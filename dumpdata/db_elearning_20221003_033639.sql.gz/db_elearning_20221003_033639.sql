-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: db_elearning
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `activity` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_course_id_foreign` (`course_id`),
  KEY `activities_student_id_foreign` (`student_id`),
  CONSTRAINT `activities_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `activities_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient` enum('all','students','teachers') COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_attachments`
--

DROP TABLE IF EXISTS `assignment_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `attachment_type` enum('file','link') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignment_attachments_assignment_id_foreign` (`assignment_id`),
  CONSTRAINT `assignment_attachments_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_attachments`
--

LOCK TABLES `assignment_attachments` WRITE;
/*!40000 ALTER TABLE `assignment_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_details`
--

DROP TABLE IF EXISTS `assignment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `basic_competence_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignment_details_assignment_id_foreign` (`assignment_id`),
  KEY `assignment_details_basic_competence_id_foreign` (`basic_competence_id`),
  CONSTRAINT `assignment_details_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `assignment_details_basic_competence_id_foreign` FOREIGN KEY (`basic_competence_id`) REFERENCES `basic_competences` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_details`
--

LOCK TABLES `assignment_details` WRITE;
/*!40000 ALTER TABLE `assignment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('skill','knowledge') COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_meeting` int(11) NOT NULL,
  `scheme` enum('writing_test','oral_test','assignment','practice','project','portfolio','product') COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_assessment` int(11) NOT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `is_uploaded` tinyint(1) NOT NULL DEFAULT '0',
  `allow_late_collection` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignments_course_id_foreign` (`course_id`),
  CONSTRAINT `assignments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('course','school') COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_id` bigint(20) unsigned DEFAULT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `study_year_id` bigint(20) unsigned NOT NULL,
  `semester` int(11) NOT NULL,
  `number_of_meetings` int(11) DEFAULT NULL,
  `checkin` time DEFAULT NULL,
  `checkout` time DEFAULT NULL,
  `date` date NOT NULL,
  `status` enum('present','permission','sick','absent','late','forget','holiday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendances_course_id_foreign` (`course_id`),
  KEY `attendances_student_id_foreign` (`student_id`),
  KEY `attendances_study_year_id_foreign` (`study_year_id`),
  CONSTRAINT `attendances_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `attendances_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `attendances_study_year_id_foreign` FOREIGN KEY (`study_year_id`) REFERENCES `study_years` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
INSERT INTO `attendances` VALUES (4,'course',9,7,1,1,1,'19:50:28',NULL,'2022-04-06','present',NULL,'2022-04-06 19:50:28','2022-04-06 19:50:28'),(5,'course',9,7,1,1,2,'16:25:08',NULL,'2022-04-08','present','Absensi kehadiran kelas online asdgh','2022-04-08 16:25:08','2022-04-08 16:25:08'),(6,'school',NULL,7,1,1,NULL,'13:58:27',NULL,'2022-06-09','absent',NULL,'2022-06-09 13:58:27','2022-06-09 13:58:27'),(7,'course',9,8,1,1,1,'20:44:26',NULL,'2022-06-11','present','Absensi kehadiran kelas online testing','2022-06-11 20:44:26','2022-06-11 20:44:26');
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_competences`
--

DROP TABLE IF EXISTS `basic_competences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_competences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `core_competence_id` bigint(20) unsigned NOT NULL,
  `course_id` bigint(20) unsigned NOT NULL,
  `code` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `basic_competences_core_competence_id_foreign` (`core_competence_id`),
  KEY `basic_competences_course_id_foreign` (`course_id`),
  CONSTRAINT `basic_competences_core_competence_id_foreign` FOREIGN KEY (`core_competence_id`) REFERENCES `core_competences` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `basic_competences_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_competences`
--

LOCK TABLES `basic_competences` WRITE;
/*!40000 ALTER TABLE `basic_competences` DISABLE KEYS */;
INSERT INTO `basic_competences` VALUES (5,1,2,1,1,'Mengenal dan menguasai konsep bahasa','2022-04-05 06:07:35',NULL),(6,1,2,2,1,'Menerapkan prinsip bahasa Indonesia kedalam kehidupan sehari-hari','2022-04-05 06:07:35',NULL),(7,1,2,3,2,'Puisi dan karya seni','2022-04-05 06:07:35',NULL),(8,1,2,4,2,'Pantun ','2022-04-05 06:07:35',NULL),(9,1,9,1,1,'Menganalisis isi dan aspek kebahasaan dari minimal dua teks laporan hasil observasi.','2022-04-06 19:44:29','2022-04-06 19:44:29'),(10,1,9,2,1,'Menganalisis struktur dan kebahasaan teks eksposisi.','2022-04-06 19:44:45','2022-04-06 19:44:45');
/*!40000 ALTER TABLE `basic_competences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broadcast_logs`
--

DROP TABLE IF EXISTS `broadcast_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `broadcast_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `broadcast_logs_course_id_foreign` (`course_id`),
  CONSTRAINT `broadcast_logs_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broadcast_logs`
--

LOCK TABLES `broadcast_logs` WRITE;
/*!40000 ALTER TABLE `broadcast_logs` DISABLE KEYS */;
INSERT INTO `broadcast_logs` VALUES (1,9,'2022-04-07 01:18:03','testing','2022-04-07 01:18:03','2022-04-07 01:18:03'),(2,9,'2022-04-07 05:47:26','testing','2022-04-07 05:47:26','2022-04-07 05:47:26'),(3,12,'2022-04-12 16:05:11','testing','2022-04-12 16:05:11','2022-04-12 16:05:11');
/*!40000 ALTER TABLE `broadcast_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_groups`
--

DROP TABLE IF EXISTS `class_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `degree_id` bigint(20) unsigned NOT NULL,
  `major_id` bigint(20) unsigned NOT NULL,
  `code` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_groups_code_unique` (`code`),
  KEY `class_groups_degree_id_foreign` (`degree_id`),
  KEY `class_groups_major_id_foreign` (`major_id`),
  CONSTRAINT `class_groups_degree_id_foreign` FOREIGN KEY (`degree_id`) REFERENCES `degrees` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `class_groups_major_id_foreign` FOREIGN KEY (`major_id`) REFERENCES `majors` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_groups`
--

LOCK TABLES `class_groups` WRITE;
/*!40000 ALTER TABLE `class_groups` DISABLE KEYS */;
INSERT INTO `class_groups` VALUES (1,1,1,'RPL-A10','RPL-A',0,'2022-04-05 06:07:33','2022-09-15 01:06:05'),(3,2,1,'RPL-A11','RPL-A',0,'2022-04-05 06:07:33','2022-09-15 01:06:07'),(4,3,1,'RPL-A12','RPL-A',0,'2022-04-05 06:07:33','2022-09-15 01:06:09'),(5,1,2,'TKJ-A10','TKJ-A',1,'2022-04-05 06:07:33','2022-09-15 01:07:29'),(21,1,7,'UCM-A','UCM-A1',0,'2022-04-06 19:27:41','2022-09-15 01:06:04'),(22,1,8,'MIPA-1','X-MIPA-1',1,'2022-09-15 01:08:09','2022-09-15 01:08:09'),(23,1,10,'X1','X1',1,'2022-09-29 09:29:15','2022-09-29 09:29:15'),(24,1,11,'X2','X2',1,'2022-10-01 18:33:10','2022-10-01 18:33:10'),(25,1,12,'X3','X3',1,'2022-10-01 18:33:24','2022-10-01 18:33:24'),(26,1,13,'X4','X4',1,'2022-10-01 18:33:46','2022-10-01 18:33:46'),(27,1,14,'X5','X5',1,'2022-10-01 18:34:05','2022-10-01 18:34:05'),(28,1,15,'X6','X6',1,'2022-10-01 18:34:19','2022-10-01 18:34:19'),(29,1,16,'X7','X7',1,'2022-10-01 18:34:33','2022-10-01 18:34:33'),(30,1,17,'X8','X8',1,'2022-10-01 18:47:27','2022-10-01 18:47:27'),(31,1,18,'X9','X9',1,'2022-10-01 18:47:46','2022-10-01 18:47:46');
/*!40000 ALTER TABLE `class_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_competences`
--

DROP TABLE IF EXISTS `core_competences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_competences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `core_competences_code_unique` (`code`),
  UNIQUE KEY `core_competences_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_competences`
--

LOCK TABLES `core_competences` WRITE;
/*!40000 ALTER TABLE `core_competences` DISABLE KEYS */;
INSERT INTO `core_competences` VALUES (1,'3','pengetahuan','Pengetahuan','2022-04-05 06:07:33',NULL),(2,'4','keterampilan','Keterampilan','2022-04-05 06:07:33',NULL);
/*!40000 ALTER TABLE `core_competences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_group_id` bigint(20) unsigned NOT NULL,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `study_year_id` bigint(20) unsigned NOT NULL,
  `thumbnail` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT 'default-course.png',
  `semester` int(11) NOT NULL,
  `number_of_meetings` int(11) NOT NULL DEFAULT '0',
  `description` tinytext COLLATE utf8mb4_unicode_ci,
  `status` enum('open','close') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_class_group_id_foreign` (`class_group_id`),
  KEY `courses_teacher_id_foreign` (`teacher_id`),
  KEY `courses_subject_id_foreign` (`subject_id`),
  KEY `courses_study_year_id_foreign` (`study_year_id`),
  CONSTRAINT `courses_class_group_id_foreign` FOREIGN KEY (`class_group_id`) REFERENCES `class_groups` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `courses_study_year_id_foreign` FOREIGN KEY (`study_year_id`) REFERENCES `study_years` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `courses_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `courses_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (2,1,4,1,1,'default-course.png',1,16,'Kelas Bahasa Indonesia Kelas 10 RPL-A','open','2022-04-05 06:07:35',NULL),(7,4,4,7,1,'default-course.png',1,16,'Kelas Pemrograman Dasar Kelas 12 RPL-A','close','2022-04-05 13:18:23','2022-04-05 13:18:23'),(9,21,5,13,1,'default-course.png',1,16,'Kelas Bhs Indonesia Kelas 10 UCM-A1','open','2022-04-06 19:32:03','2022-04-06 19:32:09'),(12,21,7,15,1,'default-course.png',1,16,'Kelas Fisika Kelas 10 UCM-A1','open','2022-04-07 13:46:06','2022-04-07 13:46:09');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `degrees`
--

DROP TABLE IF EXISTS `degrees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `degrees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `degree` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degrees`
--

LOCK TABLES `degrees` WRITE;
/*!40000 ALTER TABLE `degrees` DISABLE KEYS */;
INSERT INTO `degrees` VALUES (1,'X',10,'2022-04-05 06:07:33',NULL),(2,'XI',11,'2022-04-05 06:07:33',NULL),(3,'XII',12,'2022-04-05 06:07:33',NULL);
/*!40000 ALTER TABLE `degrees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday_settings`
--

DROP TABLE IF EXISTS `holiday_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `day_1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_1` date DEFAULT NULL,
  `date_2` date DEFAULT NULL,
  `date_3` date DEFAULT NULL,
  `start_range_1` date DEFAULT NULL,
  `end_range_1` date DEFAULT NULL,
  `start_range_2` date DEFAULT NULL,
  `end_range_2` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday_settings`
--

LOCK TABLES `holiday_settings` WRITE;
/*!40000 ALTER TABLE `holiday_settings` DISABLE KEYS */;
INSERT INTO `holiday_settings` VALUES (1,'Sunday',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35');
/*!40000 ALTER TABLE `holiday_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_assessments`
--

DROP TABLE IF EXISTS `knowledge_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_assessments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `attachment_type` enum('file','link') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade` double NOT NULL,
  `score` double DEFAULT NULL,
  `remedial` double DEFAULT NULL,
  `is_finished` tinyint(1) NOT NULL,
  `feedback` tinytext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_assessments_assignment_id_foreign` (`assignment_id`),
  KEY `knowledge_assessments_student_id_foreign` (`student_id`),
  CONSTRAINT `knowledge_assessments_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `knowledge_assessments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_assessments`
--

LOCK TABLES `knowledge_assessments` WRITE;
/*!40000 ALTER TABLE `knowledge_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_plans`
--

DROP TABLE IF EXISTS `lesson_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lesson_plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `file` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lesson_plans_course_id_foreign` (`course_id`),
  CONSTRAINT `lesson_plans_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_plans`
--

LOCK TABLES `lesson_plans` WRITE;
/*!40000 ALTER TABLE `lesson_plans` DISABLE KEYS */;
INSERT INTO `lesson_plans` VALUES (1,9,'2022-04-06','JpQKVV3QuT.pdf','2022-04-06 19:32:55','2022-04-06 19:32:55'),(2,9,'2022-04-07','vdJKsOj9ii.pdf','2022-04-07 08:46:20','2022-04-07 08:46:20');
/*!40000 ALTER TABLE `lesson_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `majors`
--

DROP TABLE IF EXISTS `majors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `majors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `majors`
--

LOCK TABLES `majors` WRITE;
/*!40000 ALTER TABLE `majors` DISABLE KEYS */;
INSERT INTO `majors` VALUES (1,'Rekayasa Perangkat Lunak','RPL',0,'2022-04-05 06:07:33','2022-09-15 01:05:27'),(2,'Teknik Komputer Jaringan','TKJ',0,'2022-04-05 06:07:33','2022-09-15 01:05:29'),(3,'Teknik Elektronika Industri','TEI',0,'2022-04-05 06:07:33','2022-09-15 01:05:30'),(7,'UJI COBA MIPA','UCM',0,'2022-04-06 19:27:07','2022-09-15 01:05:24'),(8,'MIPA','MIPA',1,'2022-09-15 01:05:50','2022-09-15 01:05:50'),(9,'IPS','IPS',1,'2022-09-15 01:05:57','2022-10-01 18:36:55'),(10,'X1','X1',1,'2022-09-29 09:27:44','2022-09-29 09:27:44'),(11,'X2','X2',1,'2022-09-29 09:27:50','2022-09-29 09:27:50'),(12,'X3','X3',1,'2022-09-29 09:27:58','2022-09-29 09:27:58'),(13,'X4','X4',1,'2022-09-29 09:28:07','2022-09-29 09:28:07'),(14,'X5','X5',1,'2022-09-29 09:28:14','2022-09-29 09:28:14'),(15,'X6','X6',1,'2022-09-29 09:28:21','2022-09-29 09:28:21'),(16,'X7','X7',1,'2022-09-29 09:28:30','2022-09-29 09:28:30'),(17,'X8','X8',1,'2022-09-29 09:28:36','2022-09-29 09:28:36'),(18,'X9','X9',1,'2022-09-29 09:28:44','2022-09-29 09:28:44');
/*!40000 ALTER TABLE `majors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_01_06_070050_create_permission_tables',1),(6,'2022_01_07_140217_create_core_competences_table',1),(7,'2022_01_07_140244_create_degrees_table',1),(8,'2022_01_07_140253_create_majors_table',1),(9,'2022_01_07_140305_create_study_years_table',1),(10,'2022_01_07_140517_create_class_groups_table',1),(11,'2022_01_07_140541_create_students_table',1),(12,'2022_01_07_140548_create_positions_table',1),(13,'2022_01_07_140549_create_teachers_table',1),(14,'2022_01_07_140550_create_shifts_table',1),(15,'2022_01_07_140607_create_student_classes_table',1),(16,'2022_01_07_140634_create_subjects_table',1),(17,'2022_01_07_140731_create_notifications_table',1),(18,'2022_01_07_140753_create_holiday_settings_table',1),(19,'2022_01_07_141107_create_courses_table',1),(20,'2022_01_07_141130_create_activities_table',1),(21,'2022_01_07_141153_create_video_conferences_table',1),(22,'2022_01_07_141159_create_video_conference_logs_table',1),(23,'2022_01_07_141223_create_lesson_plans_table',1),(24,'2022_01_07_141235_create_student_incidents_table',1),(25,'2022_01_07_141252_create_attendances_table',1),(26,'2022_01_07_141325_create_basic_competences_table',1),(27,'2022_01_07_141406_create_teaching_materials_table',1),(28,'2022_01_07_141427_create_assignments_table',1),(29,'2022_01_07_141440_create_assignment_details_table',1),(30,'2022_01_07_141526_create_knowledge_assessments_table',1),(31,'2022_01_07_141544_create_skill_assessments_table',1),(32,'2022_01_07_141559_create_semester_assessments_table',1),(33,'2022_01_07_171529_create_settings_table',1),(34,'2022_01_14_065500_create_announcements_table',1),(35,'2022_02_11_083253_create_assignment_attachments_table',1),(36,'2022_02_18_103620_create_presence_tokens_table',1),(37,'2022_04_04_154640_create_broadcast_logs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(4,'App\\Models\\User',3),(4,'App\\Models\\User',4),(4,'App\\Models\\User',5),(4,'App\\Models\\User',6),(4,'App\\Models\\User',7),(4,'App\\Models\\User',8),(3,'App\\Models\\User',9),(3,'App\\Models\\User',10),(3,'App\\Models\\User',11),(3,'App\\Models\\User',12),(3,'App\\Models\\User',13),(4,'App\\Models\\User',14),(3,'App\\Models\\User',15),(3,'App\\Models\\User',16),(4,'App\\Models\\User',17),(4,'App\\Models\\User',18),(4,'App\\Models\\User',1919),(4,'App\\Models\\User',1920),(4,'App\\Models\\User',1921),(4,'App\\Models\\User',1922),(4,'App\\Models\\User',1923),(4,'App\\Models\\User',1924),(4,'App\\Models\\User',1925),(4,'App\\Models\\User',1926),(4,'App\\Models\\User',1927),(4,'App\\Models\\User',1928),(4,'App\\Models\\User',1929),(4,'App\\Models\\User',1930),(4,'App\\Models\\User',1931),(4,'App\\Models\\User',1932),(4,'App\\Models\\User',1933),(4,'App\\Models\\User',1934),(4,'App\\Models\\User',1935),(4,'App\\Models\\User',1936),(4,'App\\Models\\User',1937),(4,'App\\Models\\User',1938),(4,'App\\Models\\User',1939),(4,'App\\Models\\User',1940),(4,'App\\Models\\User',1941),(4,'App\\Models\\User',1942),(4,'App\\Models\\User',1943),(4,'App\\Models\\User',1944),(4,'App\\Models\\User',1945),(4,'App\\Models\\User',1946),(4,'App\\Models\\User',1947),(4,'App\\Models\\User',1948),(4,'App\\Models\\User',1949),(4,'App\\Models\\User',1950),(4,'App\\Models\\User',1951),(4,'App\\Models\\User',1952),(4,'App\\Models\\User',1953),(4,'App\\Models\\User',1954),(4,'App\\Models\\User',1955),(4,'App\\Models\\User',1956),(4,'App\\Models\\User',1957),(4,'App\\Models\\User',1958),(4,'App\\Models\\User',1959),(4,'App\\Models\\User',1960),(4,'App\\Models\\User',1961),(4,'App\\Models\\User',1962),(4,'App\\Models\\User',1963),(4,'App\\Models\\User',1964),(4,'App\\Models\\User',1965),(4,'App\\Models\\User',1966),(4,'App\\Models\\User',1967),(4,'App\\Models\\User',1968),(4,'App\\Models\\User',1969),(4,'App\\Models\\User',1970),(4,'App\\Models\\User',1971),(4,'App\\Models\\User',1972),(4,'App\\Models\\User',1973),(4,'App\\Models\\User',1974),(4,'App\\Models\\User',1975),(4,'App\\Models\\User',1976),(4,'App\\Models\\User',1977),(4,'App\\Models\\User',1978),(4,'App\\Models\\User',1979),(4,'App\\Models\\User',1980),(4,'App\\Models\\User',1981),(4,'App\\Models\\User',1982),(4,'App\\Models\\User',1983),(4,'App\\Models\\User',1984),(4,'App\\Models\\User',1985),(4,'App\\Models\\User',1986),(4,'App\\Models\\User',1987),(4,'App\\Models\\User',1988),(4,'App\\Models\\User',1989),(4,'App\\Models\\User',1990),(4,'App\\Models\\User',1991),(4,'App\\Models\\User',1992),(4,'App\\Models\\User',1993),(4,'App\\Models\\User',1994),(4,'App\\Models\\User',1995),(4,'App\\Models\\User',1996),(4,'App\\Models\\User',1997),(4,'App\\Models\\User',1998),(4,'App\\Models\\User',1999),(4,'App\\Models\\User',2000),(4,'App\\Models\\User',2001),(4,'App\\Models\\User',2002),(4,'App\\Models\\User',2003),(4,'App\\Models\\User',2004),(4,'App\\Models\\User',2005),(4,'App\\Models\\User',2006),(4,'App\\Models\\User',2007),(4,'App\\Models\\User',2008),(4,'App\\Models\\User',2009),(4,'App\\Models\\User',2010),(4,'App\\Models\\User',2011),(4,'App\\Models\\User',2012),(4,'App\\Models\\User',2013),(4,'App\\Models\\User',2014),(4,'App\\Models\\User',2015),(4,'App\\Models\\User',2016),(4,'App\\Models\\User',2017),(4,'App\\Models\\User',2018),(4,'App\\Models\\User',2019),(4,'App\\Models\\User',2020),(4,'App\\Models\\User',2021),(4,'App\\Models\\User',2022),(4,'App\\Models\\User',2023),(4,'App\\Models\\User',2024),(4,'App\\Models\\User',2025),(4,'App\\Models\\User',2026),(4,'App\\Models\\User',2027),(4,'App\\Models\\User',2028),(4,'App\\Models\\User',2029),(4,'App\\Models\\User',2030),(4,'App\\Models\\User',2031),(4,'App\\Models\\User',2032),(4,'App\\Models\\User',2033),(4,'App\\Models\\User',2034),(4,'App\\Models\\User',2035),(4,'App\\Models\\User',2036),(4,'App\\Models\\User',2037),(4,'App\\Models\\User',2038),(4,'App\\Models\\User',2039),(4,'App\\Models\\User',2040),(4,'App\\Models\\User',2041),(4,'App\\Models\\User',2042),(4,'App\\Models\\User',2043),(4,'App\\Models\\User',2044),(4,'App\\Models\\User',2045),(4,'App\\Models\\User',2046),(4,'App\\Models\\User',2047),(4,'App\\Models\\User',2048),(4,'App\\Models\\User',2049),(4,'App\\Models\\User',2050),(4,'App\\Models\\User',2051),(4,'App\\Models\\User',2052),(4,'App\\Models\\User',2053),(4,'App\\Models\\User',2054),(4,'App\\Models\\User',2055),(4,'App\\Models\\User',2056),(4,'App\\Models\\User',2057),(4,'App\\Models\\User',2058),(4,'App\\Models\\User',2059),(4,'App\\Models\\User',2060),(4,'App\\Models\\User',2061),(4,'App\\Models\\User',2062),(4,'App\\Models\\User',2063),(4,'App\\Models\\User',2064),(4,'App\\Models\\User',2065),(4,'App\\Models\\User',2066),(4,'App\\Models\\User',2067),(4,'App\\Models\\User',2068),(4,'App\\Models\\User',2069),(4,'App\\Models\\User',2070),(4,'App\\Models\\User',2071),(4,'App\\Models\\User',2072),(4,'App\\Models\\User',2073),(4,'App\\Models\\User',2074),(4,'App\\Models\\User',2075),(4,'App\\Models\\User',2076),(4,'App\\Models\\User',2077),(4,'App\\Models\\User',2078),(4,'App\\Models\\User',2079),(4,'App\\Models\\User',2080),(4,'App\\Models\\User',2081),(4,'App\\Models\\User',2082),(4,'App\\Models\\User',2083),(4,'App\\Models\\User',2084),(4,'App\\Models\\User',2085),(4,'App\\Models\\User',2086),(4,'App\\Models\\User',2087),(4,'App\\Models\\User',2088),(4,'App\\Models\\User',2089),(4,'App\\Models\\User',2090),(4,'App\\Models\\User',2091),(4,'App\\Models\\User',2092),(4,'App\\Models\\User',2093),(4,'App\\Models\\User',2094),(4,'App\\Models\\User',2095),(4,'App\\Models\\User',2096),(4,'App\\Models\\User',2097),(4,'App\\Models\\User',2098),(4,'App\\Models\\User',2099),(4,'App\\Models\\User',2100),(4,'App\\Models\\User',2101),(4,'App\\Models\\User',2102),(4,'App\\Models\\User',2103),(4,'App\\Models\\User',2104),(4,'App\\Models\\User',2105),(4,'App\\Models\\User',2106),(4,'App\\Models\\User',2107),(4,'App\\Models\\User',2108),(4,'App\\Models\\User',2109),(4,'App\\Models\\User',2110),(4,'App\\Models\\User',2111),(4,'App\\Models\\User',2112),(4,'App\\Models\\User',2113),(4,'App\\Models\\User',2114),(4,'App\\Models\\User',2115),(4,'App\\Models\\User',2116),(4,'App\\Models\\User',2117),(4,'App\\Models\\User',2118),(4,'App\\Models\\User',2119),(4,'App\\Models\\User',2120),(4,'App\\Models\\User',2121),(4,'App\\Models\\User',2122),(4,'App\\Models\\User',2123),(4,'App\\Models\\User',2124),(4,'App\\Models\\User',2125),(4,'App\\Models\\User',2126),(4,'App\\Models\\User',2127),(4,'App\\Models\\User',2128),(4,'App\\Models\\User',2129),(4,'App\\Models\\User',2130),(4,'App\\Models\\User',2131),(4,'App\\Models\\User',2132),(4,'App\\Models\\User',2133),(4,'App\\Models\\User',2134),(4,'App\\Models\\User',2135),(4,'App\\Models\\User',2136),(4,'App\\Models\\User',2137),(4,'App\\Models\\User',2138),(4,'App\\Models\\User',2139),(4,'App\\Models\\User',2140),(4,'App\\Models\\User',2141),(4,'App\\Models\\User',2142),(4,'App\\Models\\User',2143),(4,'App\\Models\\User',2144),(4,'App\\Models\\User',2145),(4,'App\\Models\\User',2146),(4,'App\\Models\\User',2147),(4,'App\\Models\\User',2148),(4,'App\\Models\\User',2149),(4,'App\\Models\\User',2150),(4,'App\\Models\\User',2151),(4,'App\\Models\\User',2152),(4,'App\\Models\\User',2153),(4,'App\\Models\\User',2154),(4,'App\\Models\\User',2155),(4,'App\\Models\\User',2156),(4,'App\\Models\\User',2157),(4,'App\\Models\\User',2158),(4,'App\\Models\\User',2159),(4,'App\\Models\\User',2160),(4,'App\\Models\\User',2161),(4,'App\\Models\\User',2162),(4,'App\\Models\\User',2163),(4,'App\\Models\\User',2164),(4,'App\\Models\\User',2165),(4,'App\\Models\\User',2166),(4,'App\\Models\\User',2167),(4,'App\\Models\\User',2168),(4,'App\\Models\\User',2169),(4,'App\\Models\\User',2170),(4,'App\\Models\\User',2171),(4,'App\\Models\\User',2172),(4,'App\\Models\\User',2173),(4,'App\\Models\\User',2174),(4,'App\\Models\\User',2175),(4,'App\\Models\\User',2176),(4,'App\\Models\\User',2177),(4,'App\\Models\\User',2178),(4,'App\\Models\\User',2179),(4,'App\\Models\\User',2180),(4,'App\\Models\\User',2181),(4,'App\\Models\\User',2182),(4,'App\\Models\\User',2183),(4,'App\\Models\\User',2184),(4,'App\\Models\\User',2185),(4,'App\\Models\\User',2186),(4,'App\\Models\\User',2187),(4,'App\\Models\\User',2188),(4,'App\\Models\\User',2189),(4,'App\\Models\\User',2190),(4,'App\\Models\\User',2191),(4,'App\\Models\\User',2192),(4,'App\\Models\\User',2193),(4,'App\\Models\\User',2194),(4,'App\\Models\\User',2195),(4,'App\\Models\\User',2196),(4,'App\\Models\\User',2197),(4,'App\\Models\\User',2198),(4,'App\\Models\\User',2199),(4,'App\\Models\\User',2200),(4,'App\\Models\\User',2201),(4,'App\\Models\\User',2202),(4,'App\\Models\\User',2203),(4,'App\\Models\\User',2204),(4,'App\\Models\\User',2205),(4,'App\\Models\\User',2206),(4,'App\\Models\\User',2207),(4,'App\\Models\\User',2208),(4,'App\\Models\\User',2209),(4,'App\\Models\\User',2210),(4,'App\\Models\\User',2211),(4,'App\\Models\\User',2212),(4,'App\\Models\\User',2213),(4,'App\\Models\\User',2214),(4,'App\\Models\\User',2215),(4,'App\\Models\\User',2216),(4,'App\\Models\\User',2217),(4,'App\\Models\\User',2218),(4,'App\\Models\\User',2219),(4,'App\\Models\\User',2220),(4,'App\\Models\\User',2221),(4,'App\\Models\\User',2222),(4,'App\\Models\\User',2223),(4,'App\\Models\\User',2224),(4,'App\\Models\\User',2225),(4,'App\\Models\\User',2226),(4,'App\\Models\\User',2227),(4,'App\\Models\\User',2228),(4,'App\\Models\\User',2229),(4,'App\\Models\\User',2230),(4,'App\\Models\\User',2231),(4,'App\\Models\\User',2232),(4,'App\\Models\\User',2233),(4,'App\\Models\\User',2234),(4,'App\\Models\\User',2235),(4,'App\\Models\\User',2236),(4,'App\\Models\\User',2237),(4,'App\\Models\\User',2238),(4,'App\\Models\\User',2239),(4,'App\\Models\\User',2240),(4,'App\\Models\\User',2241),(4,'App\\Models\\User',2242),(4,'App\\Models\\User',2243);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceable_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceable_id` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,14,'Materi / Bahan Ajar','Guru 1 telah menambahkan materi / bahan ajar baru pada kelas UCM-A1','App\\Models\\TeachingMaterial','7','https://eclass.sman1cluring.sch.id/student/-4ae385g67a4-3a27657892d86dg4-ea36985ge42-e935g762/class-detail',1,'2022-04-06 19:46:02','2022-04-08 21:14:22'),(2,14,'Materi / Bahan Ajar','Guru 1 telah menambahkan materi / bahan ajar baru pada kelas UCM-A1','App\\Models\\TeachingMaterial','8','https://eclass.sman1cluring.sch.id/student/-4ae385g67a4-3a27657892d86dg4-ea36985ge42-e935g762/class-detail',1,'2022-04-06 19:48:01','2022-04-08 21:14:22'),(3,14,'Video Conference','testing pada tanggal Kamis, 7 April 2022 pukul 05.49','App\\Models\\VideoConference','4','https://eclass.sman1cluring.sch.id/student/classroom/-4ae385g67a4-3a27657892d86dg4-ea36985ge42-e935g762/video-conference/5g46a-736548497e-6-e4g2d39d5a9837ag23568ea29ge239-/conference-room',1,'2022-04-07 05:49:26','2022-04-08 21:14:22'),(4,14,'Video Conference','asdgh pada tanggal Kamis, 7 April 2022 pukul 08.43','App\\Models\\VideoConference','5','https://eclass.sman1cluring.sch.id/student/classroom/-4ae385g67a4-3a27657892d86dg4-ea36985ge42-e935g762/video-conference/a23-769e23ae67-g92739-4d62d6ge58a2a845375-g48e9456/conference-room',1,'2022-04-07 08:43:43','2022-04-08 21:14:22'),(5,14,'Video Conference','asdgh telah berakhir pada Jumat, 8 April 2022 pukul 16.29','App\\Models\\VideoConference','5','#',1,'2022-04-08 16:29:27','2022-04-08 21:14:22'),(6,17,'Video Conference','asdgh telah berakhir pada Jumat, 8 April 2022 pukul 16.29','App\\Models\\VideoConference','5','#',1,'2022-04-08 16:29:27','2022-06-11 20:32:49'),(7,18,'Video Conference','asdgh telah berakhir pada Jumat, 8 April 2022 pukul 16.29','App\\Models\\VideoConference','5','#',0,'2022-04-08 16:29:27','2022-04-08 16:29:27'),(8,3,'Video Conference','Pertemuan Pertama pada tanggal Rabu, 13 April 2022 pukul 20.17','App\\Models\\VideoConference','6','https://eclass.sman1cluring.sch.id/student/classroom/852395ge9738-54964e65-7d4gbg28a9323g7ae6a48-274g-6/video-conference/49e-642-7g874532a3-2g84d95d9765ae-68eg935e69a7g253/conference-room',0,'2022-04-13 20:18:07','2022-04-13 20:18:07'),(9,4,'Video Conference','Pertemuan Pertama pada tanggal Rabu, 13 April 2022 pukul 20.17','App\\Models\\VideoConference','6','https://eclass.sman1cluring.sch.id/student/classroom/852395ge9738-54964e65-7d4gbg28a9323g7ae6a48-274g-6/video-conference/49e-642-7g874532a3-2g84d95d9765ae-68eg935e69a7g253/conference-room',0,'2022-04-13 20:18:07','2022-04-13 20:18:07'),(10,5,'Video Conference','Pertemuan Pertama pada tanggal Rabu, 13 April 2022 pukul 20.17','App\\Models\\VideoConference','6','https://eclass.sman1cluring.sch.id/student/classroom/852395ge9738-54964e65-7d4gbg28a9323g7ae6a48-274g-6/video-conference/49e-642-7g874532a3-2g84d95d9765ae-68eg935e69a7g253/conference-room',0,'2022-04-13 20:18:07','2022-04-13 20:18:07');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `token` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_resets_user_id_foreign` (`user_id`),
  KEY `password_resets_email_index` (`email`),
  CONSTRAINT `password_resets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'read-dashboard','web','2022-04-05 06:07:33',NULL),(2,'read-users','web','2022-04-05 06:07:33',NULL),(3,'create-users','web','2022-04-05 06:07:33',NULL),(4,'update-users','web','2022-04-05 06:07:33',NULL),(5,'delete-users','web','2022-04-05 06:07:33',NULL),(6,'read-majors','web','2022-04-05 06:07:33',NULL),(7,'create-majors','web','2022-04-05 06:07:33',NULL),(8,'update-majors','web','2022-04-05 06:07:33',NULL),(9,'delete-majors','web','2022-04-05 06:07:33',NULL),(10,'read-teacher','web','2022-04-05 06:07:33',NULL),(11,'create-teacher','web','2022-04-05 06:07:33',NULL),(12,'update-teacher','web','2022-04-05 06:07:33',NULL),(13,'delete-teacher','web','2022-04-05 06:07:33',NULL),(14,'change-permissions','web','2022-04-05 06:07:33',NULL),(15,'read-roles','web','2022-04-05 06:07:33',NULL),(16,'read-class-groups','web','2022-04-05 06:07:33',NULL),(17,'create-class-groups','web','2022-04-05 06:07:33',NULL),(18,'update-class-groups','web','2022-04-05 06:07:33',NULL),(19,'delete-class-groups','web','2022-04-05 06:07:33',NULL),(20,'read-study-years','web','2022-04-05 06:07:33',NULL),(21,'create-study-years','web','2022-04-05 06:07:33',NULL),(22,'update-study-years','web','2022-04-05 06:07:33',NULL),(23,'delete-study-years','web','2022-04-05 06:07:33',NULL),(24,'read-subjects','web','2022-04-05 06:07:33',NULL),(25,'create-subjects','web','2022-04-05 06:07:33',NULL),(26,'update-subjects','web','2022-04-05 06:07:33',NULL),(27,'delete-subjects','web','2022-04-05 06:07:33',NULL),(28,'read-student-classes','web','2022-04-05 06:07:33',NULL),(29,'create-student-classes','web','2022-04-05 06:07:33',NULL),(30,'update-student-classes','web','2022-04-05 06:07:33',NULL),(31,'delete-student-classes','web','2022-04-05 06:07:33',NULL),(32,'read-settings','web','2022-04-05 06:07:33',NULL),(33,'update-settings','web','2022-04-05 06:07:33',NULL),(34,'read-announcements','web','2022-04-05 06:07:33',NULL),(35,'create-announcements','web','2022-04-05 06:07:33',NULL),(36,'update-announcements','web','2022-04-05 06:07:33',NULL),(37,'delete-announcements','web','2022-04-05 06:07:33',NULL),(38,'read-teaching-materials','web','2022-04-05 06:07:33',NULL),(39,'create-teaching-materials','web','2022-04-05 06:07:33',NULL),(40,'update-teaching-materials','web','2022-04-05 06:07:33',NULL),(41,'delete-teaching-materials','web','2022-04-05 06:07:33',NULL),(42,'read-student','web','2022-04-05 06:07:33',NULL),(43,'create-student','web','2022-04-05 06:07:33',NULL),(44,'update-student','web','2022-04-05 06:07:33',NULL),(45,'delete-student','web','2022-04-05 06:07:33',NULL),(46,'read-basic-competence','web','2022-04-05 06:07:33',NULL),(47,'create-basic-competence','web','2022-04-05 06:07:33',NULL),(48,'update-basic-competence','web','2022-04-05 06:07:33',NULL),(49,'delete-basic-competence','web','2022-04-05 06:07:33',NULL),(50,'read-shift','web','2022-04-05 06:07:33',NULL),(51,'create-shift','web','2022-04-05 06:07:33',NULL),(52,'update-shift','web','2022-04-05 06:07:33',NULL),(53,'delete-shift','web','2022-04-05 06:07:33',NULL),(54,'read-holiday-settings','web','2022-04-05 06:07:33',NULL),(55,'update-holiday-settings','web','2022-04-05 06:07:33',NULL),(56,'read-lesson-plan','web','2022-04-05 06:07:33',NULL),(57,'create-lesson-plan','web','2022-04-05 06:07:33',NULL),(58,'update-lesson-plan','web','2022-04-05 06:07:33',NULL),(59,'delete-lesson-plan','web','2022-04-05 06:07:33',NULL),(60,'read-video-conference','web','2022-04-05 06:07:33',NULL),(61,'create-video-conference','web','2022-04-05 06:07:33',NULL),(62,'update-video-conference','web','2022-04-05 06:07:33',NULL),(63,'delete-video-conference','web','2022-04-05 06:07:33',NULL),(64,'join-video-conference','web','2022-04-05 06:07:33',NULL),(65,'read-student-incident','web','2022-04-05 06:07:33',NULL),(66,'create-student-incident','web','2022-04-05 06:07:33',NULL),(67,'update-student-incident','web','2022-04-05 06:07:33',NULL),(68,'delete-student-incident','web','2022-04-05 06:07:33',NULL),(69,'read-student-class-list','web','2022-04-05 06:07:33',NULL),(70,'read-course-setting','web','2022-04-05 06:07:33',NULL),(71,'update-course-setting','web','2022-04-05 06:07:33',NULL),(72,'read-semester-assessment','web','2022-04-05 06:07:33',NULL),(73,'read-student-dashboard-class-detail','web','2022-04-05 06:07:33',NULL),(74,'create-student-dashboard-class-detail','web','2022-04-05 06:07:33',NULL),(75,'read-student-dashboard-update-profile','web','2022-04-05 06:07:33',NULL),(76,'update-student-dashboard-update-profile','web','2022-04-05 06:07:33',NULL),(77,'read-student-dashboard-assignment','web','2022-04-05 06:07:33',NULL),(78,'create-student-dashboard-assignment','web','2022-04-05 06:07:33',NULL),(79,'join-student-dashboard-video-conference','web','2022-04-05 06:07:33',NULL),(80,'read-class-attendance','web','2022-04-05 06:07:33',NULL),(81,'create-class-attendance','web','2022-04-05 06:07:33',NULL),(82,'update-class-attendance','web','2022-04-05 06:07:33',NULL),(83,'print-class-attendance','web','2022-04-05 06:07:33',NULL),(84,'read-monitoring-activity','web','2022-04-05 06:07:33',NULL),(85,'read-course','web','2022-04-05 06:07:33',NULL),(86,'create-course','web','2022-04-05 06:07:33',NULL),(87,'update-course','web','2022-04-05 06:07:33',NULL),(88,'delete-course','web','2022-04-05 06:07:33',NULL),(89,'read-school-present','web','2022-04-05 06:07:33',NULL),(90,'read-teacher-skill-assessment','web','2022-04-05 06:07:33',NULL),(91,'create-teacher-skill-assessment','web','2022-04-05 06:07:33',NULL),(92,'update-teacher-skill-assessment','web','2022-04-05 06:07:33',NULL),(93,'delete-teacher-skill-assessment','web','2022-04-05 06:07:33',NULL),(94,'read-teacher-semester-assessment','web','2022-04-05 06:07:33',NULL),(95,'read-wa-gateway','web','2022-04-05 06:07:33',NULL),(96,'update-wa-gateway','web','2022-04-05 06:07:33',NULL),(97,'read-admin-class-attendance','web','2022-04-05 06:07:33',NULL),(98,'broadcast-wa','web','2022-04-05 06:07:33',NULL),(99,'read-teacher-knowledge-assessment','web','2022-04-05 06:07:33',NULL),(100,'create-teacher-knowledge-assessment','web','2022-04-05 06:07:33',NULL),(101,'update-teacher-knowledge-assessment','web','2022-04-05 06:07:33',NULL),(102,'delete-teacher-knowledge-assessment','web','2022-04-05 06:07:33',NULL),(103,'read-position','web','2022-04-05 06:07:33',NULL),(104,'create-position','web','2022-04-05 06:07:33',NULL),(105,'update-position','web','2022-04-05 06:07:33',NULL),(106,'delete-position','web','2022-04-05 06:07:33',NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'Guru',NULL,NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presence_tokens`
--

DROP TABLE IF EXISTS `presence_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presence_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('a','b') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'a = kehadiran, b = pulang',
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presence_tokens`
--

LOCK TABLES `presence_tokens` WRITE;
/*!40000 ALTER TABLE `presence_tokens` DISABLE KEYS */;
INSERT INTO `presence_tokens` VALUES (1,'a','pOL2t4yoX79554qY','2022-04-05 06:07:35',NULL),(2,'b','HmsdAWsg7674fI2D','2022-04-05 06:07:35',NULL);
/*!40000 ALTER TABLE `presence_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(72,1),(85,1),(86,1),(87,1),(88,1),(89,1),(95,1),(96,1),(97,1),(98,1),(103,1),(104,1),(105,1),(106,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2),(40,2),(41,2),(42,2),(43,2),(44,2),(45,2),(50,2),(51,2),(52,2),(53,2),(54,2),(55,2),(72,2),(85,2),(86,2),(87,2),(88,2),(89,2),(95,2),(96,2),(97,2),(103,2),(104,2),(105,2),(106,2),(1,3),(38,3),(39,3),(40,3),(41,3),(46,3),(47,3),(48,3),(49,3),(56,3),(57,3),(58,3),(59,3),(60,3),(61,3),(62,3),(63,3),(64,3),(65,3),(66,3),(67,3),(68,3),(69,3),(70,3),(71,3),(80,3),(81,3),(82,3),(83,3),(84,3),(90,3),(91,3),(92,3),(93,3),(94,3),(98,3),(99,3),(100,3),(101,3),(102,3),(1,4),(60,4),(64,4),(73,4),(74,4),(75,4),(76,4),(77,4),(78,4),(79,4);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Developer','web','2022-04-05 06:07:33','2022-04-05 06:07:33'),(2,'Administrator','web','2022-04-05 06:07:33','2022-04-05 06:07:33'),(3,'Guru','web','2022-04-05 06:07:33','2022-04-05 06:07:33'),(4,'Siswa','web','2022-04-05 06:07:33','2022-04-05 06:07:33');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester_assessments`
--

DROP TABLE IF EXISTS `semester_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semester_assessments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `study_year_id` bigint(20) unsigned NOT NULL,
  `semester` int(11) NOT NULL,
  `score` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `semester_assessments_course_id_foreign` (`course_id`),
  KEY `semester_assessments_student_id_foreign` (`student_id`),
  KEY `semester_assessments_study_year_id_foreign` (`study_year_id`),
  CONSTRAINT `semester_assessments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `semester_assessments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `semester_assessments_study_year_id_foreign` FOREIGN KEY (`study_year_id`) REFERENCES `study_years` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester_assessments`
--

LOCK TABLES `semester_assessments` WRITE;
/*!40000 ALTER TABLE `semester_assessments` DISABLE KEYS */;
INSERT INTO `semester_assessments` VALUES (1,2,2,1,1,80,NULL,NULL),(2,2,1,1,1,78,NULL,NULL),(3,2,3,1,1,90,NULL,NULL);
/*!40000 ALTER TABLE `semester_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `groups` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `display_suffix` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'General','web_name','Web Name','eclass edu',1,NULL,'2022-04-05 06:07:35','2022-04-13 12:56:35'),(2,'General','web_description','Description','The Laravel Permission System is a system used to manage permissions in your application',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(3,'General','web_keyword','Keyword','Easily create permissions in your application with the Laravel Permission System',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(4,'General','web_author','Author','eclass',1,NULL,'2022-04-05 06:07:35','2022-04-07 01:07:32'),(5,'General','copyright','Copyright','eclass',1,NULL,'2022-04-05 06:07:35','2022-04-07 01:07:24'),(6,'General','email','Email','contact@webmediadigital.com',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(7,'General','phone','Telepon','085642746374',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(8,'General','address','Address','Banyuwangi, Jawa Timur, Indonesia',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(9,'General','facebook','Facebook','https://www.facebook.com/webmedia',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(10,'General','instagram','Instagram','webmedia.id',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(11,'General','youtube','Youtube','Web Media Solusi Digital',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(12,'Image','favicon','Favicon','SMAN1Cluring-emblem (1).png',1,NULL,'2022-04-05 06:07:35','2022-06-20 14:20:07'),(13,'Image','logo','Logo','SMAN1Cluring-emblem (1).png',1,NULL,'2022-04-05 06:07:35','2022-06-20 14:19:53'),(14,'Config','maintenance_mode','Maintenance Mode','N',0,NULL,'2022-04-05 06:07:35','2022-06-15 15:19:34'),(15,'General','presence_entry_code','Presence Entry Code','presence123',1,NULL,'2022-04-05 06:07:35','2022-04-05 06:07:35'),(16,'General','ruang_wa_token','WA Gateway Token','hwqmGyEdaEWE7Juu22PtvwkB8tZgZd1MLLmJSaeZgpPwPSyf4r',1,NULL,'2022-04-05 06:07:35','2022-04-07 05:46:22');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_entry` time NOT NULL,
  `start_time_entry` time NOT NULL,
  `last_time_entry` time NOT NULL,
  `start_exit` time NOT NULL,
  `start_time_exit` time NOT NULL,
  `last_time_exit` time NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES (1,'Shift 1','05:00:00','08:00:00','12:00:00','14:30:00','15:00:00','17:00:00',1,'2022-04-05 06:07:35','2022-04-05 06:07:35');
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill_assessments`
--

DROP TABLE IF EXISTS `skill_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_assessments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `attachment_type` enum('file','link') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade` double NOT NULL,
  `theory_score` double DEFAULT NULL,
  `process_score` double DEFAULT NULL,
  `rhetoric_score` double DEFAULT NULL,
  `feedback_score` double DEFAULT NULL,
  `result_score` double DEFAULT NULL,
  `total_score` double DEFAULT NULL,
  `score` double DEFAULT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `skill_assessments_assignment_id_foreign` (`assignment_id`),
  KEY `skill_assessments_student_id_foreign` (`student_id`),
  CONSTRAINT `skill_assessments_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `skill_assessments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill_assessments`
--

LOCK TABLES `skill_assessments` WRITE;
/*!40000 ALTER TABLE `skill_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `skill_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_classes`
--

DROP TABLE IF EXISTS `student_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_group_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `study_year_id` bigint(20) unsigned NOT NULL,
  `shift_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_classes_class_group_id_foreign` (`class_group_id`),
  KEY `student_classes_student_id_foreign` (`student_id`),
  KEY `student_classes_study_year_id_foreign` (`study_year_id`),
  KEY `student_classes_shift_id_foreign` (`shift_id`),
  CONSTRAINT `student_classes_class_group_id_foreign` FOREIGN KEY (`class_group_id`) REFERENCES `class_groups` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `student_classes_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `student_classes_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `student_classes_study_year_id_foreign` FOREIGN KEY (`study_year_id`) REFERENCES `study_years` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_classes`
--

LOCK TABLES `student_classes` WRITE;
/*!40000 ALTER TABLE `student_classes` DISABLE KEYS */;
INSERT INTO `student_classes` VALUES (1,1,1,1,1,'2022-04-05 06:07:35',NULL),(2,1,2,1,1,'2022-04-05 06:07:35',NULL),(3,1,3,1,1,'2022-04-05 06:07:35',NULL),(4,5,4,1,1,'2022-04-05 06:07:35',NULL),(5,5,5,1,1,'2022-04-05 06:07:35',NULL),(6,21,7,1,1,'2022-04-06 19:30:38','2022-04-06 19:30:38'),(7,21,8,1,1,'2022-04-07 13:51:16','2022-04-07 13:51:16'),(8,21,9,1,1,'2022-04-07 13:51:16','2022-04-07 13:51:16'),(9,23,1920,1,1,'2022-10-01 18:20:07','2022-10-01 18:20:07'),(10,23,1921,1,1,'2022-10-01 18:20:07','2022-10-01 18:20:07'),(11,23,1922,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(12,23,1923,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(13,23,1924,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(14,23,1925,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(15,23,1926,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(16,23,1927,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(17,23,1928,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(18,23,1929,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(19,23,1930,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(20,23,1931,1,1,'2022-10-01 18:38:21','2022-10-01 18:38:21'),(21,23,1932,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(22,23,1933,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(23,23,1934,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(24,23,1935,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(25,23,1936,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(26,23,1937,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(27,23,1938,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(28,23,1939,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(29,23,1940,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(30,23,1941,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(31,23,1942,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(32,23,1943,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(33,23,1944,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(34,23,1945,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(35,23,1946,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(36,23,1947,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(37,23,1948,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(38,23,1949,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(39,23,1950,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(40,23,1951,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(41,23,1952,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(42,23,1953,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(43,23,1954,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(44,23,1955,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(45,23,1956,1,1,'2022-10-01 18:39:19','2022-10-01 18:39:19'),(46,24,1957,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(47,24,1958,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(48,24,1959,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(49,24,1960,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(50,24,1961,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(51,24,1962,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(52,24,1963,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(53,24,1964,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(54,24,1965,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(55,24,1966,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(56,24,1967,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(57,24,1968,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(58,24,1969,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(59,24,1970,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(60,24,1971,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(61,24,1972,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(62,24,1973,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(63,24,1974,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(64,24,1975,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(65,24,1976,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(66,24,1977,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(67,24,1978,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(68,24,1979,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(69,24,1980,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(70,24,1981,1,1,'2022-10-01 18:39:58','2022-10-01 18:39:58'),(71,24,1982,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(72,24,1983,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(73,24,1984,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(74,24,1985,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(75,24,1986,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(76,24,1987,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(77,24,1988,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(78,24,1989,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(79,24,1990,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(80,24,1991,1,1,'2022-10-01 18:40:09','2022-10-01 18:40:09'),(81,24,1992,1,1,'2022-10-01 18:40:10','2022-10-01 18:40:10'),(82,25,1993,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(83,25,1994,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(84,25,1995,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(85,25,1996,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(86,25,1997,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(87,25,1998,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(88,25,1999,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(89,25,2000,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(90,25,2001,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(91,25,2002,1,1,'2022-10-01 18:40:47','2022-10-01 18:40:47'),(92,25,2003,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(93,25,2004,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(94,25,2005,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(95,25,2006,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(96,25,2007,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(97,25,2008,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(98,25,2009,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(99,25,2010,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(100,25,2011,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(101,25,2012,1,1,'2022-10-01 18:40:56','2022-10-01 18:40:56'),(102,25,2013,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(103,25,2014,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(104,25,2015,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(105,25,2016,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(106,25,2017,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(107,25,2018,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(108,25,2019,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(109,25,2020,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(110,25,2021,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(111,25,2022,1,1,'2022-10-01 18:41:02','2022-10-01 18:41:02'),(112,25,2023,1,1,'2022-10-01 18:41:08','2022-10-01 18:41:08'),(113,25,2024,1,1,'2022-10-01 18:41:08','2022-10-01 18:41:08'),(114,25,2025,1,1,'2022-10-01 18:41:08','2022-10-01 18:41:08'),(115,25,2026,1,1,'2022-10-01 18:41:08','2022-10-01 18:41:08'),(116,25,2027,1,1,'2022-10-01 18:41:08','2022-10-01 18:41:08'),(117,26,2028,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(118,26,2029,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(119,26,2030,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(120,26,2031,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(121,26,2032,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(122,26,2033,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(123,26,2034,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(124,26,2035,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(125,26,2036,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(126,26,2037,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(127,26,2038,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(128,26,2039,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(129,26,2040,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(130,26,2041,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(131,26,2042,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(132,26,2043,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(133,26,2044,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(134,26,2045,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(135,26,2046,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(136,26,2047,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(137,26,2048,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(138,26,2049,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(139,26,2050,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(140,26,2051,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(141,26,2052,1,1,'2022-10-01 18:41:30','2022-10-01 18:41:30'),(142,26,2053,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(143,26,2054,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(144,26,2055,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(145,26,2056,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(146,26,2057,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(147,26,2058,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(148,26,2059,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(149,26,2060,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(150,26,2061,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(151,26,2062,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(152,26,2063,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(153,26,2064,1,1,'2022-10-01 18:41:38','2022-10-01 18:41:38'),(154,27,2065,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(155,27,2066,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(156,27,2067,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(157,27,2068,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(158,27,2069,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(159,27,2070,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(160,27,2071,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(161,27,2072,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(162,27,2073,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(163,27,2074,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(164,27,2075,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(165,27,2076,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(166,27,2077,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(167,27,2078,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(168,27,2079,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(169,27,2080,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(170,27,2081,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(171,27,2082,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(172,27,2083,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(173,27,2084,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(174,27,2085,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(175,27,2086,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(176,27,2087,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(177,27,2088,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(178,27,2089,1,1,'2022-10-01 18:42:00','2022-10-01 18:42:00'),(179,27,2090,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(180,27,2091,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(181,27,2092,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(182,27,2093,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(183,27,2094,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(184,27,2095,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(185,27,2096,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(186,27,2097,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(187,27,2098,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(188,27,2099,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(189,27,2100,1,1,'2022-10-01 18:42:09','2022-10-01 18:42:09'),(190,28,2101,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(191,28,2102,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(192,28,2103,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(193,28,2104,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(194,28,2105,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(195,28,2106,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(196,28,2107,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(197,28,2108,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(198,28,2109,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(199,28,2110,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(200,28,2111,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(201,28,2112,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(202,28,2113,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(203,28,2114,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(204,28,2115,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(205,28,2116,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(206,28,2117,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(207,28,2118,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(208,28,2119,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(209,28,2120,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(210,28,2121,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(211,28,2122,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(212,28,2123,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(213,28,2124,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(214,28,2125,1,1,'2022-10-01 18:42:41','2022-10-01 18:42:41'),(215,28,2126,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(216,28,2127,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(217,28,2128,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(218,28,2129,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(219,28,2130,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(220,28,2131,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(221,28,2132,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(222,28,2133,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(223,28,2134,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(224,28,2135,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(225,28,2136,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(226,28,2137,1,1,'2022-10-01 18:42:48','2022-10-01 18:42:48'),(227,29,2172,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(228,29,2173,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(229,29,2174,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(230,29,2175,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(231,29,2176,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(232,29,2177,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(233,29,2178,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(234,29,2179,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(235,29,2180,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(236,29,2181,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(237,29,2182,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(238,29,2183,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(239,29,2184,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(240,29,2185,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(241,29,2186,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(242,29,2187,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(243,29,2188,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(244,29,2189,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(245,29,2190,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(246,29,2191,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(247,29,2192,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(248,29,2193,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(249,29,2194,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(250,29,2195,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(251,29,2196,1,1,'2022-10-01 18:44:23','2022-10-01 18:44:23'),(252,29,2197,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(253,29,2198,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(254,29,2199,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(255,29,2200,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(256,29,2201,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(257,29,2202,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(258,29,2203,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(259,29,2204,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(260,29,2205,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(261,29,2206,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(262,29,2207,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(263,29,2208,1,1,'2022-10-01 18:44:33','2022-10-01 18:44:33'),(264,30,2138,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(265,30,2139,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(266,30,2140,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(267,30,2141,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(268,30,2142,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(269,30,2143,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(270,30,2144,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(271,30,2145,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(272,30,2146,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(273,30,2147,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(274,30,2148,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(275,30,2149,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(276,30,2150,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(277,30,2151,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(278,30,2152,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(279,30,2153,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(280,30,2154,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(281,30,2155,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(282,30,2156,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(283,30,2157,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(284,30,2158,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(285,30,2159,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(286,30,2160,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(287,30,2161,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(288,30,2162,1,1,'2022-10-01 18:48:34','2022-10-01 18:48:34'),(289,30,2163,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(290,30,2164,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(291,30,2165,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(292,30,2166,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(293,30,2167,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(294,30,2168,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(295,30,2169,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(296,30,2170,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(297,30,2171,1,1,'2022-10-01 18:48:44','2022-10-01 18:48:44'),(298,31,2209,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(299,31,2210,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(300,31,2211,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(301,31,2212,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(302,31,2213,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(303,31,2214,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(304,31,2215,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(305,31,2216,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(306,31,2217,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(307,31,2218,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(308,31,2219,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(309,31,2220,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(310,31,2221,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(311,31,2222,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(312,31,2223,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(313,31,2224,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(314,31,2225,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(315,31,2226,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(316,31,2227,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(317,31,2228,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(318,31,2229,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(319,31,2230,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(320,31,2231,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(321,31,2232,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(322,31,2233,1,1,'2022-10-01 18:49:17','2022-10-01 18:49:17'),(323,31,2234,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(324,31,2235,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(325,31,2236,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(326,31,2237,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(327,31,2238,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(328,31,2239,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(329,31,2240,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(330,31,2241,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(331,31,2242,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(332,31,2243,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28'),(333,31,2244,1,1,'2022-10-01 18:49:28','2022-10-01 18:49:28');
/*!40000 ALTER TABLE `student_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_incidents`
--

DROP TABLE IF EXISTS `student_incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_incidents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `incident` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attitude_item` enum('responsibility','honest','mutual_cooperation','self_confident','discipline') COLLATE utf8mb4_unicode_ci NOT NULL,
  `attitude_value` enum('positive','negative') COLLATE utf8mb4_unicode_ci NOT NULL,
  `follow_up` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_incidents_course_id_foreign` (`course_id`),
  KEY `student_incidents_student_id_foreign` (`student_id`),
  CONSTRAINT `student_incidents_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `student_incidents_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_incidents`
--

LOCK TABLES `student_incidents` WRITE;
/*!40000 ALTER TABLE `student_incidents` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_incidents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `major_id` bigint(20) unsigned NOT NULL,
  `uid` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_number` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthplace` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_phone_number` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `students_uid_unique` (`uid`),
  UNIQUE KEY `students_identity_number_unique` (`identity_number`),
  UNIQUE KEY `students_email_unique` (`email`),
  KEY `students_major_id_foreign` (`major_id`),
  CONSTRAINT `students_major_id_foreign` FOREIGN KEY (`major_id`) REFERENCES `majors` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2245 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,1,'a1b2c3d4','1710110001','Ridho Pijak Imana','male','Banyuwangi','2002-01-02','ridho@gmail.com','085635425635','087635524516','default.png','Banyuwangi',1,'2022-09-15 01:06:39','2022-04-05 06:07:33','2022-09-15 01:06:39'),(2,1,'b2c3d4e5','1710110002','Sindy Rahayu','female','Malang','2002-01-08','sindy@gmail.com','085635425635','087635524516','default.png','Rogojampi',1,'2022-09-15 01:06:39','2022-04-05 06:07:33','2022-09-15 01:06:39'),(3,1,'c3d4e5f6','1710110003','Dimas Anggara','male','Banyuwangi','2002-11-01','dimas@gmail.com','085635425635','087635524516','default.png','Songgon',1,'2022-09-15 01:06:39','2022-04-05 06:07:33','2022-09-15 01:06:39'),(4,2,'d4e5f6g7','1710110004','Edy Saputra','male','Jember','2002-09-12','edy@gmail.com','085635425635','087635524516','default.png','Songgon',1,'2022-09-15 01:06:40','2022-04-05 06:07:33','2022-09-15 01:06:40'),(5,2,'e5f6g7h8','1710110005','Niki Lestari','female','Banyuwangi','2002-03-26','niki@gmail.com','085635425635','087635524516','default.png','Blimbingsari',1,'2022-09-15 01:06:40','2022-04-05 06:07:33','2022-09-15 01:06:40'),(6,3,'bc3d4e5f6','1710110006','Riko Darmawan','male','jember','2001-05-27','riko@gmail.com','085635425635','087635524516','default.png','Banyuwangi',1,'2022-09-15 01:06:40','2022-04-05 06:07:33','2022-09-15 01:06:40'),(7,7,'hKfzYJZuMWfcRuOmaMUuJAI4z3ZiKv','215211','Siswa 1','male','Cluring','2004-07-28','siswa@gmail.com','-','085237516017','default.png','Cluring',1,NULL,'2022-04-06 19:30:20','2022-04-07 01:17:06'),(8,7,'4TBdRQ5Q7B2jsghmwPvodZL7shwknA','215212','Siswa 2','male','Cluring','2006-04-01','siswa2@gmail.com','-','-','default.png','Cluring',1,'2022-09-15 01:06:40','2022-04-07 13:50:15','2022-09-15 01:06:40'),(9,7,'2KL0nVBtHlz6SItGeuK0NqnLpJ3SIH','215213','Siswa 3','male','Cluring','2006-01-01','siswa3@gmail.com','-','-','default.png','-',1,'2022-09-15 01:06:40','2022-04-07 13:51:03','2022-09-15 01:06:40'),(1920,10,'cNN4Zp2bAiq8C5EIRN8JBo18NTTFQB','6317','AGIL WIRA SAMUDRA','male','Banyuwangi','1970-01-01','6317@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:17:57','2022-10-01 18:17:57'),(1921,10,'Lytkm7iXrkNlNUH8mWbWExBpWOTgSS','6326','ALDYAN BY MAULANA','male','Banyuwangi','1970-01-01','6326@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:17:57','2022-10-01 18:17:57'),(1922,10,'hM8DBpPDozIsFASYa2UILqTgiOpEqU','6333','ANANDA TYO PRASETYA','male','Banyuwangi','1970-01-01','6333@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:02','2022-10-01 18:30:02'),(1923,10,'AAwReYnE5XM3KzZi5CUQDLlgsRe2N2','6339','ANGELA JESSICA AMANDA PANDELAKI','female','Banyuwangi','1970-01-01','6339@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:02','2022-10-01 18:30:02'),(1924,10,'cRRXMiNFVonUXqx6vHJCb4JozbAZMZ','6349','ARYA MIKO NUGRAHA','male','Banyuwangi','1970-01-01','6349@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:02','2022-10-01 18:30:02'),(1925,10,'AH4Nyt4FcMiCqHNDqVVnQHiTODvCEC','6350','ARYA RAMADHANI','male','Banyuwangi','1970-01-01','6350@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:03','2022-10-01 19:26:40'),(1926,10,'EYdmTNbLbxK18zaVlpgExAlfVRlYj4','6378','CYKA ULANSARI','female','Banyuwangi','1970-01-01','6378@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:03','2022-10-01 18:30:03'),(1927,10,'bQ7LklN0OefE3WQILstGGMHENN5qVH','6379','DAFA ALFARIZI','male','Banyuwangi','1970-01-01','6379@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:03','2022-10-01 18:30:03'),(1928,10,'6UzxYn40rdGM3SSpwyJmVxVeFwqNH1','6388','DESTA DWI PRATIWI','female','Banyuwangi','1970-01-01','6388@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:04','2022-10-01 18:30:04'),(1929,10,'Pd72dND0QrCrVkEpXfwvW8rId39jnR','6390','DESY NATASYA WILONA','female','Banyuwangi','1970-01-01','6390@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:04','2022-10-01 18:30:04'),(1930,10,'wZXEgra8gH9tZncFMCUUvGe0ELUsip','6397','DIAH PRAFITA PUTRI','female','Banyuwangi','1970-01-01','6397@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1931,10,'JQt8SoR9L1gObPzzx5iI2RZwReMzP1','6406','DIMAS CAHYO MENTARI','male','Banyuwangi','1970-01-01','6406@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1932,10,'q9ijl6pQpYumT45S6MIaJj4Mtr82Hn','6409','DINDA AYU TRI MAULIDDINA','female','Banyuwangi','1970-01-01','6409@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1933,10,'qIJ8WNmRYa7EisBUe13IFUwIFAFyGh','6420','ELGA DAYU PERMANA','male','Banyuwangi','1970-01-01','6420@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:06','2022-10-01 18:30:06'),(1934,10,'elUr14B5lqN6JSiS1a7Vva6nyX4L2D','6421','ELGA MAULIDIA AKBARI','female','Banyuwangi','1970-01-01','6421@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:06','2022-10-01 18:30:06'),(1935,10,'6GLjNC39JsoGgpPKp9pIun6uRZLv8y','6434','FAUZAN ISZAQI PUTRA','male','Banyuwangi','1970-01-01','6434@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1936,10,'lPNYBEt0JdP0YC3PnuUPnmJfG1joQG','6435','FAZHRI FAJAR PRIBADI','male','Banyuwangi','1970-01-01','6435@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1937,10,'oxYd3IWOQBXvQWct8PWrCRKd4Abq3l','6442','FERDION KUSENA LOBAN','male','Banyuwangi','1970-01-01','6442@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1938,10,'ifGE7xdhhv4mgx17oakeAyXsWX6cFm','6443','FINKY YUAN EKA SYAHPUTRI','female','Banyuwangi','1970-01-01','6443@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1939,10,'Jl2NQCWZzr6R5tRlrCynhB4qUVcjuq','6446','FRIZA CAHYA MECA','male','Banyuwangi','1970-01-01','6446@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1940,10,'Tt3hPnE5asE3eeEv73ccWSW5Z8Ywva','6449','GALUH ADAM DARIUS','male','Banyuwangi','1970-01-01','6449@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1941,10,'uRwCiVPBmcCvRUkCvMbXDOb4F3Nbjt','6452','GULAM AHMAD FIRDAUS','male','Banyuwangi','1970-01-01','6452@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:09','2022-10-01 18:30:09'),(1942,10,'UkwTf5JZYGFLuCJjSoGcSazPmkcmbi','6456','IFAN ADE YUDHA','male','Banyuwangi','1970-01-01','6456@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:09','2022-10-01 18:30:09'),(1943,10,'lYKBW2OwI6mcXFCChw1UsyewuW2uR5','6461','INTAN BERLIANA PUTRI','female','Banyuwangi','1970-01-01','6461@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1944,10,'lQpJq2k5KdmC71EfFtgw5NVt0DN7iC','6488','M. HAKAM HILMI AL GHIFARI','male','Banyuwangi','1970-01-01','6488@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1945,10,'SDSOKnUsfj4lvDxvC7tAYMioCTkPGa','6491','M. RAFFI IRWANSYAH','male','Banyuwangi','1970-01-01','6491@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1946,10,'5sJaZkbRyEa7SnvPJFIzIYe4MxP3gb','6495','MARCELINUS ARI PRASOJO','male','Banyuwangi','1970-01-01','6495@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1947,10,'pDreeTE5OolAZT5vIEim7rMSnyPGys','6506','MOH. DIMAS KURNIAWAN','male','Banyuwangi','1970-01-01','6506@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1948,10,'LZFgaELK2v5WhPkLovsAD5gAFFB9Wy','6516','MUH. QOHHARAFA ANANDA ROSANO','male','Banyuwangi','1970-01-01','6516@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1949,10,'lbsLoTvByYQW8wJKNUgspwOusrWtw2','6523','MUHAMMAD NAREL MAHENDRASYAH','male','Banyuwangi','1970-01-01','6523@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:12','2022-10-01 18:30:12'),(1950,10,'C8gsdKLzD0Hal9OjjGKKbbnu7OJea4','6552','NUR DIANA ARIF','female','Banyuwangi','1970-01-01','6552@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:12','2022-10-01 18:30:12'),(1951,10,'SybWxoEq10phXpjCxdZXXxro9gdYfo','6553','NURANI FANNAZA ZULQAIRIN','female','Banyuwangi','1970-01-01','6553@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:13','2022-10-01 18:30:13'),(1952,10,'f0hOFaQC24NIZMptiyakFbfPGXJn05','6560','PUTRI DEWI SEPTIANA ','female','Banyuwangi','1970-01-01','6560@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:13','2022-10-01 18:30:13'),(1953,10,'yGzE2670V7Yi0MMuQZ0C7N9DedzQRl','6583','RIFQI ANGGARA PUTRA','male','Banyuwangi','1970-01-01','6583@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:15','2022-10-01 18:30:15'),(1954,10,'pSBSNvo7gxjOIacOPPc8w7sMHtez1P','6612','TALITA BERLIANA KINARJO','female','Banyuwangi','1970-01-01','6612@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1955,10,'GLHJIH48ipjgyU9j3ogGmaypBVcYuc','6627','YOMATRINANDA BAGUS MAHARDIKA','male','Banyuwangi','1970-01-01','6627@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1956,10,'O26e8rT4AB5BfB6emvKomnL0mMZWO1','6629','ZANUBA QOTRUN NAZA','female','Banyuwangi','1970-01-01','6629@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1957,11,'kAcWCZEPsObDTxF8UOhWzO7v4gJ3HH','6312','ADINDA ARUM KIRANA','female','Banyuwangi','1970-01-01','6312@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1958,11,'MYqZvtARyvbMMvFcNbVA4NkLSBMk1D','6331','AMALIA NUR AZIZAH','female','Banyuwangi','1970-01-01','6331@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1959,11,'OWDKNN0WUKC5h5X35D9uqtB1p97sGw','6351','ARYA RIZKI SAPUTRA','male','Banyuwangi','1970-01-01','6351@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1960,11,'3uyAI4j2W3n7V9OUDSbmGYH3bgYd9N','6358','AYLA AFKARINA PUTRI','female','Banyuwangi','1970-01-01','6358@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:18','2022-10-01 18:30:18'),(1961,11,'di9TpUYi19eE6TuWnn2HjRdzmhZziR','6369','CAROLIN DAVISA ZAHRA ARIFIN','female','Banyuwangi','1970-01-01','6369@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:18','2022-10-01 18:30:18'),(1962,11,'XXtEeZM9hUvlhwOaRnVRjZODr1tiWQ','6380','DANIA MAHARANI','female','Banyuwangi','1970-01-01','6380@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1963,11,'ROeTrDsRcjZDriddYR4gEWhtpjB2x2','6395','DEWI AYU WULANDARI','female','Banyuwangi','1970-01-01','6395@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1964,11,'cjlGT5HJDL5WIEyYvXdiCEdGPSYGxs','6398','DIAN DUTA CANDRA MARTHA','female','Banyuwangi','1970-01-01','6398@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1965,11,'gNAuMjcJVtUuAriTV7z6SZjovydllu','6408','DIMAS PRAMUDYA WICAKSANA','male','Banyuwangi','1970-01-01','6408@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:20','2022-10-01 18:30:20'),(1966,11,'1CAZRBoJiJhYcdztvR2GGPNCTf3EpH','6413','DITA FEBRIYANTI','female','Banyuwangi','1970-01-01','6413@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:20','2022-10-01 18:30:20'),(1967,11,'jFREzBl6FMnQZTYd1vlJEQCH3K0BZW','6428','EVY RINDA SETYOWATI','female','Banyuwangi','1970-01-01','6428@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1968,11,'DmGlucPmHLXKumqWVTqcy6IdQwMgQG','6436','FAZRIN RAHMA ANGGRAINY','female','Banyuwangi','1970-01-01','6436@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1969,11,'Lvz03iY3Uos8jXEriYCmU9nVMrNpPf','6437','FEBRIAN NANTA PRAYOGA','male','Banyuwangi','1970-01-01','6437@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1970,11,'3t27NWQxbiCFjMLWPaVDC97fy7ckww','6448','GADIS FEBRIYANTI','female','Banyuwangi','1970-01-01','6448@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1971,11,'BGEYOjkp3tsZ0XBiUybUr1txlCpq1T','6463','JENI RIZKIA AMANDA','female','Banyuwangi','1970-01-01','6463@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1972,11,'tYB4OEeBGbB5h99XSqyv0zaawTrB7r','6469','KARINIA DEWI','female','Banyuwangi','1970-01-01','6469@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1973,11,'Kuuajlss735BB7nonbHMNfKJe18FQV','6477','KHANZA LAURA MAULIDIA','female','Banyuwangi','1970-01-01','6477@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:23','2022-10-01 18:30:23'),(1974,11,'mtclIKWvA5tiw4TwJHxQBLoc8XWd5f','6479','KHARISMA SUKMA AYU','female','Banyuwangi','1970-01-01','6479@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:23','2022-10-01 18:30:23'),(1975,11,'KjhKrvZFFXsviqzimGD1CH0HgCeXtf','6482','KIRANA CINTA LESTARI','female','Banyuwangi','1970-01-01','6482@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1976,11,'luwfup2bmv5dv2bEzsn6YPAySB7oC3','6484','LIAN BINTARA NUSANTARA','female','Banyuwangi','1970-01-01','6484@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1977,11,'RuLwNc4DcOyZ8uTuY01VFJAOypicMN','6501','MEY LIANA FEBRIANTI','female','Banyuwangi','1970-01-01','6501@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1978,11,'LYW0D3RofueSwZU4IcZFVZBvN8NBEx','6511','MOHAMMAD IRSYAD FAIZ SAMSUDIN','male','Banyuwangi','1970-01-01','6511@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:25','2022-10-01 18:30:25'),(1979,11,'T34wJFvPywbRD2dd6ejb4jDrvnHpbV','6520','MUHAMMAD FARHAN SYARIF HIDAYAT','male','Banyuwangi','1970-01-01','6520@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:25','2022-10-01 18:30:25'),(1980,11,'qnsoFuyYzeohiIHC0140jkDJmOELjo','6526','MUSTHOFA ALI SUBKHAN','male','Banyuwangi','1970-01-01','6526@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1981,11,'c2IvkUgko6WxUIBXKU4QPYIFwEjbeY','6528','MUTIARA TIFFANY RAMADHAN','female','Banyuwangi','1970-01-01','6528@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1982,11,'xkmvbEyBL9NBL1aNVUR7FiJAkcd42F','6535','NAILA ZAHRA PRASETIA','female','Banyuwangi','1970-01-01','6535@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1983,11,'lk4KD63ZvboRrMuDxdweWqZVdTsXbg','6541','NAZILA HUROH','female','Banyuwangi','1970-01-01','6541@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1984,11,'ebB2ZA1Cf1tFdLrdb3GQDOJr3rekWX','6545','NENSY MEIKA','female','Banyuwangi','1970-01-01','6545@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1985,11,'xdx8FNecb9FFJLHoU6SLCBkMMfcYXd','6557','PUJI RAHAYU','female','Banyuwangi','1970-01-01','6557@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1986,11,'JjFbWKTBP4aRambTgVFqDDd7lzk1Jl','6564','RAHMA IMROATI','female','Banyuwangi','1970-01-01','6564@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:28','2022-10-01 18:30:28'),(1987,11,'2lALyCXciohRKYQT5XbeGkiOvsIQKM','6572','RENDY DAVA SYAHPUTRA','male','Banyuwangi','1970-01-01','6572@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:28','2022-10-01 18:30:28'),(1988,11,'UDLKm9U5krvAG4Ahmwutda9oTaN8CD','6589','RIVA INESTA FURY','female','Banyuwangi','1970-01-01','6589@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1989,11,'uvx77S9WXn9irJuOid1fW7aFWLXViN','6596','SALWA EKA PUTRI','female','Banyuwangi','1970-01-01','6596@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1990,11,'EJhI9GtKMA3IFcoCxhp314YF3JgWIF','6615','TIRTO AJI PAMUNGKAS','male','Banyuwangi','1970-01-01','6615@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1991,11,'L8Rw8RNGsGfAoj1kmxFNlFL7kVHdMk','6616','TRENNYA SAVANA ARDFIA PUTRI','female','Banyuwangi','1970-01-01','6616@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:30','2022-10-01 18:30:30'),(1992,11,'S4j2jUXWSgD3uifOMLC7UtuimQkUez','6621','VIA CHERIL AS ZAHRA','female','Banyuwangi','1970-01-01','6621@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:30','2022-10-01 18:30:30'),(1993,12,'eVAm6hK9RGVlkVFNpXKIbisrGR7Z0Q','6328','ALFIA USTOJIK','female','Banyuwangi','1970-01-01','6328@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1994,12,'xzBpIXTN75qzOKRXtpjpas7c0FKnhk','6334','ANARGYA LUNANAIYA ANJANI','female','Banyuwangi','1970-01-01','6334@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1995,12,'BLUq58fzijsRW4Ex4AVBtYa1A0N0Dx','6341','ANGGUN NANDA PAMUNGKAS','female','Banyuwangi','1970-01-01','6341@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1996,12,'ghtSPQ9SGNjdCB1b5LfDrdNoSyM9Fr','6345','ARINDA AGUSTINA','female','Banyuwangi','1970-01-01','6345@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1997,12,'KIeNCJ0rD2OeCRY2WAT40zEDKhykth','6352','AULIA DWI YANTI','female','Banyuwangi','1970-01-01','6352@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1998,12,'JRyBJsouAIev9h15EDK5QG5xpBItA4','6355','AURA DHATU NINDYAATMAJA','female','Banyuwangi','1970-01-01','6355@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1999,12,'GIf7cGZkSSsjhbhQbDgJgK8kEobVEI','6363','BIMA SETYRA PUTRA','male','Banyuwangi','1970-01-01','6363@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:33','2022-10-01 18:30:33'),(2000,12,'CMdVTAYBEpnjtMHGGS7M6RxRVjaikz','6372','CHINTA APRILIANI','female','Banyuwangi','1970-01-01','6372@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:33','2022-10-01 18:30:33'),(2001,12,'7Q9GDVaR42FAjSMiFy9AhUxOlPRkJx','6393','DEVI VANIA MAHARANI','female','Banyuwangi','1970-01-01','6393@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2002,12,'sHlhgItyQjwNhcEaj4LuQE4GG6ZNTk','6396','DHANI SAPUTRA','male','Banyuwangi','1970-01-01','6396@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2003,12,'oWkzOz5B7gusNknF33MuQlQXt4JoY7','6405','DILA SABILA PUTRI','female','Banyuwangi','1970-01-01','6405@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2004,12,'9agegb5q2gYTRiuQaxDL0uDc4dLZeu','6411','DINY ALVEIRA ANGGRAINY','female','Banyuwangi','1970-01-01','6411@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2005,12,'I3WzkBG2sq7mEYfHz819ClS9hAbGDP','6415','DUFAN ARIL PRASETYO','male','Banyuwangi','1970-01-01','6415@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2006,12,'2gvs14HUtyHmpeTkOw5Nh7RAVm9nEX','6433','FARRADIA PUTRI AZRIETA','female','Banyuwangi','1970-01-01','6433@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2007,12,'vgUYeUQKAmbeuE95ahalfpPn7NLKzT','6455','HANCEN AZZAINSON','male','Banyuwangi','1970-01-01','6455@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:36','2022-10-01 18:30:36'),(2008,12,'W72HRyrjWyBE3MWFroAr2qqcRWcb7b','6458','IMA AIROH','female','Banyuwangi','1970-01-01','6458@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:36','2022-10-01 18:30:36'),(2009,12,'oxNO1WfpOwdnzTFSLJc0hSNkL5uVeZ','6466','KANAYA PUTRI ZACSKYA','female','Banyuwangi','1970-01-01','6466@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2010,12,'VcbrKP8nDulTzYdC60cPzCCN8gMvmh','6474','KEYSYA REVINDHIKA KURNIAWAN','female','Banyuwangi','1970-01-01','6474@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2011,12,'AfujjEYRzUO2bfbqbLpLthRHFL1NoR','6504','MOCH. RIFKI ADE PRAMADAN','male','Banyuwangi','1970-01-01','6504@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2012,12,'J17Df3DSEpJdQODZKpcC8HWPfGFINf','6507','MOH. ROHMI HILMAN MUFADDOL','male','Banyuwangi','1970-01-01','6507@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:38','2022-10-01 18:30:38'),(2013,12,'npLsiqr6Bq4hKsLkWa66egk1gPklBf','6522','MUHAMMAD HISYAM DWI .S','male','Banyuwangi','1970-01-01','6522@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:38','2022-10-01 18:30:38'),(2014,12,'vy4GoXfkcKiRSEI388XGDKMXekXzVj','6527','MUTIA JINGGA AZZAHRA','female','Banyuwangi','1970-01-01','6527@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2015,12,'l6shOsWMiUwvS5jdK0LSQQKfcWjeG0','6533','NADINE ASKA AULIAINI','female','Banyuwangi','1970-01-01','6533@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2016,12,'bzmPVv18rlmvAM1UtkKNIPTIARdUY3','6544','NAZWA MELANI KUSUMA PUTRI','female','Banyuwangi','1970-01-01','6544@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2017,12,'wJNF7PyBB7eeZqrzgjziswaHi47kqp','6548','NILA FIRDAUZI NUZULA','female','Banyuwangi','1970-01-01','6548@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2018,12,'T8g2TkQwi84CovDUcJzp5HbAk8yoZS','6559','PUTRI AZAHRA SOFIA ANGGRAINI','female','Banyuwangi','1970-01-01','6559@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2019,12,'9ZqeWMfOukqkAA69AanlOEurwyPbve','6563','RAHAYU DESTRIANI','female','Banyuwangi','1970-01-01','6563@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2020,12,'E3KAPNMKx73AF3lLCVVcNirBRBuxPb','6565','RAISYA PUTRI ELVINDA RULLY','female','Banyuwangi','1970-01-01','6565@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:41','2022-10-01 18:30:41'),(2021,12,'TZLLS3hfNFaf6ifojbqf6iUxHEnft4','6566','RASTHY SHARLA NURFADILLAH. S','female','Banyuwangi','1970-01-01','6566@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:41','2022-10-01 18:30:41'),(2022,12,'yn7kg8l9RfLEQZ8h4vuzowHgRzKW8y','6571','RENA AULIA IRIANI','female','Banyuwangi','1970-01-01','6571@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2023,12,'CTc0VC9jpKgWoEuwEGKd4viWZLBdeZ','6592','RYZA SAVANA PUTRA','male','Banyuwangi','1970-01-01','6592@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2024,12,'quElvJmvXGemzdaZPWQrAdZVC6xUM0','6594','SAFNA DEWI MARIYAM','female','Banyuwangi','1970-01-01','6594@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2025,12,'PQiiKO6dltFe9SNZn6eD2kqar2eKhl','6614','TIARA AL HIKMAH','female','Banyuwangi','1970-01-01','6614@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:43','2022-10-01 18:30:43'),(2026,12,'zgKEyT4tTa9V0Y34srNxHARwehsUV6','6620','TYA RISKI AMALIA','female','Banyuwangi','1970-01-01','6620@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:43','2022-10-01 18:30:43'),(2027,12,'0ePBzUxXwgzRHQANX9JYFAcpAHHIa4','6630','ZAQIA AGASSY','female','Banyuwangi','1970-01-01','6630@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2028,13,'bHPIHMPnwHKPAND8uYaijCAoRPCQWv','6308','ACHMAD FERINO YUDHA HARIYANTO','male','Banyuwangi','1970-01-01','6308@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2029,13,'bysnCPGvlQDVVRga1ErN0vmbfifZYJ','6316','AFRIZA JULIAN ADITYA','male','Banyuwangi','1970-01-01','6316@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2030,13,'9xj4gqDZrNG08kZw0Q5c3zvbVCHYEE','6319','AGUNG ULI ARTA','male','Banyuwangi','1970-01-01','6319@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:45','2022-10-01 18:30:45'),(2031,13,'olYLQ9ILQZTRc6cawMhF9xJxl8z1U2','6320','AHMAD SHOFA MUBAROK','male','Banyuwangi','1970-01-01','6320@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:45','2022-10-01 18:30:45'),(2032,13,'AAOnVNkcltz33S6y31xdv0WG2E0erL','6335','ANDINI DWI MULYANI','female','Banyuwangi','1970-01-01','6335@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2033,13,'ur3M8imhIfqLEpPYJkrMii9vnaN1F6','6337','ANDRA ADI PRAKASA','male','Banyuwangi','1970-01-01','6337@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2034,13,'tsFO9yE6J0BOEE583xIFbHZNQoLu3z','6338','ANDREAS SUGIARTO ADMOJO','male','Banyuwangi','1970-01-01','6338@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2035,13,'yNXE2acw3mZO5NoIKJxlUYTCCkqMx1','6353','AULIA MIFTA\'UL ARZAK ','female','Banyuwangi','1970-01-01','6353@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2036,13,'MfekmGMvqeOz5tgffbYdpL4ekblE1K','6361','BENY NAUFAL SUKMA WANTA','male','Banyuwangi','1970-01-01','6361@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2037,13,'SQM29yV3ZidpVo2pFBwftSl2lFDHJM','6365','BUNGA MAULIDIA PRATIWI','female','Banyuwangi','1970-01-01','6365@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2038,13,'nhX04UPY1mHn0JbHPeJ0GqkhmOTIiQ','6375','CINTA APRERIDA PUTRI','female','Banyuwangi','1970-01-01','6375@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:48','2022-10-01 18:30:48'),(2039,13,'fF7oG4YTdXqCgWum6KNId0CscdUEIm','6381','DANU DWI PUTRA FERDIANSYAH','male','Banyuwangi','1970-01-01','6381@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:48','2022-10-01 18:30:48'),(2040,13,'hnRhOkFIKofdcPVe9urqest2zeXnw1','6410','DINDA EKA FEBRIYANTI','female','Banyuwangi','1970-01-01','6410@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2041,13,'Gsa4hwWqMjKpmoBrDJFqMhkzVUIGj5','6416','DWI RINDRAHADI KHUSZUMAH WARDANA','male','Banyuwangi','1970-01-01','6416@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2042,13,'6TBVK1MveSxcPgOw7Fw0vhBr5jaN9B','6424','ERIANA DWI NIRWANA ','female','Banyuwangi','1970-01-01','6424@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2043,13,'Q5cEYMfbFclLV94AEUVQf3MXm8SqI6','6430','FAREL BAYU SASMITO','male','Banyuwangi','1970-01-01','6430@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:50','2022-10-01 18:30:50'),(2044,13,'dh5haT6uB7WTxoRIOH6aVCZPcw6SX2','6441','FELISYA SHERLY NATHANIELA','female','Banyuwangi','1970-01-01','6441@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:50','2022-10-01 18:30:50'),(2045,13,'QOwE5fN84kxQbwKQOA397s1ZeIPTYu','6445','FIRDAUS GHIFARI ARAFAT FAUZAN','male','Banyuwangi','1970-01-01','6445@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2046,13,'jfCsacCVevxOBjwkEo66RuhU5U7S2g','6457','ILHAM ARIF FAHROZI','male','Banyuwangi','1970-01-01','6457@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2047,13,'56s5MnUOwGDkSqTCoSNIYgH0iVmVRX','6467','KANIA RAMADHANI','female','Banyuwangi','1970-01-01','6467@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2048,13,'yxGsKbYwal66LoGtGnuoAlwKKxA2cR','6473','KEYSHA SILSABELLA RAHMA','female','Banyuwangi','1970-01-01','6473@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2049,13,'OjdJGLq5tRV0CCLuFiGchbPAqiyiSm','6476','KHAIRUNISA LUTFIAH SALMA','female','Banyuwangi','1970-01-01','6476@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2050,13,'6CQCGKUo4oog77EKVLd8UVUuxK4VkH','6486','LOVYORA ASMODIWATI PUTRI','female','Banyuwangi','1970-01-01','6486@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2051,13,'E10OcuAhMxjxe70Vg2ZsmbqUbIA0YM','6496','MARSYA SAREN','female','Banyuwangi','1970-01-01','6496@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:53','2022-10-01 18:30:53'),(2052,13,'HhFZnQ0YTv6Ak4cpHoSdunbnocYlnr','6503','MOCH ERVANDRA RIZQI AKBARI','male','Banyuwangi','1970-01-01','6503@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:53','2022-10-01 18:30:53'),(2053,13,'07PqDLCCNn8WdrETrTMObsGDWWXJlX','6508','MOH. WILLY ALDI YANTO','male','Banyuwangi','1970-01-01','6508@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2054,13,'Dhmhhfel3WSbWI4m2HNJy7zNew8W3a','6513','MOHAMMAD TEGAS DWINANDA KURNIAWAN','male','Banyuwangi','1970-01-01','6513@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2055,13,'rof2dO681km4L2Fe0Uvx5ztAC6rEUi','6517','MUHAMAT IFAN MAULANA','male','Banyuwangi','1970-01-01','6517@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2056,13,'anYOlxPgqHYkr4rvit1p5z4IdR2uuX','6518','MUHAMMAD CHELVIN ALAMSYAH','male','Banyuwangi','1970-01-01','6518@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2057,13,'CufqHs2jiaW5Qqqzja61JXXW8lqwHf','6519','MUHAMMAD DAFFA FIRDAUS','male','Banyuwangi','1970-01-01','6519@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2058,13,'eZvqa4PmkOiMWaVpPRmWEwnmcsGXbX','6521','MUHAMMAD FERNANDO DWI PUTRA','male','Banyuwangi','1970-01-01','6521@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2059,13,'CGUAUvNiZ0AymKzM9MqJQUfZZIgqTL','6524','MUHAMMAD REHAN DANUWARTA','male','Banyuwangi','1970-01-01','6524@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:56','2022-10-01 18:30:56'),(2060,13,'rhJbTi0MhecHRUYBrMlXolJkE9KRCv','6567','RASYA AIDIL CITRA AULIA','female','Banyuwangi','1970-01-01','6567@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:56','2022-10-01 18:30:56'),(2061,13,'ZKpNLdfZwDzqvJSGpTEOnlyb1fmArN','6577','REZA ALAMSYAH','male','Banyuwangi','1970-01-01','6577@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2062,13,'knKOD0f8AG0kzC7sxvzSxNgBzjY0sH','6598','SATRIA FITRIAN ARIADI','male','Banyuwangi','1970-01-01','6598@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2063,13,'NQ0ZEvbsKqhT7Liusqh5GEVQWTGkRl','6604','SHERA PUTRI MEYLANI','female','Banyuwangi','1970-01-01','6604@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2064,13,'CHxTLcoAQkVqPAwDwZJZyVM1M4KDI4','6622','VICKY BASID SADEWA','male','Banyuwangi','1970-01-01','6622@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:58','2022-10-01 18:30:58'),(2065,14,'3TOl3wctTHyY2a5FxshVCD3D54bQzj','6313','ADYAKSA YAHYA PRAESA','male','Banyuwangi','1970-01-01','6313@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:58','2022-10-01 18:30:58'),(2066,14,'vDmh6PWoBA8pvlxoz0weP8NGDcV4z7','6315','AFIKA NUR FITRIA','female','Banyuwangi','1970-01-01','6315@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:59','2022-10-01 18:30:59'),(2067,14,'rdRQvh9qzw4ge1AlqjZMkoS34brFBy','6324','AISYAH AZAHRA ISABEL PO','female','Banyuwangi','1970-01-01','6324@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:30:59','2022-10-01 18:30:59'),(2068,14,'KIalnADxyjPeqL0E7IJxhrM3mR9hqM','6344','ARIEF RAHMAN HAKIM','male','Banyuwangi','1970-01-01','6344@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2069,14,'w2eXYGEGqkPSwy0LNQnRTOxXrQCK9i','6356','AVRILIA DEWI PUJA ARIYANTO','female','Banyuwangi','1970-01-01','6356@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2070,14,'VmGxjBs0qV8bENuEZgGoXC1MksHbFd','6364','BINGGA SHENDYKA AYU','female','Banyuwangi','1970-01-01','6364@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2071,14,'APqaH7UlNWD3lm06HnjmhgGbm45VaF','6376','CITRA SULUNG SETYANDARA','female','Banyuwangi','1970-01-01','6376@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:01','2022-10-01 18:31:01'),(2072,14,'Lf4RnbgHkgLIdRu7qtTEbp739cATqQ','6394','DEVI YULI INDRAWATI','female','Banyuwangi','1970-01-01','6394@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:01','2022-10-01 18:31:01'),(2073,14,'cGeYEQVBrK64sI7ZhLqZmObTG6V2IQ','6400','DIANDRA WAHYU KRISTANTO','male','Banyuwangi','1970-01-01','6400@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2074,14,'6BHeJfgx8NjXT18PVwRJ4gXU0tJyYN','6403','DIKI PURNAMA','male','Banyuwangi','1970-01-01','6403@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2075,14,'j4hVat0UCy7riFoQNARuejl1DyS3DS','6425','ERICA ATHARISNA','female','Banyuwangi','1970-01-01','6425@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2076,14,'oiaIWl4dVqQaskhCX52Bz3CDaqFM8K','6431','FARENZA RISKY ANSEL','male','Banyuwangi','1970-01-01','6431@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:03','2022-10-01 18:31:03'),(2077,14,'8DOv03LYxMc8YnzsQumVoDjc9LeR5a','6440','FELISIA AYU VERDINA','female','Banyuwangi','1970-01-01','6440@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:03','2022-10-01 18:31:03'),(2078,14,'vnwZyciCk2UC2pXrRTTPh0Csf3A6lP','6450','GIGIH ADITIYA','male','Banyuwangi','1970-01-01','6450@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2079,14,'Ky9IE0gZK1J0k1yasLPC4SHKFxI43O','6454','HAFSH AL HADARIY','male','Banyuwangi','1970-01-01','6454@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2080,14,'8h9aKHX55VFqN5ckovgM4wNeckF2Zj','6462','JAMILATUS SURURIYAH','female','Banyuwangi','1970-01-01','6462@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2081,14,'TeqZ3nryJVfnd2EWj05EKmyIh0oIJ7','6485','LINDA PURNAMA SARI','female','Banyuwangi','1970-01-01','6485@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2082,14,'ePuyKhPI8hkslOHAor7l60XzPHiMAM','6505','MOH BRILIAN DWI NUGROHO','male','Banyuwangi','1970-01-01','6505@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2083,14,'cGLhPObfVaXx99mFxHlwLV4kKyCeEa','6510','MOHAMMAD ADI AGIL FATHONI','male','Banyuwangi','1970-01-01','6510@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2084,14,'0mdWLUOdVurlW5a36CDVM4OhNMmYP5','6530','NABIL DAFFA ADLI','male','Banyuwangi','1970-01-01','6530@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:06','2022-10-01 18:31:06'),(2085,14,'vz0Dou9QxxCZF4OQC38EuDRmpOr1Vd','6532','NADIA AYU SHOLEHAH','female','Banyuwangi','1970-01-01','6532@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:06','2022-10-01 18:31:06'),(2086,14,'KdymHeURdcI42GcVVZl7SvfMP1usGV','6537','NANTA SUBHA DOYO','male','Banyuwangi','1970-01-01','6537@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2087,14,'F28CZ7nQTbtLUsQGxFzPndrQxfDuSy','6546','NESYA AYU RAHMADINI','female','Banyuwangi','1970-01-01','6546@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2088,14,'xxQar42kODkF3ysyyTgeZWSk6ttaIm','6550','NIRMALA WAHYUNINGTYAS','female','Banyuwangi','1970-01-01','6550@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2089,14,'cb5gxIu6eSxW1B5l3TqzfqJoc5pQKg','6561','PUTRI YOGI BRUNIEYANTI','female','Banyuwangi','1970-01-01','6561@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:08','2022-10-01 18:31:08'),(2090,14,'90ZuJjNeSk8yLyGXwH1d8BAoxcvMI1','6573','RESTI AMELLINA','female','Banyuwangi','1970-01-01','6573@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:08','2022-10-01 18:31:08'),(2091,14,'Y20OyJNcUClTAWn4ioyMEMbhfcLO4p','6576','REYNATH KALLIO PRADAMAR','male','Banyuwangi','1970-01-01','6576@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2092,14,'wpxQZteticxNl06JARCC0Xe2Nm4hfx','6586','RISMA RAHAYU AGUSTIN','female','Banyuwangi','1970-01-01','6586@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2093,14,'6wiHVxD6XxHFWeh1nYvqoto1Ig24c5','6599','SATRIO SANJAYA DANA WINATA','male','Banyuwangi','1970-01-01','6599@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2094,14,'RNc7hhRniiipk6jXtNF2SJJya77Jbg','6602','SERLY APRILIANI','female','Banyuwangi','1970-01-01','6602@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2095,14,'WL99mS8cIbiswF0Th6t0Sv1izI5Cat','6607','SOVIA INTAN PERMATASARI','female','Banyuwangi','1970-01-01','6607@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2096,14,'Io6KSPFFOaDItnKVHuHvhTPHXiEi1d','6608','SUCI NAJWA SABILA','female','Banyuwangi','1970-01-01','6608@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2097,14,'ybHu3PuoGmKnozCnRuD59FyXpBxC7U','6613','TALITHA WAFIRANA','female','Banyuwangi','1970-01-01','6613@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:11','2022-10-01 18:31:11'),(2098,14,'3PUnnBD2T9B12TMwmgqFFjm13ZD9i2','6618','TRIA ISMA FIBRIANI','female','Banyuwangi','1970-01-01','6618@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:11','2022-10-01 18:31:11'),(2099,14,'yo2CbCnwQNCtXCBQkonzk9WvGZ04pJ','6624','VIVI OLIVIA KHODIN','female','Banyuwangi','1970-01-01','6624@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2100,14,'Xem64GBl2pvrZuR7Crayu1l2WACevJ','6632','ZUAN PRATAMA PANJIASA','male','Banyuwangi','1970-01-01','6632@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2101,15,'4FN1LaJfkTTPBFiLTdHOdKM4fPM4Mu','6314','AFIFA NUR FITRIA','female','Banyuwangi','1970-01-01','6314@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2102,15,'VLXjE8DggK73Y1uA3bnwEMHOv6wgDk','6322','AISAH FIKAYATUL APRIL LAILI','female','Banyuwangi','1970-01-01','6322@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2103,15,'FfD7YaeUTmV5r3asropmxBNGFNNDEY','6329','ALFINO ZIDAN FAIZI','male','Banyuwangi','1970-01-01','6329@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2104,15,'p0NiQMXYrNx6qJGRQafMrEMoYsbZHW','6343','APRILLIA INTAN ANDINI','female','Banyuwangi','1970-01-01','6343@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2105,15,'2mP2fTIqtqqSU6KYTIWICRqrDIDOHz','6346','ARISTA RAMADHANI','female','Banyuwangi','1970-01-01','6346@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:14','2022-10-01 18:31:14'),(2106,15,'eYMMAmqykX1iO4qH8438yZtZ1xDbqa','6348','ARYA DWI PAMUNGKAS','male','Banyuwangi','1970-01-01','6348@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:14','2022-10-01 18:31:14'),(2107,15,'SxOqAPzSZ7di6xHkMwtbC5sR2Mnfia','6354','AULIA WULAN','female','Banyuwangi','1970-01-01','6354@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2108,15,'mLdz0t3m5zR71iKxaGrWlqJk2u3q7p','6360','BAGUS AHMAD DWI KURNIAWAN','male','Banyuwangi','1970-01-01','6360@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2109,15,'sAIs0DE3Qm1XSqdkLEySpKrgTLhT3c','6374','CINDY ZAZKIA VALIZA','female','Banyuwangi','1970-01-01','6374@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2110,15,'Jy9RFbHQZI58RB4G58wdzLGMxVIZdU','6384','DELA HIDAYAH NINGRUM','female','Banyuwangi','1970-01-01','6384@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2111,15,'DDh5pmqbCrPbeA6eMkbVo0q6U9Xert','6399','DIANA PUNGKI','female','Banyuwangi','1970-01-01','6399@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2112,15,'gyRaNMqgzCeaATgT01jbFsiOKhhGWX','6402','DIFFANY NATHASS YAMSIE','female','Banyuwangi','1970-01-01','6402@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2113,15,'GLpGOzRYTUIT0FF5hCAOaqluL4xLYH','6404','DILA MARISKA','female','Banyuwangi','1970-01-01','6404@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:17','2022-10-01 18:31:17'),(2114,15,'mVTgt7Pen2rYP2dCb44szLFBpIR9xR','6412','DINY NUR QISTINA','female','Banyuwangi','1970-01-01','6412@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:17','2022-10-01 18:31:17'),(2115,15,'h4nQH4bV1wjpWeBZL6N1hsqzTVzhUE','6427','ETICO ABI GUWIRA','male','Banyuwangi','1970-01-01','6427@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:18','2022-10-01 18:31:18'),(2116,15,'loGPlu2s03SC8K7L0fLEhiVrxnRbLj','6438','FEBRIANA NUR AINI','female','Banyuwangi','1970-01-01','6438@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:18','2022-10-01 18:31:18'),(2117,15,'v3Pa3pI5l7BL6vsbslBqOMIC9htCBj','6444','FIRDA RESTI ANJAR SARI','female','Banyuwangi','1970-01-01','6444@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:18','2022-10-01 18:31:18'),(2118,15,'pVwWtm9lJ9z4oh9LN2VOYn4KZ2x2Qp','6453','GUNTUR CHANDRA LOKA ADHITYA','male','Banyuwangi','1970-01-01','6453@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2119,15,'3FOpHhiyuJJWH16RNQ8yEEbIxuimRv','6460','INDIRA PRATAMA PUTRI','female','Banyuwangi','1970-01-01','6460@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2120,15,'Xy9MaPbiB1eVBGmR7cciYB1xi1tXIK','6483','LA HAYYU LAWALATA','male','Banyuwangi','1970-01-01','6483@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2121,15,'8sIV7BlTlMd49oqEP57Mfci4lI7e3C','6487','LUVI NATASYA','female','Banyuwangi','1970-01-01','6487@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2122,15,'B5NyqpxL5k0O4VPzENlCFBYwywV8hT','6490','M. HANIF ZAMZAMI','male','Banyuwangi','1970-01-01','6490@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2123,15,'mxy4arByKPjmHmjVu61chnPrXfSv1i','6492','MAELANY KURNIA SARI','female','Banyuwangi','1970-01-01','6492@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2124,15,'FTDaO6LcW7Rnpz26Dajcx9cvtqO4qw','6512','MOHAMMAD IRSYAD IVANKA','male','Banyuwangi','1970-01-01','6512@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:21','2022-10-01 18:31:21'),(2125,15,'2GbmErmXJyL0sQsC3fCmUcfVsxhghQ','6514','MUBLIHA SALSAFIRA','female','Banyuwangi','1970-01-01','6514@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:21','2022-10-01 18:31:21'),(2126,15,'O2C0SEd2fG2IeykgllUPtrOW1DRIJz','6540','NAZALA AIYANG VIANDINI','female','Banyuwangi','1970-01-01','6540@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2127,15,'5WagzATcybDiigz3PoJXAQHzVQcptc','6549','NINDA MEILANISTI UTARI','female','Banyuwangi','1970-01-01','6549@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2128,15,'Ema9q0Wu24qUy4kQPDPkwdqaNMIc5T','6551','NOVAL TRI ARIANSYAH','male','Banyuwangi','1970-01-01','6551@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2129,15,'ZSU4I0IPPLPFFo69HpwRuWgJnt1jRF','6558','PUSPA AYU INTAN PERTIWI','female','Banyuwangi','1970-01-01','6558@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:23','2022-10-01 18:31:23'),(2130,15,'6Zns4ovfmvx7on1hqLUr054EMGbd0H','6569','RAYA STARTYA RAIHAN','male','Banyuwangi','1970-01-01','6569@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:23','2022-10-01 18:31:23'),(2131,15,'cuwDasswqrT4kqjJxpu8XSznrOZfdn','6575','REVALITA DWI DESTYA','female','Banyuwangi','1970-01-01','6575@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2132,15,'Db4leoHOY7TLPfQeIhQQJ6icArHbOj','6584','RIKHA NUR AZIZAH','female','Banyuwangi','1970-01-01','6584@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2133,15,'yuTdIJfXm0cC6xdVi6QKfIgDhjWvWV','6591','ROGAN AFDUL DAFA','male','Banyuwangi','1970-01-01','6591@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2134,15,'NqqT2IUMzkFfToKxlQyEZiv60ivFL0','6606','SINDI MAULIA PUTRI','female','Banyuwangi','1970-01-01','6606@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2135,15,'f9c5OXMJCmxPTiRyjxUKn2Rmp0RVaG','6617','TRI YULI ASTUTI','female','Banyuwangi','1970-01-01','6617@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2136,15,'UpcleDlLKTARqakfVUjxufFYyF6i8x','6619','TRIANA AYU RAHMAWATI','female','Banyuwangi','1970-01-01','6619@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2137,15,'ugMfLtmlVrCOWGVe0OjqfVwtON8dlq','6628','ZAKIYA NUR SYAFIRA','female','Banyuwangi','1970-01-01','6628@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:26','2022-10-01 18:31:26'),(2138,17,'K0sJU9Cr3AVYmtGMokuwl5pJnGFCyd','6309','ADELIA NUR AZIZAH','female','Banyuwangi','1970-01-01','6309@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:26','2022-10-01 18:31:26'),(2139,17,'4I1HmkpWrWoR0S3VIQIZLv9UHn6PGi','6327','ALETHA REVALINASYA AZZAHRA','female','Banyuwangi','1970-01-01','6327@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2140,17,'84lkUd9ASI6t035XCHAEHglj2en4Pk','6332','AMELIA RAHMAWATI','female','Banyuwangi','1970-01-01','6332@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2141,17,'LR9Lov0GRcQVDPbidqu4SKL7ixITgB','6336','ANDJANI AURA AL-ARSY','female','Banyuwangi','1970-01-01','6336@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2142,17,'jw0ug6OMXEMIvSv5oKEP91Lrbi0H8f','6340','ANGGUN AULIA AZZAHRA ','female','Banyuwangi','1970-01-01','6340@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:28','2022-10-01 18:31:28'),(2143,17,'YXCj9wlOu4iXL7s2MLSJmFdYPkVS2w','6347','ARLINA MEILA PUTRI','female','Banyuwangi','1970-01-01','6347@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:28','2022-10-01 18:31:28'),(2144,17,'abNIwyGFUVpWgvB7MpEu7i23aaCLDa','6366','CAHYA SEFTY EVA PURWANTI','female','Banyuwangi','1970-01-01','6366@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2145,17,'yY6YfZJpgLaIGtaeWfU7ILhRrIBJcG','6368','CALLISTA IRGI MAUREN OKTAVIA','female','Banyuwangi','1970-01-01','6368@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2146,17,'hsEuyzMFWAP7atKZoFX887KlQngnve','6371','CHELSEA RAHMAWATI','female','Banyuwangi','1970-01-01','6371@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2147,17,'7lMpp8R1CYBkwgTV33Iu2C0pcu93jU','6382','DAVA AJI MAULANA','male','Banyuwangi','1970-01-01','6382@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2148,17,'8QPwrU0JtMGeL2lD3bFq4woR7ehzwV','6389','DESTA NATALIA ANGGRAINI','female','Banyuwangi','1970-01-01','6389@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2149,17,'j3S9JzrjdpE6q6ZSb5a43RITrI4Wx7','6423','ELLA EKA NURLAILI','female','Banyuwangi','1970-01-01','6423@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2150,17,'h94WhkA83HshQb33W3S44nHQw60uLl','6465','JERRY PRIAYUDA','male','Banyuwangi','1970-01-01','6465@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:31','2022-10-01 18:31:31'),(2151,17,'dXg47WXwdifBirHMDM8x5G6P37WJKL','6468','KARINA DWI PUTRI CANTIKA','female','Banyuwangi','1970-01-01','6468@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:31','2022-10-01 18:31:31'),(2152,17,'3dlsABAX0oKOlSMP0JH30M8faNbrMq','6472','KEYSHA GHITA SHAKILA','female','Banyuwangi','1970-01-01','6472@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2153,17,'V1TXtGQno8c7uZ5WPP5bPvYYWjtOa2','6475','KEYZA BUNGA OLIVIA','female','Banyuwangi','1970-01-01','6475@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2154,17,'0AxggvlYt7TljYZfPUG1GPk9tCSJRP','6478','KHARISMA ANDJANI PASA PRIYANTO','female','Banyuwangi','1970-01-01','6478@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2155,17,'LQT7lvaxvYuo8ABDTz5swWyknEH6sd','6489','M. ARGA MAULANA SAPUTRA','male','Banyuwangi','1970-01-01','6489@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:33','2022-10-01 18:31:33'),(2156,17,'2bHaeaeXoJCMmoWx4YuYhyZUCCfcpU','6498','MAULIDA ANANDA SARI','female','Banyuwangi','1970-01-01','6498@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:33','2022-10-01 18:31:33'),(2157,17,'ixXNKZ0yDgYNlYN8rHtWFnWstBkYEG','6531','NABILA NUR MALA SARI','female','Banyuwangi','1970-01-01','6531@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2158,17,'0EvSiujdWgRcsnwKTY8eActW5g0Rbf','6538','NATASYA ALISIA FATEHA','female','Banyuwangi','1970-01-01','6538@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2159,17,'8j5hVDAdpFQyGYuXGAtPNrmcuJkM3t','6542','NAZRIL NAUFAL MUHAEDOR','male','Banyuwangi','1970-01-01','6542@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2160,17,'6M9yXBnJuGsY3kIvoHb18csPzNYxFo','6554','OKFI ARMANURIA AZZAHROH','female','Banyuwangi','1970-01-01','6554@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2161,17,'NX5QBPhgekklIHODhudKWSZ7COXwTP','6556','PINTARIE WAHYU BERLIAN SARIE','female','Banyuwangi','1970-01-01','6556@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2162,17,'pOEBMb3cfCaJgoEFAXUJwJmCnzKcFi','6562','RAFI MAULANA PUTRA','male','Banyuwangi','1970-01-01','6562@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2163,17,'ku9g6bEOQWXHcV2slt0d3IoJxLPseA','6578','REZA NOVA PALESTRI','female','Banyuwangi','1970-01-01','6578@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:36','2022-10-01 18:31:36'),(2164,17,'LmTAaKNKMLFi2VrqLDNUqPzEBsEDkt','6585','RISMA DAMAYANTI','female','Banyuwangi','1970-01-01','6585@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:36','2022-10-01 18:31:36'),(2165,17,'kEvDgxN84dWfP4URxR98mlF5xCPz2o','6587','RISTA AMELIA','female','Banyuwangi','1970-01-01','6587@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2166,17,'gj17tkYurFy3r3EJ4KduI8IBuO2WOu','6590','RIZMA FAUZIA UTAMI','female','Banyuwangi','1970-01-01','6590@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2167,17,'3ck0X5GZa9lY0ewfSG0aGxjcgwqluN','6595','SALSABILA ANGGRAINI','female','Banyuwangi','1970-01-01','6595@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2168,17,'K0oBf0GnDs5hIY9fdSDqdFydMLmAjV','6605','SHEVA ELHAQQI ALBAS','male','Banyuwangi','1970-01-01','6605@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:38','2022-10-01 18:31:38'),(2169,17,'KbEOnDqVKPxPiMQ54c6pSlUXLdkCqm','6609','SULTAN AL BAIHAQI','male','Banyuwangi','1970-01-01','6609@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:38','2022-10-01 18:31:38'),(2170,17,'BEybrD9CpmmsEXWhGm04Pf5P1SWaIQ','6625','WAHYU PRAKUSO','male','Banyuwangi','1970-01-01','6625@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2171,17,'y5gtvNJNnPpk6thLDQE0MbIcr0tB1s','6631','ZHORA NORIN DAVITA SARI','female','Banyuwangi','1970-01-01','6631@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2172,16,'LW0TAiLfH8PbryBmiSG1vkw0cGKZtn','6310','ADELIA PUTRI CAHYANI','female','Banyuwangi','1970-01-01','6310@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2173,16,'r1vcDtPiLW8APlMDvTDd1N3J8ivdiC','6311','ADELIA ZAHRA','female','Banyuwangi','1970-01-01','6311@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2174,16,'iw1zi4YgEyP66yoEiwU6OY1dhB59CF','6318','AGNES KALESIA ANGGI','female','Banyuwangi','1970-01-01','6318@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2175,16,'7QlPmFHZAxpby1f2QePYvSjlSxLqPR','6321','AINUN ANNISA AZZAHRA','female','Banyuwangi','1970-01-01','6321@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2176,16,'dnaPV2K4EeLDWszptUTz02VjfwhmHp','6323','AISIFAH NURAINI IKA SAPUTRI','female','Banyuwangi','1970-01-01','6323@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:41','2022-10-01 18:31:41'),(2177,16,'xpEVoaOz9c8fjGMTJYMkoVZWqSscvK','6325','ALDI RISKI SETIAWAN','male','Banyuwangi','1970-01-01','6325@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:41','2022-10-01 18:31:41'),(2178,16,'9bHbd3E5FfDCYzJdG0JuvhePhlCKBh','6357','AXCEL TIRTA FAHRIZAL','male','Banyuwangi','1970-01-01','6357@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2179,16,'kZXinD35vITE3qJV7RDrzlVeSLrGge','6370','CHANTIKA ZAHRA AZIZAH','female','Banyuwangi','1970-01-01','6370@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2180,16,'QaBUQDadaXfsKpvHxxcIIDDWXkHuPs','6377','CLAUDHINA MARTHA HARIYADI','female','Banyuwangi','1970-01-01','6377@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2181,16,'9uFZ8x0XyGtkvFpLnlKdSSgLtWICMV','6383','DEALOVA FRANSISKA','female','Banyuwangi','1970-01-01','6383@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:43','2022-10-01 18:31:43'),(2182,16,'XIlt6l3QPZeI5RoCTN6ATBYY6hbDlB','6385','DELA WULANDARI','female','Banyuwangi','1970-01-01','6385@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:43','2022-10-01 18:31:43'),(2183,16,'L8HtadAZgGHvXf2JirimJenZKhcmvd','6392','DEVI CITRA SARI','female','Banyuwangi','1970-01-01','6392@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2184,16,'GJ5WMpizqgnfySjyTe0dht2TRcDdLz','6422','ELIZA NUR NABILLAH','female','Banyuwangi','1970-01-01','6422@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2185,16,'pl26vtP63vn5yLMut91qf9L46wAFeD','6429','FAREL AGUSTIANO PRATAMA','male','Banyuwangi','1970-01-01','6429@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2186,16,'ZAjHBzuBfq0XFZGdeBWFVY4VZgTupV','6432','FARIKHA RIZQI FADILA','female','Banyuwangi','1970-01-01','6432@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2187,16,'kSy42kKFSvdXLD1h8WoXb0xo5Vyioa','6470','KEISYA MAULIA NANDITA MAWARDI','female','Banyuwangi','1970-01-01','6470@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2188,16,'lqv80nBPK6DpDnTgsWVofE6YSFXZRN','6471','KEYRA ZILLA AMELIA','female','Banyuwangi','1970-01-01','6471@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2189,16,'r0A8yweFg1q6Sl1FXyfDEBqgm8Q0d3','6480','KHILYA NAFA\'ATUS SYAFI\'I','female','Banyuwangi','1970-01-01','6480@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:46','2022-10-01 18:31:46'),(2190,16,'Ynm1UYRISck1vQANUcQBonw8rQnt1Q','6493','MAGHFIROH FITRI MAULANI','female','Banyuwangi','1970-01-01','6493@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:46','2022-10-01 18:31:46'),(2191,16,'4TEfN9suTqC5J7SvlFU8Z0sA6KNq0f','6497','MAULANA WIJAYA','male','Banyuwangi','1970-01-01','6497@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2192,16,'0nIgOnTzHV0elLyQdOApG3mL77fHlP','6499','MELDA MAULADITA','female','Banyuwangi','1970-01-01','6499@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2193,16,'rf4uBihGbWHRw6UcI7AvIxxTB8Mbcl','6500','MELINDA TWIN JEFRINA RAHMADANI','female','Banyuwangi','1970-01-01','6500@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2194,16,'pIUm86iE2tHFE6ZrySWYEbBAOci3JL','6509','MOHAMAD HUSNI RAHMADANI','male','Banyuwangi','1970-01-01','6509@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:48','2022-10-01 18:31:48'),(2195,16,'ScB8Wo8OXDB5h2vFPIQMQdQxXDp05i','6525','MUHAMMAD VINO TRI SURYA ANGGARA','male','Banyuwangi','1970-01-01','6525@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:48','2022-10-01 18:31:48'),(2196,16,'JBs6ur86J1BsyIh0icRntGpgL4WKxt','6529','MUTMAINA','female','Banyuwangi','1970-01-01','6529@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:49','2022-10-01 18:31:49'),(2197,16,'O5XfwydpjZZQXtDHFWmVdw0KLFfp31','6534','NAFIRA JULIA AZZAHRO','female','Banyuwangi','1970-01-01','6534@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:49','2022-10-01 18:31:49'),(2198,16,'jWpuCc9x9900Xajm7bgbh5UGbWjhIK','6543','NAZWA LUNA SHAFA RAIHANI','female','Banyuwangi','1970-01-01','6543@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:49','2022-10-01 18:31:49'),(2199,16,'McG7rkA38g0qiyzPvSia3lNwRw9nA6','6547','NGIZZA ULIATUNNAFISAH','female','Banyuwangi','1970-01-01','6547@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2200,16,'2JuFygpdtbWkU6WA66fLF6yc7lwkOC','6574','REVA FEBRINA NUR HABIBAH','female','Banyuwangi','1970-01-01','6574@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2201,16,'cHbnkvdJnSRrH9x1bxlMtXkTFV66dS','6579','REZI NOVA PALESTRI ','female','Banyuwangi','1970-01-01','6579@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2202,16,'5FUPB3GB3aWcKfIn1cC2szAkyHOdKM','6580','RIBI WULANDARI','female','Banyuwangi','1970-01-01','6580@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:51','2022-10-01 18:31:51'),(2203,16,'42117A1NKfponfcT0Y8Dsunmi3pkY0','6581','RIENDA NUR JEFLINA','female','Banyuwangi','1970-01-01','6581@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:51','2022-10-01 18:31:51'),(2204,16,'radG4mHrLdWThDXuCMhH6cq3ZUKA6S','6597','SAMUEL KENANDY','male','Banyuwangi','1970-01-01','6597@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2205,16,'rNcEtXUTdcYX6yY2tmyx4qLql66RYx','6603','SHENDI PUTRA','male','Banyuwangi','1970-01-01','6603@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2206,16,'2rEOP2Yv4EJ4pchHpcUtip2fvgbZcj','6611','TAHTA AYU LAZUARDINI','female','Banyuwangi','1970-01-01','6611@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2207,16,'F3TwcMap0ln54U8lrZVXBRUS8gop18','6623','VIONA LAELYKA AZIZ','female','Banyuwangi','1970-01-01','6623@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2208,16,'wYKwI5WbWleuL7n5u1TalzCKi45o7c','6626','YOFI FATMALA','female','Banyuwangi','1970-01-01','6626@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2209,18,'Kywz6E14PDyhIGdfH8Jam1dbIORtn2','6330','ALISYA ALMA ARISOM','female','Banyuwangi','1970-01-01','6330@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2210,18,'AvdbswYWILxVGE53MmClJ43jDTsw8O','6342','ANISA DINDA ANDIRA RAHMA','female','Banyuwangi','1970-01-01','6342@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:54','2022-10-01 18:31:54'),(2211,18,'sOD7QOwxm2V6E5DmACLsrpOLB3qCKL','6359','AYU DYA PRAMISWARI','female','Banyuwangi','1970-01-01','6359@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:54','2022-10-01 18:31:54'),(2212,18,'ovEWav7B9M51rwvgiIRk80S0r1ywKC','6362','BETRAN CAHYA SAPUTRA','male','Banyuwangi','1970-01-01','6362@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2213,18,'5GpiTtgCSepJKCPCszATr2aPxFg02K','6367','CALISTA JULYA SAPTA RINO','female','Banyuwangi','1970-01-01','6367@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2214,18,'CuvWqCNrltGvneXJVE9xz4YiYCTsfr','6373','CINDY ALEXA FEBRIANA','female','Banyuwangi','1970-01-01','6373@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2215,18,'lDPnQxFhWs5L1gfrzdHJlXHM6relc2','6386','DENOK MANGGARANI','female','Banyuwangi','1970-01-01','6386@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:56','2022-10-01 18:31:56'),(2216,18,'NNjX3b1MjcQfuPxnFEDr7ioHTqvrHu','6387','DERRYL AZZA MAULANA','male','Banyuwangi','1970-01-01','6387@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:56','2022-10-01 18:31:56'),(2217,18,'WW6dP0a0aSq73VhgqAJgMj7C88d2bZ','6391','DEVA YUSUF SAPUTRA ','male','Banyuwangi','1970-01-01','6391@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2218,18,'0beCdeBDsZyGD6lTZHKsJepaiT4zYF','6401','DIEMAS DWI ARDIANSYAH','male','Banyuwangi','1970-01-01','6401@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2219,18,'bLA0xf67NIoWkngNtoaEAolFcY2o05','6407','DIMAS NOVIANTO','male','Banyuwangi','1970-01-01','6407@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2220,18,'eVbm8LyCqNfPxlJlhEGSmyQkKJeXjR','6414','DIVA CITRA SARI','female','Banyuwangi','1970-01-01','6414@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2221,18,'pCrf3v7FjXPgWqAS8Q7TDWSZzq4gKt','6417','DYAS SHERINE AMUKTI','female','Banyuwangi','1970-01-01','6417@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2222,18,'Ec0AvyaVxxWC4y46zma6225HUx2wnJ','6418','DYSTA ARDELIA RAMADHANI','female','Banyuwangi','1970-01-01','6418@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2223,18,'N38DdLbTmKfx5cK4SO2fbixPYPxhU6','6419','EKSA MAXENTIA IVANA WALUYO','female','Banyuwangi','1970-01-01','6419@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:59','2022-10-01 18:31:59'),(2224,18,'ED7qXCsbjnWSIpO7rtE5667u8yvAtX','6426','ESSAFA SADWIKA ANDRIANTA','male','Banyuwangi','1970-01-01','6426@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:31:59','2022-10-01 18:31:59'),(2225,18,'A5OHMcJXLjVODEcF16EV6kBSZYjLUi','6439','FEBY PUTRI VALLENTYAS YUSUP','female','Banyuwangi','1970-01-01','6439@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2226,18,'d2MegiWozFZBVtoOhmduuqrOYyGhUt','6447','GADHIZA ZULEYKA','female','Banyuwangi','1970-01-01','6447@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2227,18,'gF8l0Q2r9Pxa4C8bu2LSkwfnTGTVfR','6451','GIGIH PRATAMA PUTRA','male','Banyuwangi','1970-01-01','6451@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2228,18,'KUHm6ztEuQcPItfu9wfEMLvCz967kK','6459','IMELDA AUDRIA D.','female','Banyuwangi','1970-01-01','6459@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:01','2022-10-01 18:32:01'),(2229,18,'0Clm3oXhGMnRZ1KScoN1nZKHStoaJS','6464','JENNY INDAH WIJAYANTI','female','Banyuwangi','1970-01-01','6464@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:01','2022-10-01 18:32:01'),(2230,18,'k1LHkX6HI5w0LF4xuh4RuJTallP4J5','6481','KIRANA BINTANG BRILLIANTNOSA D.K.J.A.','female','Banyuwangi','1970-01-01','6481@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2231,18,'GWvtN2RmKklf2crcQxd17gokAizu1E','6494','MANDA MAETA ANGGRAENI','female','Banyuwangi','1970-01-01','6494@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2232,18,'lx32ZjPM8ZXrvRI6hH1LTzCRlTqZ9V','6502','MILA SOFIANTI ARINI','female','Banyuwangi','1970-01-01','6502@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2233,18,'mFG5aGmaXS9gsaaeaVFdwJNFauBs0L','6515','MUH. FAUZAN AL HAQ DARMAWAN','male','Banyuwangi','1970-01-01','6515@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2234,18,'EgJcRuJNfU3j8t66yWh7X9nPjY84dn','6536','NANDA NAZHIFA MURIA ZHAFIR','female','Banyuwangi','1970-01-01','6536@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2235,18,'IPuNO3UV5iEjs5k5QNH7SsOK60QznO','6539','NAYLA SAKINA PUTRI','female','Banyuwangi','1970-01-01','6539@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2236,18,'czdbCz8NPjM3nkaXBuzB8Fp7ufL7KM','6555','PHANTOM MADA CHITAR','male','Banyuwangi','1970-01-01','6555@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:04','2022-10-01 18:32:04'),(2237,18,'VNFls6T2OEoDSrssQzL71QQEtMB5Gr','6568','RASYA DWI PRASTYA NINGRUM','female','Banyuwangi','1970-01-01','6568@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:04','2022-10-01 18:32:04'),(2238,18,'FsHpDG7eA3NuuBfn7NeKkDkgJNaWYU','6570','REGA JULIAN SHAFIRA','male','Banyuwangi','1970-01-01','6570@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2239,18,'evmPQMoCn7AVPl5y0WuXhALwjUmQVu','6582','RIFQA ANANDA CINTA','female','Banyuwangi','1970-01-01','6582@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2240,18,'gu98u4UiCclh8OFW4YpGkHyYsPAyYZ','6588','RITA AYU LESTARI','female','Banyuwangi','1970-01-01','6588@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2241,18,'eH6ecCaVTPrOxktwoQKIo6xdHXyMlD','6593','SAFIRA AJENG REFA CAHYANI','female','Banyuwangi','1970-01-01','6593@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2242,18,'f3bTqlB4NBhEbbtSSQQuRFqM2vYD9Q','6600','SAXENA RAKHES ARSHANDI','male','Banyuwangi','1970-01-01','6600@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2243,18,'QaqEcZOCS2Ptyu0I31vUPTpY3LUhlQ','6601','SEPTIAN WAHYU JEFRINATA','male','Banyuwangi','1970-01-01','6601@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2244,18,'dDNj9e2Jm4c4Pau68MyQcXv39FcRwZ','6610','SYALWA QOTHRUNNADA','female','Banyuwangi','1970-01-01','6610@gmail.com','0','0','default.png','Banyuwangi',1,NULL,'2022-10-01 18:32:07','2022-10-01 18:32:07');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `study_years`
--

DROP TABLE IF EXISTS `study_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `study_years` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `year` year(4) NOT NULL,
  `semester` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `study_years_year_unique` (`year`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study_years`
--

LOCK TABLES `study_years` WRITE;
/*!40000 ALTER TABLE `study_years` DISABLE KEYS */;
INSERT INTO `study_years` VALUES (1,2022,1,1,'2022-04-05 06:07:33','2022-04-05 06:07:33');
/*!40000 ALTER TABLE `study_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `major_id` bigint(20) unsigned DEFAULT NULL,
  `degree_id` bigint(20) unsigned DEFAULT NULL,
  `code` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subjects_code_unique` (`code`),
  KEY `subjects_major_id_foreign` (`major_id`),
  KEY `subjects_degree_id_foreign` (`degree_id`),
  CONSTRAINT `subjects_degree_id_foreign` FOREIGN KEY (`degree_id`) REFERENCES `degrees` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `subjects_major_id_foreign` FOREIGN KEY (`major_id`) REFERENCES `majors` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,NULL,NULL,'MPL001','Bahasa Indonesia',75,1,NULL,'2022-04-05 06:07:35',NULL),(2,NULL,NULL,'MPL002','Bahasa Inggris',75,1,NULL,'2022-04-05 06:07:35',NULL),(3,NULL,NULL,'MPL003','Matematika',75,1,NULL,'2022-04-05 06:07:35',NULL),(4,NULL,NULL,'MPL004','Seni Budaya',75,1,NULL,'2022-04-05 06:07:35',NULL),(5,NULL,NULL,'MPL005','Pendidikan Agama',75,1,NULL,'2022-04-05 06:07:35',NULL),(6,NULL,NULL,'MPL006','Pendidikan Kewarganegaraan',75,1,NULL,'2022-04-05 06:07:35',NULL),(7,1,1,'MPL007','Pemrograman Dasar',80,1,NULL,'2022-04-05 06:07:35',NULL),(8,1,1,'MPL009','Sistem Komputer',80,1,NULL,'2022-04-05 06:07:35',NULL),(9,1,2,'MPL010','Database',80,1,NULL,'2022-04-05 06:07:35',NULL),(10,2,1,'MPL011','Komputer dan Jaringan Dasar',80,1,NULL,'2022-04-05 06:07:35',NULL),(11,2,3,'MPL012','Administrasi Infrastruktur Jaringan',80,1,NULL,'2022-04-05 06:07:35',NULL),(12,2,3,'MPL013','Teknologi Layanan Jaringan',80,1,NULL,'2022-04-05 06:07:35',NULL),(13,7,1,'UCM-In','Bhs Indonesia',75,1,NULL,'2022-04-06 19:31:49','2022-04-06 19:31:49'),(14,7,1,'UCM-Math','Matematika',75,1,NULL,'2022-04-07 13:43:57','2022-04-07 13:43:57'),(15,7,1,'UCM-Fis','Fisika',75,1,NULL,'2022-04-07 13:44:16','2022-04-07 13:44:16');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `position_id` bigint(20) unsigned NOT NULL,
  `identity_number` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthplace` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year_of_entry` year(4) NOT NULL,
  `picture` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_education` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teachers_position_id_foreign` (`position_id`),
  CONSTRAINT `teachers_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,1,'190302123456789','Suyono, S.Kom','male','085673637261','suyono@gmail.com','Banyuwangi','1987-12-09','Sukorejo',2016,'default.png',1,'S1',NULL,'2022-04-05 06:07:33',NULL),(2,1,'200302123456789','Edy Pramono, S.Pd., M.Kom','male','085673637261','edypram@gmail.com','Banyuwangi','1977-11-10','Banyuwangi',2016,'default.png',1,'S2',NULL,'2022-04-05 06:07:33',NULL),(3,1,'200302123456790','Rina Indrawati, S.T','female','085673637261','rina@gmail.com','Surabaya','1992-11-10','Blimbingsari',2016,'default.png',1,'S1',NULL,'2022-04-05 06:07:33',NULL),(4,1,'300302123456789','Sri Rahayu, S.Pd','female','085673637261','srirahayu@gmail.com','Banyuwangi','1982-01-12','Blimbingsari',2016,'teachers_94930308_3096172877.png',1,'S1',NULL,'2022-04-05 06:07:33','2022-04-06 04:59:37'),(5,1,'214211','Guru 1','male','-','guru@gmail.com','Cluring','1977-04-07','Cluring Banyuwangi',2010,'default.png',1,'S1',NULL,'2022-04-06 19:29:12','2022-04-06 19:29:12'),(6,1,'214212','Guru 2','male','-','guru2@gmail.com','Cluring','1977-04-01','Cluring',2010,'default.png',1,'S1',NULL,'2022-04-07 13:42:09','2022-04-07 13:42:09'),(7,1,'214213','Guru 3','male','-','guru3@gmail.com','Cluring','1977-04-01','Cluring',2010,'default.png',1,'S1',NULL,'2022-04-07 13:42:53','2022-04-07 13:42:53');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaching_materials`
--

DROP TABLE IF EXISTS `teaching_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaching_materials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `core_competence_id` bigint(20) unsigned NOT NULL,
  `basic_competence_id` bigint(20) unsigned NOT NULL,
  `type` enum('file','image','video','audio','youtube','article') COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci,
  `is_share` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teaching_materials_course_id_foreign` (`course_id`),
  KEY `teaching_materials_core_competence_id_foreign` (`core_competence_id`),
  KEY `teaching_materials_basic_competence_id_foreign` (`basic_competence_id`),
  CONSTRAINT `teaching_materials_basic_competence_id_foreign` FOREIGN KEY (`basic_competence_id`) REFERENCES `basic_competences` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `teaching_materials_core_competence_id_foreign` FOREIGN KEY (`core_competence_id`) REFERENCES `core_competences` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `teaching_materials_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaching_materials`
--

LOCK TABLES `teaching_materials` WRITE;
/*!40000 ALTER TABLE `teaching_materials` DISABLE KEYS */;
INSERT INTO `teaching_materials` VALUES (1,2,1,5,'file','file.pdf','Testing materi file','Materi untuk testing',1,NULL,NULL),(2,2,1,5,'image','image.jpg','Testing materi image','Materi untuk image',1,NULL,NULL),(3,2,1,5,'video','video.mp4','Testing materi video','Materi untuk video',1,NULL,NULL),(4,2,1,5,'audio','audio.mp3','Testing materi audio','Materi untuk audio',1,NULL,NULL),(5,2,1,5,'youtube','https://www.youtube.com/watch?v=5yTgAwbFECY','Testing materi youtube','Materi untuk youtube',1,NULL,NULL),(6,2,1,5,'article','https://webmediadigital.com','Testing materi article','Materi untuk article',1,NULL,NULL),(7,9,1,9,'video','bahan_ajar_LwhHoaAKGEpPNBd.mp4','IPA(Testing Upload Video)',NULL,1,'2022-04-06 19:46:02','2022-04-06 19:46:02'),(8,9,1,9,'youtube','https://www.youtube.com/watch?v=2UnaotbBqWw&t=2880s','IPA(Testing Embed Youtube)',NULL,1,'2022-04-06 19:48:01','2022-04-06 19:48:01');
/*!40000 ALTER TABLE `teaching_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userable_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userable_id` bigint(20) unsigned DEFAULT NULL,
  `picture` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT 'default.png',
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_channel` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_online` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,'default.png','Developer','root@gmail.com','root',NULL,'$2y$10$FDBeFgfzpLQwZgJzcWTFnumallomqIEC8.fcyM6vIMI0yAbOJU3Du',NULL,'2022-09-29 09:58:51',1,1,NULL,'2022-04-05 06:07:34','2022-09-29 09:58:51'),(2,NULL,NULL,'users_931524490_1693224141.png','Administrator','admin@gmail.com','admin',NULL,'$2y$10$eLaaMbo/Ej28Y/6arF.Gg.LoTCvCBFCDZxmdhQdf6Wi6pG8VG84Ja',NULL,'2022-10-02 09:22:55',0,1,NULL,'2022-04-05 06:07:34','2022-10-02 09:23:06'),(3,'App\\Models\\Student',1,'default.png','Ridho Pijak Imana','ridho@gmail.com','ridho',NULL,'$2y$10$RRn0DH3MWWGDhNlubPJvRuh3XGRVIMsQMWszYMAoNiTRhnwJ6iF1G',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(4,'App\\Models\\Student',2,'default.png','Sindy Rahayu','sindy@gmail.com','sindy',NULL,'$2y$10$Zvpq1RIy7beVXgv5hgK7tevibz1xHkcMJTCiAxEeimtXRL6rMQs9G',NULL,'2022-04-13 20:16:55',0,1,NULL,'2022-04-05 06:07:34','2022-04-13 20:17:34'),(5,'App\\Models\\Student',3,'default.png','Dimas Anggara','dimas@gmail.com','dimas',NULL,'$2y$10$emdUgk56wnptoCQBL8CJIOHfHNzA5EK7T6kJ5VLmNkwY8MH1afiZa',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(6,'App\\Models\\Student',4,'default.png','Edy Saputra','edysaputra@gmail.com','edysaputra',NULL,'$2y$10$lQmZsCBTiWYFdtuiOrmRK.XwpNtD4qP1DX70W9bKMgwZTzAUXUjnq',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(7,'App\\Models\\Student',5,'default.png','Niki Lestari','niki@gmail.com','niki',NULL,'$2y$10$FxUUvCOjVFHUVxbaPBZhgOrPpOUHqf2zb7J4J3EBA0.JrCS6A3Uua',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(8,'App\\Models\\Student',6,'default.png','Riko Dermawan','riko@gmail.com','riko',NULL,'$2y$10$4/aYnNIodEzkW1GAbB27m.4Bl.GTBFv7j0MpxbYOnlFMG.uuoPy2m',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(9,'App\\Models\\Teacher',1,'default.png','Suyono, S.Kom','suyono@gmail.com','suyono',NULL,'$2y$10$.AZF.Sq66x5nGvrQiGjKqO741u/fHlRm8f3NS0PPTtqDOhIa51026',NULL,'2022-04-13 20:17:44',1,1,NULL,'2022-04-05 06:07:34','2022-04-13 20:17:44'),(10,'App\\Models\\Teacher',2,'default.png','Edy Pramono, S.Pd., M.Kom','edypram@gmail.com','edypram',NULL,'$2y$10$e1FPXNb24Xs3hIJSEAjfyeBGEmpZG7EsO7cyWqHj.qezt3kqQ/76O',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(11,'App\\Models\\Teacher',3,'default.png','Rina Indrawati, S.T','rina@gmail.com','rina',NULL,'$2y$10$kTHnK1L7rH64Dy7s5VIdTeLKCj8UD.qrxcBpc1uB/KcAiZ/WxDHCu',NULL,NULL,0,1,NULL,'2022-04-05 06:07:34',NULL),(12,'App\\Models\\Teacher',4,'users_555110879_5780667827.png','Sri Rahayu, S.Pd','srirahayu@gmail.com','300302123456789',NULL,'$2y$10$hfBmdls7VF5iHKCTOv0t0.ByqXRRnbpEdgn3ckaezDL8AKmGWE3ey',NULL,'2022-04-06 12:45:18',1,1,NULL,'2022-04-05 06:07:34','2022-04-06 12:45:18'),(13,'App\\Models\\Teacher',5,'default.png','Guru 1','guru@gmail.com','214211',NULL,'$2y$10$Rjmg1qP.FCc4ZsYKwdHATevvzFMgJdIksnd14cuVSsTc8gNiCwX/S',NULL,'2022-07-28 12:47:02',1,1,NULL,'2022-04-06 19:29:13','2022-07-28 12:47:02'),(14,'App\\Models\\Student',7,'default.png','Siswa 1','siswa@gmail.com','215211',NULL,'$2y$10$JmgBQflmQBDAZKK87jb2/.ksEiEEFZFNx.Cj5qQyyFOl.icddSiZa',NULL,'2022-06-20 22:15:41',1,1,NULL,'2022-04-06 19:30:21','2022-06-20 22:15:41'),(15,'App\\Models\\Teacher',6,'default.png','Guru 2','guru2@gmail.com','214212',NULL,'$2y$10$2W4OueRT4piXzhXgqVLIweZT9/v/hdSR60UpLCODAPcKg//05O4Qi',NULL,'2022-04-11 10:39:11',1,1,NULL,'2022-04-07 13:42:09','2022-06-15 13:22:03'),(16,'App\\Models\\Teacher',7,'default.png','Guru 3','guru3@gmail.com','214213',NULL,'$2y$10$nuXTrfAlAfdANyMm9Qu.bui1EiE3Be5HqKKBccBZdv.KhaV7oDFua',NULL,'2022-04-12 16:04:48',0,1,NULL,'2022-04-07 13:42:53','2022-04-12 16:05:26'),(17,'App\\Models\\Student',8,'default.png','Siswa 2','siswa2@gmail.com','215212',NULL,'$2y$10$LKkPCOG2HoF3ALXX2OM5xOd.UcLhCnn/B1IXeX8p/CZAhbl./mu.e',NULL,'2022-06-11 20:26:43',1,1,NULL,'2022-04-07 13:50:16','2022-06-15 13:22:02'),(18,'App\\Models\\Student',9,'default.png','Siswa 3','siswa3@gmail.com','215213',NULL,'$2y$10$3.MWBhDaFkMGEPeYFGkRAOQWIrocnBY9zXHx4QiZco.ibIjTvU9Bm',NULL,'2022-04-11 10:36:30',0,1,NULL,'2022-04-07 13:51:03','2022-04-11 10:38:48'),(1919,'App\\Models\\Student',1920,'default.png','AGIL WIRA SAMUDRA','6317@gmail.com','6317',NULL,'$2y$10$gF/dorlQMTwcOKgqAMCoQeDFZWDxn3wL7Ab9g8OOpv9/sR3FMNrbu',NULL,'2022-10-01 18:20:26',0,1,NULL,'2022-10-01 18:17:57','2022-10-01 18:20:44'),(1920,'App\\Models\\Student',1921,'default.png','ALDYAN BY MAULANA','6326@gmail.com','6326',NULL,'$2y$10$UcEW3EPtfecmTYUEGHzOvO6l21eMg/xGz.Sg1RVDfBIWwmJPB3uf2',NULL,NULL,0,1,NULL,'2022-10-01 18:17:57','2022-10-01 18:17:57'),(1921,'App\\Models\\Student',1922,'default.png','ANANDA TYO PRASETYA','6333@gmail.com','6333',NULL,'$2y$10$41TPT2HyQDiHOkFgdYHNwev49M74rfGMbbxTIp.1.WgeJ3n7XCGiS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:02','2022-10-01 18:30:02'),(1922,'App\\Models\\Student',1923,'default.png','ANGELA JESSICA AMANDA PANDELAKI','6339@gmail.com','6339',NULL,'$2y$10$jRefj.FvjGCqECkQGJTWNelx2f5JN.6VG5JW2WApLxb0uCrZeFWzm',NULL,NULL,0,1,NULL,'2022-10-01 18:30:02','2022-10-01 18:30:02'),(1923,'App\\Models\\Student',1924,'default.png','ARYA MIKO NUGRAHA','6349@gmail.com','6349',NULL,'$2y$10$SAVS8FAs1UcY5n256BlYKOlvTj0USQaWMbDb7vLDwOuEgaxe3olxK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:03','2022-10-01 18:30:03'),(1924,'App\\Models\\Student',1925,'default.png','ARYA RAMADHANI','6350@gmail.com','6350',NULL,'$2y$10$.dGEhQo6PyiVGfZ6pZcyYu03pv.74fcZOgmvdPjqCH6xgpOGhnYKq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:03','2022-10-01 18:30:03'),(1925,'App\\Models\\Student',1926,'default.png','CYKA ULANSARI','6378@gmail.com','6378',NULL,'$2y$10$UaJkjOZMQDgtlE0jZHjcLOl4d18atpIpPXuAXPLAC.83TTt9MBux2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:03','2022-10-01 18:30:03'),(1926,'App\\Models\\Student',1927,'default.png','DAFA ALFARIZI','6379@gmail.com','6379',NULL,'$2y$10$YCdGcS01Ze5Y14KoAJM9e.1PuUMGdAxKs1F04EXUQOCIKTP54RgcK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:04','2022-10-01 18:30:04'),(1927,'App\\Models\\Student',1928,'default.png','DESTA DWI PRATIWI','6388@gmail.com','6388',NULL,'$2y$10$h7IRGkJkUCxgYNN4rVk.8uRWXUMAkKaNqimbSP6u6i218e1gIYYb6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:04','2022-10-01 18:30:04'),(1928,'App\\Models\\Student',1929,'default.png','DESY NATASYA WILONA','6390@gmail.com','6390',NULL,'$2y$10$Z9yhv0QOH01f8eSeXXYeAOA2U89CIGDKlZrj/LisY82wIXl1/o7i.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1929,'App\\Models\\Student',1930,'default.png','DIAH PRAFITA PUTRI','6397@gmail.com','6397',NULL,'$2y$10$sDo9mpgP8BiYpRV4zYZrJe4q/DDST5Ypfp53WuBMrT7Fr62bWEWTi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1930,'App\\Models\\Student',1931,'default.png','DIMAS CAHYO MENTARI','6406@gmail.com','6406',NULL,'$2y$10$jPAHxcAh0wty3bK1NZp5muPgm/MbW8GW3lXixch4LKDNHo3eyRax.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:05','2022-10-01 18:30:05'),(1931,'App\\Models\\Student',1932,'default.png','DINDA AYU TRI MAULIDDINA','6409@gmail.com','6409',NULL,'$2y$10$38TXgo74RjxSY6nejnC5hOa1mKszTsNu6rw3sSSvaGEpv20EHRMgm',NULL,NULL,0,1,NULL,'2022-10-01 18:30:06','2022-10-01 18:30:06'),(1932,'App\\Models\\Student',1933,'default.png','ELGA DAYU PERMANA','6420@gmail.com','6420',NULL,'$2y$10$GewKiexPyu/yILbF5pEpMOkOaHiRpb.lI0Or0MiAy0XsGgYzejbfm',NULL,NULL,0,1,NULL,'2022-10-01 18:30:06','2022-10-01 18:30:06'),(1933,'App\\Models\\Student',1934,'default.png','ELGA MAULIDIA AKBARI','6421@gmail.com','6421',NULL,'$2y$10$KipAXJGsR/jJ7ZQYN/nIBeB.iKDf9WDYYABM5J3aBZZ2hgZk1pxRq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1934,'App\\Models\\Student',1935,'default.png','FAUZAN ISZAQI PUTRA','6434@gmail.com','6434',NULL,'$2y$10$65KcwWuKT7bLH7uU28/nvOw8trqS.3XqQ4Qcw32Gpo8N076F/rv0e',NULL,NULL,0,1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1935,'App\\Models\\Student',1936,'default.png','FAZHRI FAJAR PRIBADI','6435@gmail.com','6435',NULL,'$2y$10$uIXmmRh6j0DsoxWf5On3YOd7ztRR31zlNGXhXn6ztYfJkWnF8HBra',NULL,NULL,0,1,NULL,'2022-10-01 18:30:07','2022-10-01 18:30:07'),(1936,'App\\Models\\Student',1937,'default.png','FERDION KUSENA LOBAN','6442@gmail.com','6442',NULL,'$2y$10$u23thpzIZpwPFs8gqh/Or.ScLyFUSAWD8Fm1tA5/TT9.RqhQlJlBa',NULL,NULL,0,1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1937,'App\\Models\\Student',1938,'default.png','FINKY YUAN EKA SYAHPUTRI','6443@gmail.com','6443',NULL,'$2y$10$NOnWsOGfhn2av8RuyHQlbe2g7ML3AqyK7HfAonWt3r99zG0AKZUKG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1938,'App\\Models\\Student',1939,'default.png','FRIZA CAHYA MECA','6446@gmail.com','6446',NULL,'$2y$10$/R1yThJmfJ3meUJWoNiZ5eisZbhKh9Hr9WDMulNGTOA/6BZ9//E/a',NULL,NULL,0,1,NULL,'2022-10-01 18:30:08','2022-10-01 18:30:08'),(1939,'App\\Models\\Student',1940,'default.png','GALUH ADAM DARIUS','6449@gmail.com','6449',NULL,'$2y$10$aBenDBk3Np5/Blrb00jYfurNfBvgiwLtdjLcV5HWMfbVi03dF3dc.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:09','2022-10-01 18:30:09'),(1940,'App\\Models\\Student',1941,'default.png','GULAM AHMAD FIRDAUS','6452@gmail.com','6452',NULL,'$2y$10$2IGL.qLn0cRos9/yXJ1dh.YqRg9wlG0zUwrfrcG/thGAdkwD8yf6S',NULL,NULL,0,1,NULL,'2022-10-01 18:30:09','2022-10-01 18:30:09'),(1941,'App\\Models\\Student',1942,'default.png','IFAN ADE YUDHA','6456@gmail.com','6456',NULL,'$2y$10$rBEhgK4LqmABf8nMSPLh2uncBByiA/vDQHDpdj5fm61WJZEJgy3bq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1942,'App\\Models\\Student',1943,'default.png','INTAN BERLIANA PUTRI','6461@gmail.com','6461',NULL,'$2y$10$4ExZQRMU2Oeh.Zt6ZKhyEOQ0vr.DYd8SjxxeRQQjYBJzu4U49drgK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1943,'App\\Models\\Student',1944,'default.png','M. HAKAM HILMI AL GHIFARI','6488@gmail.com','6488',NULL,'$2y$10$SRz9acAuWbL9fN7ZZJJWdOBNnRqXJQOwn9UdGeKvjM6RJePqeF1Eq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:10','2022-10-01 18:30:10'),(1944,'App\\Models\\Student',1945,'default.png','M. RAFFI IRWANSYAH','6491@gmail.com','6491',NULL,'$2y$10$Kf.caCe5HMI4qIaFjwgyj.hQ5w/Opf8X3rYdMbItNDvfr/Y1VFRgq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1945,'App\\Models\\Student',1946,'default.png','MARCELINUS ARI PRASOJO','6495@gmail.com','6495',NULL,'$2y$10$WOGECxMm1KgESMsGRWxsc.Tj/CivrL8v5ol4W5RHzDQyh9XheKpC.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1946,'App\\Models\\Student',1947,'default.png','MOH. DIMAS KURNIAWAN','6506@gmail.com','6506',NULL,'$2y$10$vJO9haUVdHzCjIue/8XbHuE25HoQ2uYn9Fh7j7B5MgpFa.IHyRGNi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:11','2022-10-01 18:30:11'),(1947,'App\\Models\\Student',1948,'default.png','MUH. QOHHARAFA ANANDA ROSANO','6516@gmail.com','6516',NULL,'$2y$10$5UPCZLaC1SugebWp4Dk1v.sO0CaJb/bZSaZLhmYU/jeb0qs8.UKyO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:12','2022-10-01 18:30:12'),(1948,'App\\Models\\Student',1949,'default.png','MUHAMMAD NAREL MAHENDRASYAH','6523@gmail.com','6523',NULL,'$2y$10$vqVr33m9zGTfJb/0T75s8OqFnwTtmuE2CmYLjNilXfZiw55RFQkva',NULL,NULL,0,1,NULL,'2022-10-01 18:30:12','2022-10-01 18:30:12'),(1949,'App\\Models\\Student',1950,'default.png','NUR DIANA ARIF','6552@gmail.com','6552',NULL,'$2y$10$Xs8GXz4p.60M.Kc2SraDBeENOvGRVLYw6XtpyIw/tPfKLRbIljrHG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:13','2022-10-01 18:30:13'),(1950,'App\\Models\\Student',1951,'default.png','NURANI FANNAZA ZULQAIRIN','6553@gmail.com','6553',NULL,'$2y$10$.NLJsh902Qc/uCKr4J2hEuTLuWQnA2GGgpniMQZpRhnn7z606niIS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:13','2022-10-01 18:30:13'),(1951,'App\\Models\\Student',1952,'default.png','PUTRI DEWI SEPTIANA ','6560@gmail.com','6560',NULL,'$2y$10$G7Sab4DNEw0EtlVoffDkhuhqjl6AgooWG8yoOBlowAlTO1Zmq9I9W',NULL,NULL,0,1,NULL,'2022-10-01 18:30:15','2022-10-01 18:30:15'),(1952,'App\\Models\\Student',1953,'default.png','RIFQI ANGGARA PUTRA','6583@gmail.com','6583',NULL,'$2y$10$hUYFV0bK3F3/tppWOJDTNebjH8ccmrY.eDE1xGs8ldpbZGhdw8b66',NULL,NULL,0,1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1953,'App\\Models\\Student',1954,'default.png','TALITA BERLIANA KINARJO','6612@gmail.com','6612',NULL,'$2y$10$EXVctuHdCHSc.yRlDEJqv.8PvTGPGye1zW9wbyCwHfpVWgzIfXmFK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1954,'App\\Models\\Student',1955,'default.png','YOMATRINANDA BAGUS MAHARDIKA','6627@gmail.com','6627',NULL,'$2y$10$EEJUIGD25bR4dPpsTLjKB.w0mG11phOo12kp4rUsUWC0V5WgReuUu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:16','2022-10-01 18:30:16'),(1955,'App\\Models\\Student',1956,'default.png','ZANUBA QOTRUN NAZA','6629@gmail.com','6629',NULL,'$2y$10$kFwSyVOFz0z91s469tWnVeH2IA4tiXJ2PxRtymzrcpUVPOv05XsFW',NULL,NULL,0,1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1956,'App\\Models\\Student',1957,'default.png','ADINDA ARUM KIRANA','6312@gmail.com','6312',NULL,'$2y$10$W0kEUHPR4sAQItjzP0ZCOebSWSG8hRJrS6Lt9PFFDfhzHRPVgW5Ha',NULL,NULL,0,1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1957,'App\\Models\\Student',1958,'default.png','AMALIA NUR AZIZAH','6331@gmail.com','6331',NULL,'$2y$10$Zl970sC5tOOnJu7XC7b3g.RkB47TgptkQUa045/RCR1RH/6ghwNCa',NULL,NULL,0,1,NULL,'2022-10-01 18:30:17','2022-10-01 18:30:17'),(1958,'App\\Models\\Student',1959,'default.png','ARYA RIZKI SAPUTRA','6351@gmail.com','6351',NULL,'$2y$10$Zg2lSq0DYfatR7iWuZDpiexm8W/SjuXYxw/7G/J63Wev7jeSX2zMW',NULL,NULL,0,1,NULL,'2022-10-01 18:30:18','2022-10-01 18:30:18'),(1959,'App\\Models\\Student',1960,'default.png','AYLA AFKARINA PUTRI','6358@gmail.com','6358',NULL,'$2y$10$H9vABRQlYugKSVs2X0Ppquz4V8xz4WvrhyngKEWWxDgX72Nrj6IXu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:18','2022-10-01 18:30:18'),(1960,'App\\Models\\Student',1961,'default.png','CAROLIN DAVISA ZAHRA ARIFIN','6369@gmail.com','6369',NULL,'$2y$10$3tHCy/f1gnPdGWB8eiHDe.SJ7NwuKtXlxtAfjt21m1oNemr4gQ9AC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1961,'App\\Models\\Student',1962,'default.png','DANIA MAHARANI','6380@gmail.com','6380',NULL,'$2y$10$HpB.ZPQvhVvmes.ot4cpQObmuRQJzpvZJfGPNEzbsAHA3MUtjUSDO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1962,'App\\Models\\Student',1963,'default.png','DEWI AYU WULANDARI','6395@gmail.com','6395',NULL,'$2y$10$vBSIA0lRymecwDWtvRscpeXSZP1byFN897KK5OMttTeyDq4YGxC7i',NULL,NULL,0,1,NULL,'2022-10-01 18:30:19','2022-10-01 18:30:19'),(1963,'App\\Models\\Student',1964,'default.png','DIAN DUTA CANDRA MARTHA','6398@gmail.com','6398',NULL,'$2y$10$/xvNrK8p0jwhbILIS6SdBun44W50h7D6CVsDe.Bi2cS3VBKaTv81W',NULL,NULL,0,1,NULL,'2022-10-01 18:30:20','2022-10-01 18:30:20'),(1964,'App\\Models\\Student',1965,'default.png','DIMAS PRAMUDYA WICAKSANA','6408@gmail.com','6408',NULL,'$2y$10$8UJM/n8GO/dnd2P5rPMageJLDMBRbGlxL1rIcV1Ib1M..16FCaluW',NULL,NULL,0,1,NULL,'2022-10-01 18:30:20','2022-10-01 18:30:20'),(1965,'App\\Models\\Student',1966,'default.png','DITA FEBRIYANTI','6413@gmail.com','6413',NULL,'$2y$10$CgFfNz1Ob/AXOpEobLTaPuce82hlcUrMIwfWAk0deLkEIfst7Uzsy',NULL,NULL,0,1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1966,'App\\Models\\Student',1967,'default.png','EVY RINDA SETYOWATI','6428@gmail.com','6428',NULL,'$2y$10$cPIYskadqbktxBNJUmQb4.8j7JPfw0EhJYDfXvStep3AiP6KeLnri',NULL,NULL,0,1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1967,'App\\Models\\Student',1968,'default.png','FAZRIN RAHMA ANGGRAINY','6436@gmail.com','6436',NULL,'$2y$10$8A2sXHLhQhzWBAJ9Faax1OgjZEAim7WC3MGdwnSBunDtTfXMm4s.S',NULL,NULL,0,1,NULL,'2022-10-01 18:30:21','2022-10-01 18:30:21'),(1968,'App\\Models\\Student',1969,'default.png','FEBRIAN NANTA PRAYOGA','6437@gmail.com','6437',NULL,'$2y$10$6/aHU5aRqDo7oPlUFyZDOOnyxy6943OyPArxy5btCzYIVddKZxHOq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1969,'App\\Models\\Student',1970,'default.png','GADIS FEBRIYANTI','6448@gmail.com','6448',NULL,'$2y$10$VI4abqqMrNhOlquWeDOH6eV.suBrjwrE7xiJvyiZKi5ohMsLkaNp6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1970,'App\\Models\\Student',1971,'default.png','JENI RIZKIA AMANDA','6463@gmail.com','6463',NULL,'$2y$10$b8lR9LHNmRIKVz.MYZ2Q5umPmGL5lhtsPfPTdQU0T3ada1QzP9q9q',NULL,NULL,0,1,NULL,'2022-10-01 18:30:22','2022-10-01 18:30:22'),(1971,'App\\Models\\Student',1972,'default.png','KARINIA DEWI','6469@gmail.com','6469',NULL,'$2y$10$TILIMotMIvT9IHYyx6P21euE62/w6DLkhgkpwfwe52633HL64zQ2m',NULL,NULL,0,1,NULL,'2022-10-01 18:30:23','2022-10-01 18:30:23'),(1972,'App\\Models\\Student',1973,'default.png','KHANZA LAURA MAULIDIA','6477@gmail.com','6477',NULL,'$2y$10$xKCkJWwBOySTE8UXHPfkEOPZyFOPFUzQP5vgOd8AQJDNtWC600dxK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:23','2022-10-01 18:30:23'),(1973,'App\\Models\\Student',1974,'default.png','KHARISMA SUKMA AYU','6479@gmail.com','6479',NULL,'$2y$10$TA6TwMt1JuLsrHb4cdBym.3oERA1wisOJwIM35hwY8JviGiJz9mMG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1974,'App\\Models\\Student',1975,'default.png','KIRANA CINTA LESTARI','6482@gmail.com','6482',NULL,'$2y$10$80.mO8Ywf21f5xmQPadg4O7HUl2UxDFMSzdH0cY7W4MwGV8ebFYyK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1975,'App\\Models\\Student',1976,'default.png','LIAN BINTARA NUSANTARA','6484@gmail.com','6484',NULL,'$2y$10$QKFS80CpXVrU1pNxtyE1F.BmQLMxwsi2XTPwAc7hd6SUNPGiK4HP6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:24','2022-10-01 18:30:24'),(1976,'App\\Models\\Student',1977,'default.png','MEY LIANA FEBRIANTI','6501@gmail.com','6501',NULL,'$2y$10$Fc7AxhWS8YK6Wfo1nIUJn.U/RYRQmXPfRU57b1PL1XY84EwWoW4K6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:25','2022-10-01 18:30:25'),(1977,'App\\Models\\Student',1978,'default.png','MOHAMMAD IRSYAD FAIZ SAMSUDIN','6511@gmail.com','6511',NULL,'$2y$10$rP2LbwiRN.FgxlCdO0ZQpeq3HKjuVR31kn04kv6TfIw.1KEcuq3PG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:25','2022-10-01 18:30:25'),(1978,'App\\Models\\Student',1979,'default.png','MUHAMMAD FARHAN SYARIF HIDAYAT','6520@gmail.com','6520',NULL,'$2y$10$29mbHGQqZ4b4rtu/8cpxCeHpib4LoZJiHz9nbLq08vTdtXGZ3Ic8K',NULL,NULL,0,1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1979,'App\\Models\\Student',1980,'default.png','MUSTHOFA ALI SUBKHAN','6526@gmail.com','6526',NULL,'$2y$10$DphYhl1TIk.eR0qRGxb4ROUuxL7DNCY17JwTeXNV96OPw6apy6utK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1980,'App\\Models\\Student',1981,'default.png','MUTIARA TIFFANY RAMADHAN','6528@gmail.com','6528',NULL,'$2y$10$DbV2T7b/unlgAAVnIYuo2.EFoAj2NNnXW4kodQ3B./9kdB07iD1gm',NULL,NULL,0,1,NULL,'2022-10-01 18:30:26','2022-10-01 18:30:26'),(1981,'App\\Models\\Student',1982,'default.png','NAILA ZAHRA PRASETIA','6535@gmail.com','6535',NULL,'$2y$10$uzQ41EzCSDATNRUSiiMUWOW8S947fG4j8HNh.Vwl4cQVqA4hYdf6W',NULL,NULL,0,1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1982,'App\\Models\\Student',1983,'default.png','NAZILA HUROH','6541@gmail.com','6541',NULL,'$2y$10$qNIaY.KSiSjByr2DGJb4MuAUqgFgo9.M2XYh388yX32Q/MnxI6dK6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1983,'App\\Models\\Student',1984,'default.png','NENSY MEIKA','6545@gmail.com','6545',NULL,'$2y$10$JfEOhA1PHCuJwEtrE7RVD.P1NvgbGiEK2CskjqiK53M71coNePRuO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:27','2022-10-01 18:30:27'),(1984,'App\\Models\\Student',1985,'default.png','PUJI RAHAYU','6557@gmail.com','6557',NULL,'$2y$10$P8NGaFJHwK.4CsM37i/XeukuaMi2KLO.a66ApD09PRCJFUYBMp2YC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:28','2022-10-01 18:30:28'),(1985,'App\\Models\\Student',1986,'default.png','RAHMA IMROATI','6564@gmail.com','6564',NULL,'$2y$10$WHeR2MIB4BcS0E/4xhcyfedwMNeW6hsmTIo2T5loq5TpRgftAvxpG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:28','2022-10-01 18:30:28'),(1986,'App\\Models\\Student',1987,'default.png','RENDY DAVA SYAHPUTRA','6572@gmail.com','6572',NULL,'$2y$10$Xl.zC9TMcdT/jxcq9L14A.aKbWEo0oOr2/v.OCDvhwOJHkMTFj.F2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1987,'App\\Models\\Student',1988,'default.png','RIVA INESTA FURY','6589@gmail.com','6589',NULL,'$2y$10$0bi4uLdxji3L.o.Sxg.QMuq2nzMK/Tuy6FpROPmS3r3OGQbrBPZWe',NULL,NULL,0,1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1988,'App\\Models\\Student',1989,'default.png','SALWA EKA PUTRI','6596@gmail.com','6596',NULL,'$2y$10$sPQVFNnr8mvoGSjUxXsDNuHb2YgAyw64JmLE.V0dTrN/rf0aZK.Te',NULL,NULL,0,1,NULL,'2022-10-01 18:30:29','2022-10-01 18:30:29'),(1989,'App\\Models\\Student',1990,'default.png','TIRTO AJI PAMUNGKAS','6615@gmail.com','6615',NULL,'$2y$10$BUk4N2E00wu/fsYBiIP5Hu34LgSqMyqszBsx0DmlSawHPkzbu0TvO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:30','2022-10-01 18:30:30'),(1990,'App\\Models\\Student',1991,'default.png','TRENNYA SAVANA ARDFIA PUTRI','6616@gmail.com','6616',NULL,'$2y$10$UcyTNGZodvGp/i5FPR2qtupQQ6OxjKXQWTpnlONmOZPLlZUfQWzAK',NULL,NULL,0,1,NULL,'2022-10-01 18:30:30','2022-10-01 18:30:30'),(1991,'App\\Models\\Student',1992,'default.png','VIA CHERIL AS ZAHRA','6621@gmail.com','6621',NULL,'$2y$10$agVhQUJ2K21HshkUvJ6CeeY7ezkChBLKjuaQzQS3T3fGnCcrjj1ym',NULL,NULL,0,1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1992,'App\\Models\\Student',1993,'default.png','ALFIA USTOJIK','6328@gmail.com','6328',NULL,'$2y$10$Y6R4aHLaMxxTvf6Fms3Nb.vCNFfn7wDPXImFDiWUAYTtxcC1h3cyy',NULL,NULL,0,1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1993,'App\\Models\\Student',1994,'default.png','ANARGYA LUNANAIYA ANJANI','6334@gmail.com','6334',NULL,'$2y$10$pAcZBOL9bLS14dm5aNDhxuOD28X0wHEgRRnPiAErYNoRQhBTbh3OW',NULL,NULL,0,1,NULL,'2022-10-01 18:30:31','2022-10-01 18:30:31'),(1994,'App\\Models\\Student',1995,'default.png','ANGGUN NANDA PAMUNGKAS','6341@gmail.com','6341',NULL,'$2y$10$O0W5usne8.Ksy.3IbExdmeiBmyu.e7gpBaqKbtOksrloW8FlnLjuO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1995,'App\\Models\\Student',1996,'default.png','ARINDA AGUSTINA','6345@gmail.com','6345',NULL,'$2y$10$b/S4C.VrJr2.EmCQ6xIfD.UwuCRHVAJ8cGk5hIHcU442KXvHCy80y',NULL,NULL,0,1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1996,'App\\Models\\Student',1997,'default.png','AULIA DWI YANTI','6352@gmail.com','6352',NULL,'$2y$10$RXInoVFZparZJamJcF00K.ZKirOaDOGzj87LGZhbdq0p0zT9NCrqS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:32','2022-10-01 18:30:32'),(1997,'App\\Models\\Student',1998,'default.png','AURA DHATU NINDYAATMAJA','6355@gmail.com','6355',NULL,'$2y$10$XyeGXnKd8W.GyXeq1Y8JSuyQP5jW.6M8tXwGYk2JUJLU/2LWEZkp6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:33','2022-10-01 18:30:33'),(1998,'App\\Models\\Student',1999,'default.png','BIMA SETYRA PUTRA','6363@gmail.com','6363',NULL,'$2y$10$2ChSmrDRgO2qy77GUIieZeBFVx2uoBvqjzMzmIiht3w7f68gRm6IC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:33','2022-10-01 18:30:33'),(1999,'App\\Models\\Student',2000,'default.png','CHINTA APRILIANI','6372@gmail.com','6372',NULL,'$2y$10$ILi4JZ5hXWJdseSDlZ/97O4hsyPeJp0ttGMwfCbrtree.ulpB7kX2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2000,'App\\Models\\Student',2001,'default.png','DEVI VANIA MAHARANI','6393@gmail.com','6393',NULL,'$2y$10$.V9KWkw6zjiaYZhHUVn9S./2ZVCJLxqJMrk7NQDK6a35qK9//cIr6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2001,'App\\Models\\Student',2002,'default.png','DHANI SAPUTRA','6396@gmail.com','6396',NULL,'$2y$10$w2.S4eUFOJozV6dLsr7Ire2GzbeMb8enZhXXYXhtoUbueJxH3CY2a',NULL,NULL,0,1,NULL,'2022-10-01 18:30:34','2022-10-01 18:30:34'),(2002,'App\\Models\\Student',2003,'default.png','DILA SABILA PUTRI','6405@gmail.com','6405',NULL,'$2y$10$3U3lWiC7Mz0B/eGI6KM4T.B.uzBjOz8H9pnMu83/ydjpnf1J7juLy',NULL,NULL,0,1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2003,'App\\Models\\Student',2004,'default.png','DINY ALVEIRA ANGGRAINY','6411@gmail.com','6411',NULL,'$2y$10$ZQSNvwqkGljxEXVD8J.dyOnNypGqTrDEip5mKlEJz5s8Uc.DN5brS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2004,'App\\Models\\Student',2005,'default.png','DUFAN ARIL PRASETYO','6415@gmail.com','6415',NULL,'$2y$10$EulUIzim3QiZ24xPHVN7d.u9Nk8x4lIzif6umzW78.iWDGkXTuUdG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:35','2022-10-01 18:30:35'),(2005,'App\\Models\\Student',2006,'default.png','FARRADIA PUTRI AZRIETA','6433@gmail.com','6433',NULL,'$2y$10$uul4X2Rvek2OW/4GuCVcNuS/KNYRWuHORstBYNcqLTP7qewMiTPmu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:36','2022-10-01 18:30:36'),(2006,'App\\Models\\Student',2007,'default.png','HANCEN AZZAINSON','6455@gmail.com','6455',NULL,'$2y$10$MnCRMtUWufxTh0pLijAUs.TdoHVsAFooQbjeRr0MiyzE/yaUt.M.O',NULL,NULL,0,1,NULL,'2022-10-01 18:30:36','2022-10-01 18:30:36'),(2007,'App\\Models\\Student',2008,'default.png','IMA AIROH','6458@gmail.com','6458',NULL,'$2y$10$NHKctJEtQcxMUId1fPT0VOIBqeOImemIJSHev3JWKyR40HswX6Gpe',NULL,NULL,0,1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2008,'App\\Models\\Student',2009,'default.png','KANAYA PUTRI ZACSKYA','6466@gmail.com','6466',NULL,'$2y$10$nBbMlNSgCVJaqRssbcrQ1erMBj3iUANYalRdBi8Pt4EJSDLstElha',NULL,NULL,0,1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2009,'App\\Models\\Student',2010,'default.png','KEYSYA REVINDHIKA KURNIAWAN','6474@gmail.com','6474',NULL,'$2y$10$uvl9jF1GZIglOoXjqYXUa.2qeO3p5ONREWkgtycBnDdgFHNpe80Wq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:37','2022-10-01 18:30:37'),(2010,'App\\Models\\Student',2011,'default.png','MOCH. RIFKI ADE PRAMADAN','6504@gmail.com','6504',NULL,'$2y$10$irLaVRqTJNumCZJZ3mNyLOoqRcSwqcmpOFeBYmn.8QtFgAgnbFQMq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:38','2022-10-01 18:30:38'),(2011,'App\\Models\\Student',2012,'default.png','MOH. ROHMI HILMAN MUFADDOL','6507@gmail.com','6507',NULL,'$2y$10$Jyo9z3Tedhz4bBbD9psCFOfcZe/ZQARAAzejm3ZSjReEexOy0A1e2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:38','2022-10-01 18:30:38'),(2012,'App\\Models\\Student',2013,'default.png','MUHAMMAD HISYAM DWI .S','6522@gmail.com','6522',NULL,'$2y$10$GtXfXe7x2WiWKTkF11dOUOJYvNA5oxLE3hVIDkyNslSiW/8.IsZja',NULL,NULL,0,1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2013,'App\\Models\\Student',2014,'default.png','MUTIA JINGGA AZZAHRA','6527@gmail.com','6527',NULL,'$2y$10$b57C0quwVD95FPvnVLA4Le2J8enLhWW4evl/da7VXgDk8uPN90VCu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2014,'App\\Models\\Student',2015,'default.png','NADINE ASKA AULIAINI','6533@gmail.com','6533',NULL,'$2y$10$.t7EZgHMWw0rjkkEWGex0Ox9JcDdH2ffRcTv2.sMVqbVMKLHVVzeq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:39','2022-10-01 18:30:39'),(2015,'App\\Models\\Student',2016,'default.png','NAZWA MELANI KUSUMA PUTRI','6544@gmail.com','6544',NULL,'$2y$10$MZuhKKfoBqig8MD/3OEOjOnX7y/V4zk5I9yqrEOXS6E7jI/nDTng2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2016,'App\\Models\\Student',2017,'default.png','NILA FIRDAUZI NUZULA','6548@gmail.com','6548',NULL,'$2y$10$VcleeI0DML2bsFS54wmxZO078Ejcf5HpZkEve2.iOTjigyTSO0OFy',NULL,NULL,0,1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2017,'App\\Models\\Student',2018,'default.png','PUTRI AZAHRA SOFIA ANGGRAINI','6559@gmail.com','6559',NULL,'$2y$10$czGCwIQhINy5q6LNlqRmbO/E8KT4KGII/qvejCTSIWv.06E5s5Mmq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:40','2022-10-01 18:30:40'),(2018,'App\\Models\\Student',2019,'default.png','RAHAYU DESTRIANI','6563@gmail.com','6563',NULL,'$2y$10$kx7sad34ZOWBz5F9ndrUVeprHutcg2/PRxisA90wJ6Xz42z26MfGu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:41','2022-10-01 18:30:41'),(2019,'App\\Models\\Student',2020,'default.png','RAISYA PUTRI ELVINDA RULLY','6565@gmail.com','6565',NULL,'$2y$10$lvBlPf2s5Y6urN0aoB0D6epAn.cK95ZtcTk7aZ28Q3oPUVA1PYUw6',NULL,NULL,0,1,NULL,'2022-10-01 18:30:41','2022-10-01 18:30:41'),(2020,'App\\Models\\Student',2021,'default.png','RASTHY SHARLA NURFADILLAH. S','6566@gmail.com','6566',NULL,'$2y$10$KcdmsycWFMttcPTjy6YitOn7r7EISECWOLhPEvqU7f/227qUyg2Bu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2021,'App\\Models\\Student',2022,'default.png','RENA AULIA IRIANI','6571@gmail.com','6571',NULL,'$2y$10$bftmRVKKVNMae6FfU0kZwOjH1myxpA5imWcE.k8ikFZZJoZ4z9sGG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2022,'App\\Models\\Student',2023,'default.png','RYZA SAVANA PUTRA','6592@gmail.com','6592',NULL,'$2y$10$NYdPKMXIq8y2SC4L7J7pPefx6vMC1oUqy30AK4urXWPPs1jMrLMJO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:42','2022-10-01 18:30:42'),(2023,'App\\Models\\Student',2024,'default.png','SAFNA DEWI MARIYAM','6594@gmail.com','6594',NULL,'$2y$10$LCtrxIZ2qNPm4HD29E1t2.Eu5Y3qI5qPHySRGLiydcksaIKKihsq2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:43','2022-10-01 18:30:43'),(2024,'App\\Models\\Student',2025,'default.png','TIARA AL HIKMAH','6614@gmail.com','6614',NULL,'$2y$10$XLwZP1HTbRXRzACab9RmK.BQVToNCEFwTjFtBnUqKJ6qaIWB9UqPu',NULL,NULL,0,1,NULL,'2022-10-01 18:30:43','2022-10-01 18:30:43'),(2025,'App\\Models\\Student',2026,'default.png','TYA RISKI AMALIA','6620@gmail.com','6620',NULL,'$2y$10$Pt4r4U2eZKcmZgzpVMP2fO1sOQFqLeEq6Qgt7kwSHrvY7B0tXoMmC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2026,'App\\Models\\Student',2027,'default.png','ZAQIA AGASSY','6630@gmail.com','6630',NULL,'$2y$10$aEhBK6AAjepp/LeH./TCHOZCiHmkjGwmk5HHNOwyz.kKRjBaWQMr.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2027,'App\\Models\\Student',2028,'default.png','ACHMAD FERINO YUDHA HARIYANTO','6308@gmail.com','6308',NULL,'$2y$10$17yyVma51VmEjZtaNxdsu.0mAHS/5k3A7ePTfsvCzVqsMXcWGPbWa',NULL,NULL,0,1,NULL,'2022-10-01 18:30:44','2022-10-01 18:30:44'),(2028,'App\\Models\\Student',2029,'default.png','AFRIZA JULIAN ADITYA','6316@gmail.com','6316',NULL,'$2y$10$CyrGZUx9mGvc9xmwbpnqz.xNZD5LarWErj1yWMs5m9N8m8KMjT2Om',NULL,NULL,0,1,NULL,'2022-10-01 18:30:45','2022-10-01 18:30:45'),(2029,'App\\Models\\Student',2030,'default.png','AGUNG ULI ARTA','6319@gmail.com','6319',NULL,'$2y$10$AqtGiTCqeDQhLDvL/OxOlewyX/Rynd2DhpEpMBc15VDF0OotDoR1m',NULL,NULL,0,1,NULL,'2022-10-01 18:30:45','2022-10-01 18:30:45'),(2030,'App\\Models\\Student',2031,'default.png','AHMAD SHOFA MUBAROK','6320@gmail.com','6320',NULL,'$2y$10$MhDKWyxC4uKL581n.bYzUuLNAKV3KgDglx0iYKQCN3Glw7sTWP7ra',NULL,NULL,0,1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2031,'App\\Models\\Student',2032,'default.png','ANDINI DWI MULYANI','6335@gmail.com','6335',NULL,'$2y$10$dT0G38wDjtTiuLRf30VPROY6wecK8aKZPMU5Ev.4y0Ooq4yTbHyyi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2032,'App\\Models\\Student',2033,'default.png','ANDRA ADI PRAKASA','6337@gmail.com','6337',NULL,'$2y$10$hOCJc2jvCWJfaZQ1l99BwOJGSG1tRvbgKHtoDCFhstKWD6cu..sYC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:46','2022-10-01 18:30:46'),(2033,'App\\Models\\Student',2034,'default.png','ANDREAS SUGIARTO ADMOJO','6338@gmail.com','6338',NULL,'$2y$10$G.V2Cwfxn1t8RBAltD8SO.X18a3nmTwf.iXzbN6jr/fV7d1RKn7zq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2034,'App\\Models\\Student',2035,'default.png','AULIA MIFTA\'UL ARZAK ','6353@gmail.com','6353',NULL,'$2y$10$8TnPN/9Rpa5Q8Xg9BLXkjOXk.RBwroFJpoGcRhNA6TyVqvTcHPNuC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2035,'App\\Models\\Student',2036,'default.png','BENY NAUFAL SUKMA WANTA','6361@gmail.com','6361',NULL,'$2y$10$v7k5Rv45aDU7wpfj8cCDNOBcbOfZK7ffM5LOxtKuBvwAgG.Oyn7GG',NULL,NULL,0,1,NULL,'2022-10-01 18:30:47','2022-10-01 18:30:47'),(2036,'App\\Models\\Student',2037,'default.png','BUNGA MAULIDIA PRATIWI','6365@gmail.com','6365',NULL,'$2y$10$t6kX2t6WszX5DrlNns4jw.epUCa/exeA1jixtv8AhIvMX5JSIxtzi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:48','2022-10-01 18:30:48'),(2037,'App\\Models\\Student',2038,'default.png','CINTA APRERIDA PUTRI','6375@gmail.com','6375',NULL,'$2y$10$i9tqw1cEl24CumZFEKjK.u855ok5Ih9BTHUaeVJsf48OUUoBxmFOS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:48','2022-10-01 18:30:48'),(2038,'App\\Models\\Student',2039,'default.png','DANU DWI PUTRA FERDIANSYAH','6381@gmail.com','6381',NULL,'$2y$10$GJP.fHs22RbDIFKXQgGvA.NS.xo8/h1BhS7S3MhPvxPH0Y0/zIZTO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2039,'App\\Models\\Student',2040,'default.png','DINDA EKA FEBRIYANTI','6410@gmail.com','6410',NULL,'$2y$10$nL/aEowVcqKOUJRZkYn32eGtJqdlKSi33NWNZ0/apo3DKfROmbJgi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2040,'App\\Models\\Student',2041,'default.png','DWI RINDRAHADI KHUSZUMAH WARDANA','6416@gmail.com','6416',NULL,'$2y$10$lPE7zcLKtmUWiu8tXw4hceq0xNKEqF/iOP/xYeR861BtY3g6LSt8K',NULL,NULL,0,1,NULL,'2022-10-01 18:30:49','2022-10-01 18:30:49'),(2041,'App\\Models\\Student',2042,'default.png','ERIANA DWI NIRWANA ','6424@gmail.com','6424',NULL,'$2y$10$5Nwth31OmcI2dUiVzvAlbu8xuQPPHsKbzNhdKdUP0t7MNW4EcN6Wa',NULL,NULL,0,1,NULL,'2022-10-01 18:30:50','2022-10-01 18:30:50'),(2042,'App\\Models\\Student',2043,'default.png','FAREL BAYU SASMITO','6430@gmail.com','6430',NULL,'$2y$10$wtSiqyNVd4Z5DbJXrJIlieb26Tp8dTMNjDbNSKbIsunlfPzdLB/4q',NULL,NULL,0,1,NULL,'2022-10-01 18:30:50','2022-10-01 18:30:50'),(2043,'App\\Models\\Student',2044,'default.png','FELISYA SHERLY NATHANIELA','6441@gmail.com','6441',NULL,'$2y$10$tV.N8AKKAUT2CqRHC3OKzusuAx2vjJjXk0UCKcAzdniKGul607xRC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2044,'App\\Models\\Student',2045,'default.png','FIRDAUS GHIFARI ARAFAT FAUZAN','6445@gmail.com','6445',NULL,'$2y$10$8hiuYF1FDFezhPZyuMsqtu956WhXebD6Eyljc9kM.dgdBJtS3Q4wO',NULL,NULL,0,1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2045,'App\\Models\\Student',2046,'default.png','ILHAM ARIF FAHROZI','6457@gmail.com','6457',NULL,'$2y$10$XjX6uVXGzJVd6EaqSQUp.O0FoqcGXQdurpF9ogMkcYiQPDTJLS8jC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:51','2022-10-01 18:30:51'),(2046,'App\\Models\\Student',2047,'default.png','KANIA RAMADHANI','6467@gmail.com','6467',NULL,'$2y$10$Q5a0TVwHCpF02kgcQcAOf.vMTf0Tm0w/t1vv3Iyh.eigPwGLRjS/K',NULL,NULL,0,1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2047,'App\\Models\\Student',2048,'default.png','KEYSHA SILSABELLA RAHMA','6473@gmail.com','6473',NULL,'$2y$10$sfC5I9cpXgvq1txm0NDZK..Aq5NiI477RQaVXEj0yhq2NV3By3jCi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2048,'App\\Models\\Student',2049,'default.png','KHAIRUNISA LUTFIAH SALMA','6476@gmail.com','6476',NULL,'$2y$10$a0oYJ30CLAlaHllyE.Z9Murr4qJ1MrUKx4xkkLSNQqyIeqXiphpXC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:52','2022-10-01 18:30:52'),(2049,'App\\Models\\Student',2050,'default.png','LOVYORA ASMODIWATI PUTRI','6486@gmail.com','6486',NULL,'$2y$10$ffUdZRhVQ3aWaLGz2TBM0u0i8VwW7.w6QjDQ0pknuuajZMO4tYI8m',NULL,NULL,0,1,NULL,'2022-10-01 18:30:53','2022-10-01 18:30:53'),(2050,'App\\Models\\Student',2051,'default.png','MARSYA SAREN','6496@gmail.com','6496',NULL,'$2y$10$WyUQWPxjtnq7JlERa6QTbu2w8InGhCLQqvFOyjSFEdkhB/T.GZa2O',NULL,NULL,0,1,NULL,'2022-10-01 18:30:53','2022-10-01 18:30:53'),(2051,'App\\Models\\Student',2052,'default.png','MOCH ERVANDRA RIZQI AKBARI','6503@gmail.com','6503',NULL,'$2y$10$gn55td66/6TYMKClzzFWVuNgSsiHJbCC3loRwrxbCSbFk0r0G7nQi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2052,'App\\Models\\Student',2053,'default.png','MOH. WILLY ALDI YANTO','6508@gmail.com','6508',NULL,'$2y$10$OGyydvj1i0WTVWhkynVpAOVRZFPOuQNVCalcvyTty/mppnFGxawj.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2053,'App\\Models\\Student',2054,'default.png','MOHAMMAD TEGAS DWINANDA KURNIAWAN','6513@gmail.com','6513',NULL,'$2y$10$2kNSv/uHcOPlvpsSwkIe6.lX7aG0Lu3PYJCMsU8/Y.86iWUq96BRi',NULL,NULL,0,1,NULL,'2022-10-01 18:30:54','2022-10-01 18:30:54'),(2054,'App\\Models\\Student',2055,'default.png','MUHAMAT IFAN MAULANA','6517@gmail.com','6517',NULL,'$2y$10$Wh7Z1a8flvFXT9ehzvm64O4kAvBjZHzcVxwTnfjavKbjKoJFuGso2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2055,'App\\Models\\Student',2056,'default.png','MUHAMMAD CHELVIN ALAMSYAH','6518@gmail.com','6518',NULL,'$2y$10$Yo/40HvreYZcUTkl9clnHeJlZTFCbEfi6rq9luXyEQqLNxxXUqSWS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2056,'App\\Models\\Student',2057,'default.png','MUHAMMAD DAFFA FIRDAUS','6519@gmail.com','6519',NULL,'$2y$10$LtuRmGyAVXYN6fkzFNmQduAQAIDehiXJXdVoSpZNiQN0NrqOlOpCC',NULL,NULL,0,1,NULL,'2022-10-01 18:30:55','2022-10-01 18:30:55'),(2057,'App\\Models\\Student',2058,'default.png','MUHAMMAD FERNANDO DWI PUTRA','6521@gmail.com','6521',NULL,'$2y$10$7QYNKbLlc31Dwf8/D9YsX.PNuKYlsaxNIhH.UEDBrSeARW.u3LuMq',NULL,NULL,0,1,NULL,'2022-10-01 18:30:56','2022-10-01 18:30:56'),(2058,'App\\Models\\Student',2059,'default.png','MUHAMMAD REHAN DANUWARTA','6524@gmail.com','6524',NULL,'$2y$10$eQX0.Pn4n.8kwosaiL/niOfcZ1BwDh/YL5JrylLwIPh9I/tEK4RY2',NULL,NULL,0,1,NULL,'2022-10-01 18:30:56','2022-10-01 18:30:56'),(2059,'App\\Models\\Student',2060,'default.png','RASYA AIDIL CITRA AULIA','6567@gmail.com','6567',NULL,'$2y$10$66pkVn4zC.ktMbk.sraVDucsLUxdoi91jlNtESTzU6ysFyY3xD24K',NULL,NULL,0,1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2060,'App\\Models\\Student',2061,'default.png','REZA ALAMSYAH','6577@gmail.com','6577',NULL,'$2y$10$7u3JxACuJzcZ5g6gE4SYYul9rt9ivMAhEqF/eJiaUOgaToJiox5Wy',NULL,NULL,0,1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2061,'App\\Models\\Student',2062,'default.png','SATRIA FITRIAN ARIADI','6598@gmail.com','6598',NULL,'$2y$10$PHt90NyzTC27Vn4ZUDkh7O1y8CLgYxNRw4uBga8jlC2Mg8Ip8PEM.',NULL,NULL,0,1,NULL,'2022-10-01 18:30:57','2022-10-01 18:30:57'),(2062,'App\\Models\\Student',2063,'default.png','SHERA PUTRI MEYLANI','6604@gmail.com','6604',NULL,'$2y$10$j7hDEVLi/ob5KXRXZr5pVewPK7rcP48Aids9KafTZdXNRRf1SOFrm',NULL,NULL,0,1,NULL,'2022-10-01 18:30:58','2022-10-01 18:30:58'),(2063,'App\\Models\\Student',2064,'default.png','VICKY BASID SADEWA','6622@gmail.com','6622',NULL,'$2y$10$1x4L0aNQbmgr6L0YxJmS9edgEe9UL8fhRUWQCeSfyyDgtwMbIuDcW',NULL,NULL,0,1,NULL,'2022-10-01 18:30:58','2022-10-01 18:30:58'),(2064,'App\\Models\\Student',2065,'default.png','ADYAKSA YAHYA PRAESA','6313@gmail.com','6313',NULL,'$2y$10$ETk5H.rH2v3NPJS2BNDCvuzq9aOVDm5tvIkGrd7NfY7rMVm7FtHOS',NULL,NULL,0,1,NULL,'2022-10-01 18:30:59','2022-10-01 18:30:59'),(2065,'App\\Models\\Student',2066,'default.png','AFIKA NUR FITRIA','6315@gmail.com','6315',NULL,'$2y$10$ax4fLaB0eFTX7zCvEYvwROnx3S3wX.h8oChNQfQWTQ8E6YkC2U4my',NULL,NULL,0,1,NULL,'2022-10-01 18:30:59','2022-10-01 18:30:59'),(2066,'App\\Models\\Student',2067,'default.png','AISYAH AZAHRA ISABEL PO','6324@gmail.com','6324',NULL,'$2y$10$xT5so/RQmXUvKimRhkrhC.WEW0hThBVDK7ybHSOOvB0o4C3pxDgl6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2067,'App\\Models\\Student',2068,'default.png','ARIEF RAHMAN HAKIM','6344@gmail.com','6344',NULL,'$2y$10$8ZMYPriH3oqDcJETQX07EebuE.hnEmSb8Y5py9uCa.pmkctXJ8ACS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2068,'App\\Models\\Student',2069,'default.png','AVRILIA DEWI PUJA ARIYANTO','6356@gmail.com','6356',NULL,'$2y$10$SkOIdr6dtmR3ob0Z9RDqIuFbXy5TkI.d6pN/FtFCIbU.eDkAVi0R2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:00','2022-10-01 18:31:00'),(2069,'App\\Models\\Student',2070,'default.png','BINGGA SHENDYKA AYU','6364@gmail.com','6364',NULL,'$2y$10$5NR/5DDRlh7J5P21pgVOTefCOs8wVN62Y4RmSuVQeGGOn7DrcfQ66',NULL,NULL,0,1,NULL,'2022-10-01 18:31:01','2022-10-01 18:31:01'),(2070,'App\\Models\\Student',2071,'default.png','CITRA SULUNG SETYANDARA','6376@gmail.com','6376',NULL,'$2y$10$Bzl31LxokkVwan1UsQvW9.Y1dmBEAg3q9l1TNziLpSQED5z4co8QC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:01','2022-10-01 18:31:01'),(2071,'App\\Models\\Student',2072,'default.png','DEVI YULI INDRAWATI','6394@gmail.com','6394',NULL,'$2y$10$8gRZ3z5XY/HuoZRCDV96AuVFD9XvcTvw376dGKpf/LQWYrM.FB2XG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2072,'App\\Models\\Student',2073,'default.png','DIANDRA WAHYU KRISTANTO','6400@gmail.com','6400',NULL,'$2y$10$qeTg9Emz5I4VgT7OMycI0.1J3KBY7iPf106It.8LMOp0eIKTN66wK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2073,'App\\Models\\Student',2074,'default.png','DIKI PURNAMA','6403@gmail.com','6403',NULL,'$2y$10$wPQgkcvKxdeTWsJZX1EChea4YCQX4bOB8cjCalsFmVMvxa5.tQy6W',NULL,NULL,0,1,NULL,'2022-10-01 18:31:02','2022-10-01 18:31:02'),(2074,'App\\Models\\Student',2075,'default.png','ERICA ATHARISNA','6425@gmail.com','6425',NULL,'$2y$10$WKNKPmwGMnx16vEz9vPmuu7Coq4RzzwkiVEZX2ly1U1IetOGH3bkC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:03','2022-10-01 18:31:03'),(2075,'App\\Models\\Student',2076,'default.png','FARENZA RISKY ANSEL','6431@gmail.com','6431',NULL,'$2y$10$n8k/r19OBLA6aObs483j4.icgHDPs3fBKpwJOe.NYyOreBhZJJ8he',NULL,NULL,0,1,NULL,'2022-10-01 18:31:03','2022-10-01 18:31:03'),(2076,'App\\Models\\Student',2077,'default.png','FELISIA AYU VERDINA','6440@gmail.com','6440',NULL,'$2y$10$23OsDkKKPZPecwRFcyn6/etAw0HF2Vhk1vFgn2B41CKSiKLIWi1GK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2077,'App\\Models\\Student',2078,'default.png','GIGIH ADITIYA','6450@gmail.com','6450',NULL,'$2y$10$anucqaRtxM9bzIpRnOcSLOBkjDPGXGCc7Wd2Whh1DHuWKCGkTVdx6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2078,'App\\Models\\Student',2079,'default.png','HAFSH AL HADARIY','6454@gmail.com','6454',NULL,'$2y$10$OhQfZBVoHbmzCSmGRthKHedaKtoHMRx1oBntgdX4a7ggqQH2lFkG6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:04','2022-10-01 18:31:04'),(2079,'App\\Models\\Student',2080,'default.png','JAMILATUS SURURIYAH','6462@gmail.com','6462',NULL,'$2y$10$xT.k6adb/SBjP6HHpTX6DeNhNViKJcOi08HP9UQwqlNUvaPxcVij2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2080,'App\\Models\\Student',2081,'default.png','LINDA PURNAMA SARI','6485@gmail.com','6485',NULL,'$2y$10$Jn65pFVrB1BvTxNm0ptNauyKlfyczvYvWJNzKLJxZC4EYEiFIskK.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2081,'App\\Models\\Student',2082,'default.png','MOH BRILIAN DWI NUGROHO','6505@gmail.com','6505',NULL,'$2y$10$hgrdK3xMRExeWYdl4kex2.sQDTnhN74PNz315f/3sZf8ONpIdJJku',NULL,NULL,0,1,NULL,'2022-10-01 18:31:05','2022-10-01 18:31:05'),(2082,'App\\Models\\Student',2083,'default.png','MOHAMMAD ADI AGIL FATHONI','6510@gmail.com','6510',NULL,'$2y$10$R4Js8EbIcFrXWCDQ0SwwX.UKvDUZrbGc4QfXMRaLw/BMrQz8eIgxC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:06','2022-10-01 18:31:06'),(2083,'App\\Models\\Student',2084,'default.png','NABIL DAFFA ADLI','6530@gmail.com','6530',NULL,'$2y$10$yy/T8T1BXG5.nywpza0c6Ow9.6b9KYZtSlngoeBHQCP8PTrzFzTC.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:06','2022-10-01 18:31:06'),(2084,'App\\Models\\Student',2085,'default.png','NADIA AYU SHOLEHAH','6532@gmail.com','6532',NULL,'$2y$10$trMpL8sf1wBTbc09vzgrCuttEhtKQ26Qqz4qt70aBlEgyjUGlGbN.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2085,'App\\Models\\Student',2086,'default.png','NANTA SUBHA DOYO','6537@gmail.com','6537',NULL,'$2y$10$2b16ek7aZ25P.Xx2O.QjauCEY3LA1/wODRxaAs5/rMvdPvsJE1CvS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2086,'App\\Models\\Student',2087,'default.png','NESYA AYU RAHMADINI','6546@gmail.com','6546',NULL,'$2y$10$5WDbENOlvia1B6qLCjo36O8q1FngdvUltg0yuGIR3rNgdZb7R48xW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:07','2022-10-01 18:31:07'),(2087,'App\\Models\\Student',2088,'default.png','NIRMALA WAHYUNINGTYAS','6550@gmail.com','6550',NULL,'$2y$10$0.FBqv4Bp61tG8wfmT5EfeYFvaRaTvv5E0cJr/3TG1wx23qOq4VIm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:08','2022-10-01 18:31:08'),(2088,'App\\Models\\Student',2089,'default.png','PUTRI YOGI BRUNIEYANTI','6561@gmail.com','6561',NULL,'$2y$10$FhVG3Qhfghmi0FUkVivgH.sx7yNIil6wooEDPlgw.kM9uwisCau5S',NULL,NULL,0,1,NULL,'2022-10-01 18:31:08','2022-10-01 18:31:08'),(2089,'App\\Models\\Student',2090,'default.png','RESTI AMELLINA','6573@gmail.com','6573',NULL,'$2y$10$EUgtKj2rJnvZfeYwWtutT.50yl7iKztl93.LfsWvndfeR6Ib.Yl1K',NULL,NULL,0,1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2090,'App\\Models\\Student',2091,'default.png','REYNATH KALLIO PRADAMAR','6576@gmail.com','6576',NULL,'$2y$10$yjx29Fr0j/e/wZLtXvnUQODnbCJnYKg060qlPJ21gKZ/2CigKQCI2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2091,'App\\Models\\Student',2092,'default.png','RISMA RAHAYU AGUSTIN','6586@gmail.com','6586',NULL,'$2y$10$FRSKfas.0WtwoTx.qmZKcukqSZgJmPsr5XKWo311pTE67IogjVRzC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:09','2022-10-01 18:31:09'),(2092,'App\\Models\\Student',2093,'default.png','SATRIO SANJAYA DANA WINATA','6599@gmail.com','6599',NULL,'$2y$10$CglNofv5f00nGaxF0a1PUuHdE/1DCj9RK0sEOR10/TwZa01awaxyO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2093,'App\\Models\\Student',2094,'default.png','SERLY APRILIANI','6602@gmail.com','6602',NULL,'$2y$10$f422d5slvVptC4XvkDueGO3z98BLCpNF7ndz3nGm9rgjSingct2bO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2094,'App\\Models\\Student',2095,'default.png','SOVIA INTAN PERMATASARI','6607@gmail.com','6607',NULL,'$2y$10$hkJOtYqaAtiYEu3tdbkQ/.RZXugQoa49R5ETdMr3AQRvT2NNfc5Di',NULL,NULL,0,1,NULL,'2022-10-01 18:31:10','2022-10-01 18:31:10'),(2095,'App\\Models\\Student',2096,'default.png','SUCI NAJWA SABILA','6608@gmail.com','6608',NULL,'$2y$10$JJAWDEFDiniAyUMkW4s1t.Pvqq18troRSt5TCWNy5cntMgR9ERR3.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:11','2022-10-01 18:31:11'),(2096,'App\\Models\\Student',2097,'default.png','TALITHA WAFIRANA','6613@gmail.com','6613',NULL,'$2y$10$7Z4pQqaqfmHbfSSCVqxMf.ptjwxNNJdXF.MMkJIufDROkol1mk/GK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:11','2022-10-01 18:31:11'),(2097,'App\\Models\\Student',2098,'default.png','TRIA ISMA FIBRIANI','6618@gmail.com','6618',NULL,'$2y$10$P6yTW20jDNGlFEiclVJAyOEUvhltltB57WgP.YUPqA.ZkdpPaBFWm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2098,'App\\Models\\Student',2099,'default.png','VIVI OLIVIA KHODIN','6624@gmail.com','6624',NULL,'$2y$10$1yLOdKpuCR.0EYlHKw8aHOeRGazgJqDZdhQTJ.Om2rdfN0ZGrog7C',NULL,NULL,0,1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2099,'App\\Models\\Student',2100,'default.png','ZUAN PRATAMA PANJIASA','6632@gmail.com','6632',NULL,'$2y$10$E0OjzlOUMJHy0Qcg/9bCGOSeVdvzNknOCap90b5SCfThWn5W/eBei',NULL,NULL,0,1,NULL,'2022-10-01 18:31:12','2022-10-01 18:31:12'),(2100,'App\\Models\\Student',2101,'default.png','AFIFA NUR FITRIA','6314@gmail.com','6314',NULL,'$2y$10$1w4L2030q3KXXYtiqmd9jOoI91ykLp3fD4RxGsPg1o0e2vsPUOWRq',NULL,NULL,0,1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2101,'App\\Models\\Student',2102,'default.png','AISAH FIKAYATUL APRIL LAILI','6322@gmail.com','6322',NULL,'$2y$10$EkSzZSaFThzhdWhVMiyMauGK3ZvNLe4ZbA2d8UbJUGhXkF08y0kBq',NULL,NULL,0,1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2102,'App\\Models\\Student',2103,'default.png','ALFINO ZIDAN FAIZI','6329@gmail.com','6329',NULL,'$2y$10$2pbX73BxcAvBhkX4c3kuNetCQ7xzib1UO5w1tkEHOlUglxrkTfW9i',NULL,NULL,0,1,NULL,'2022-10-01 18:31:13','2022-10-01 18:31:13'),(2103,'App\\Models\\Student',2104,'default.png','APRILLIA INTAN ANDINI','6343@gmail.com','6343',NULL,'$2y$10$uAiYytNiRH/y3gndPapDVOFX/hhTpylQpNkDVbiZKqf9SkI1NdzWe',NULL,NULL,0,1,NULL,'2022-10-01 18:31:14','2022-10-01 18:31:14'),(2104,'App\\Models\\Student',2105,'default.png','ARISTA RAMADHANI','6346@gmail.com','6346',NULL,'$2y$10$OlwW4ONlCIqMhSUicBbdBOqUfxfdF/g5b3cKrkowzz8PAO0pIt6jq',NULL,NULL,0,1,NULL,'2022-10-01 18:31:14','2022-10-01 18:31:14'),(2105,'App\\Models\\Student',2106,'default.png','ARYA DWI PAMUNGKAS','6348@gmail.com','6348',NULL,'$2y$10$Op0OJhFspPWSveuh8rwoOuBjdodoaufnR4AvD.T3H/vPZpLLfKD6q',NULL,NULL,0,1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2106,'App\\Models\\Student',2107,'default.png','AULIA WULAN','6354@gmail.com','6354',NULL,'$2y$10$Jh330PRRer15qPIzEBibNOipqdwDP47f.dmzOf0RFD37ZTOkgUSRC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2107,'App\\Models\\Student',2108,'default.png','BAGUS AHMAD DWI KURNIAWAN','6360@gmail.com','6360',NULL,'$2y$10$NDAcVH1ZDMsp/fePoCCb3Oo8U1lYNxYQXC1V7BoJHKOWBXEK5su0C',NULL,NULL,0,1,NULL,'2022-10-01 18:31:15','2022-10-01 18:31:15'),(2108,'App\\Models\\Student',2109,'default.png','CINDY ZAZKIA VALIZA','6374@gmail.com','6374',NULL,'$2y$10$INxDE7b6suYg1yilatI8uefHs12MiPfKaom0hezttNW0QfGMFFFK2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2109,'App\\Models\\Student',2110,'default.png','DELA HIDAYAH NINGRUM','6384@gmail.com','6384',NULL,'$2y$10$jO4nkyFZSC5NGrkUFIp9iuE9keL56s6ZW/JLlTXRWL2qicbEt9/pi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2110,'App\\Models\\Student',2111,'default.png','DIANA PUNGKI','6399@gmail.com','6399',NULL,'$2y$10$EUzYsQbEly50odPeNYpeDujUce1tsojXBJXAy9KPDs.ERPnagPZ/e',NULL,NULL,0,1,NULL,'2022-10-01 18:31:16','2022-10-01 18:31:16'),(2111,'App\\Models\\Student',2112,'default.png','DIFFANY NATHASS YAMSIE','6402@gmail.com','6402',NULL,'$2y$10$JS90NCa/Zcw2JoCCEt9tlegNmj/dlmjbGbd4Xmimpj7LDqDp5vU1S',NULL,NULL,0,1,NULL,'2022-10-01 18:31:17','2022-10-01 18:31:17'),(2112,'App\\Models\\Student',2113,'default.png','DILA MARISKA','6404@gmail.com','6404',NULL,'$2y$10$9cHpMF4nzdANCfVv06SaxezpU9VdEFW1dkaJ3Z/Zbk7cHUvLR0n7e',NULL,NULL,0,1,NULL,'2022-10-01 18:31:17','2022-10-01 18:31:17'),(2113,'App\\Models\\Student',2114,'default.png','DINY NUR QISTINA','6412@gmail.com','6412',NULL,'$2y$10$09J13JkkhFI02gF0MAY0MOIUPSbt/yWblUcJIU5L1GeeMJgkGmEg2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:17','2022-10-01 18:31:17'),(2114,'App\\Models\\Student',2115,'default.png','ETICO ABI GUWIRA','6427@gmail.com','6427',NULL,'$2y$10$yJAaZvrMdW3gP.9ajIQhbeDgzUv8AoybgMOwFFHV9ATJJ5khltHYi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:18','2022-10-01 18:31:18'),(2115,'App\\Models\\Student',2116,'default.png','FEBRIANA NUR AINI','6438@gmail.com','6438',NULL,'$2y$10$AORKaMHmHSFBWytkUDkMXeVdS33BGrHaS4BMADhXz78A8/OTZqHeG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:18','2022-10-01 18:31:18'),(2116,'App\\Models\\Student',2117,'default.png','FIRDA RESTI ANJAR SARI','6444@gmail.com','6444',NULL,'$2y$10$NwEdBe4lXlY2zwjvKnohNOTidvjr91Zcb1hHYEp8dpwml/JYArBJ6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2117,'App\\Models\\Student',2118,'default.png','GUNTUR CHANDRA LOKA ADHITYA','6453@gmail.com','6453',NULL,'$2y$10$.gq3PIR64hbygUkUM7KLMuok4kIK4.TMjebbojUp0R3Gq/TDkTN5u',NULL,NULL,0,1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2118,'App\\Models\\Student',2119,'default.png','INDIRA PRATAMA PUTRI','6460@gmail.com','6460',NULL,'$2y$10$M8b.K/DRTuVuMqMv2nutIeLO6T7HT/GrsvwcDC/I144f8iCYWx6y6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:19','2022-10-01 18:31:19'),(2119,'App\\Models\\Student',2120,'default.png','LA HAYYU LAWALATA','6483@gmail.com','6483',NULL,'$2y$10$UBKUQetoAxHK25zSDN5ajuLb.udMz2sZpFNzEuu6ccb2k16LXl5Ku',NULL,NULL,0,1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2120,'App\\Models\\Student',2121,'default.png','LUVI NATASYA','6487@gmail.com','6487',NULL,'$2y$10$Qjw8/lXo.T0zfbMn6PB1XeXqEMEYVDQx7HVGoXPdh0AstVyXdBmRG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2121,'App\\Models\\Student',2122,'default.png','M. HANIF ZAMZAMI','6490@gmail.com','6490',NULL,'$2y$10$6EOjrs0rTKfP2pW4Ss3Kq.jRR7gVhWl62Ke9dXWFn1UcEPOpBhLLG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:20','2022-10-01 18:31:20'),(2122,'App\\Models\\Student',2123,'default.png','MAELANY KURNIA SARI','6492@gmail.com','6492',NULL,'$2y$10$QKP5aMimABgmx5YLixw4HuCLiZEWgM33L4AE7SmeqhGsI//nsQSSe',NULL,NULL,0,1,NULL,'2022-10-01 18:31:21','2022-10-01 18:31:21'),(2123,'App\\Models\\Student',2124,'default.png','MOHAMMAD IRSYAD IVANKA','6512@gmail.com','6512',NULL,'$2y$10$wIN9Mg05P/YON2dxM.Djkez02FdnFquuREiyTar9oTy.XUs8SBm8.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:21','2022-10-01 18:31:21'),(2124,'App\\Models\\Student',2125,'default.png','MUBLIHA SALSAFIRA','6514@gmail.com','6514',NULL,'$2y$10$J/ryTM6LGMOoEZdmMWEPquAuoFB90KMjQE..8g1ildchmNW0/Y.cu',NULL,NULL,0,1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2125,'App\\Models\\Student',2126,'default.png','NAZALA AIYANG VIANDINI','6540@gmail.com','6540',NULL,'$2y$10$tGm8ofBQx8L15HevjyPyhO.Q0C8OoNt85h37k4D3LVmQuMbMSHcXO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2126,'App\\Models\\Student',2127,'default.png','NINDA MEILANISTI UTARI','6549@gmail.com','6549',NULL,'$2y$10$rhn2qAqxoa7shOdNfU3CZ.zgcBKfXGC15ONZ4JUtcJlW7ZXcb7gTO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:22','2022-10-01 18:31:22'),(2127,'App\\Models\\Student',2128,'default.png','NOVAL TRI ARIANSYAH','6551@gmail.com','6551',NULL,'$2y$10$lC28oKuyrrNIQ5/tWMzFCOLCTJu6ZjdFPVle8GZn6nLCjZhw1K9L6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:23','2022-10-01 18:31:23'),(2128,'App\\Models\\Student',2129,'default.png','PUSPA AYU INTAN PERTIWI','6558@gmail.com','6558',NULL,'$2y$10$DGIrytXZQ0zXu05waVtOzOyPuD7BxlZ67EMfsufIq3oSM9d4tFk2O',NULL,NULL,0,1,NULL,'2022-10-01 18:31:23','2022-10-01 18:31:23'),(2129,'App\\Models\\Student',2130,'default.png','RAYA STARTYA RAIHAN','6569@gmail.com','6569',NULL,'$2y$10$oIKA1iaEBdjfs.ZkLLXEjuZF00Nvm3h/Ct/uXOkbjn8W7eqv1r8Uu',NULL,NULL,0,1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2130,'App\\Models\\Student',2131,'default.png','REVALITA DWI DESTYA','6575@gmail.com','6575',NULL,'$2y$10$essu2KBhkr75xc6NeTp9F.h8KsRhrbvyotWFwAyJuU1Ynn3tE2LFS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2131,'App\\Models\\Student',2132,'default.png','RIKHA NUR AZIZAH','6584@gmail.com','6584',NULL,'$2y$10$uhOGWbbXYai1co/7mQXzPOW6F2sPqrfHaFIud/DDKUArC/zMnsYDS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:24','2022-10-01 18:31:24'),(2132,'App\\Models\\Student',2133,'default.png','ROGAN AFDUL DAFA','6591@gmail.com','6591',NULL,'$2y$10$8AqY/2GTRX7ANQ7rOQFyveaY.0tkl7HBeo/Z9h4VLkcAcgNavZBsm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2133,'App\\Models\\Student',2134,'default.png','SINDI MAULIA PUTRI','6606@gmail.com','6606',NULL,'$2y$10$x/TXUV8M1iEeHoUZmqI/tO6ePA/HjnA2Bn/SSs2KOFm.yrbz/7nKS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2134,'App\\Models\\Student',2135,'default.png','TRI YULI ASTUTI','6617@gmail.com','6617',NULL,'$2y$10$qqiDE3hmNX//HDWD9/j7Xe4IjwsFlDtmSfYb094K74L5eR/NbHK0e',NULL,NULL,0,1,NULL,'2022-10-01 18:31:25','2022-10-01 18:31:25'),(2135,'App\\Models\\Student',2136,'default.png','TRIANA AYU RAHMAWATI','6619@gmail.com','6619',NULL,'$2y$10$/tYAn2NZddz2wASjZ2Qw8.hVJ3Fj9zBoQTMbCCgrif1IBORjclB5K',NULL,NULL,0,1,NULL,'2022-10-01 18:31:26','2022-10-01 18:31:26'),(2136,'App\\Models\\Student',2137,'default.png','ZAKIYA NUR SYAFIRA','6628@gmail.com','6628',NULL,'$2y$10$1gkRD8IJjpr6PCgYIV0/sO2m2ZiDso2rQjkpxeJ8C81/mGxAEK/LS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:26','2022-10-01 18:31:26'),(2137,'App\\Models\\Student',2138,'default.png','ADELIA NUR AZIZAH','6309@gmail.com','6309',NULL,'$2y$10$IFXl5wGwlc/0KyhI4eleUuITAXPWpqsrXmtRVxnQ7GdeGviryj3k.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2138,'App\\Models\\Student',2139,'default.png','ALETHA REVALINASYA AZZAHRA','6327@gmail.com','6327',NULL,'$2y$10$U0bICPwLsuEPzi9XLStM7ezqrn1b8vrFbvchoGK.EADgrF/h8e7HO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2139,'App\\Models\\Student',2140,'default.png','AMELIA RAHMAWATI','6332@gmail.com','6332',NULL,'$2y$10$/H6or8rKec1hHWZ03SPR..gMusYiUvhXqmQftxDftkyQ4FzHZ/8Bm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:27','2022-10-01 18:31:27'),(2140,'App\\Models\\Student',2141,'default.png','ANDJANI AURA AL-ARSY','6336@gmail.com','6336',NULL,'$2y$10$wWfEhoDvXoaooMehiZJgR.PcABG6b4Xlt/Hn83inrzRlFOj7DwzCa',NULL,NULL,0,1,NULL,'2022-10-01 18:31:28','2022-10-01 18:31:28'),(2141,'App\\Models\\Student',2142,'default.png','ANGGUN AULIA AZZAHRA ','6340@gmail.com','6340',NULL,'$2y$10$3ooHVzKBy6sC6mRisbbkXOT1.CCW2CWO3kZaWswhgkcMtMlfV2ii2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:28','2022-10-01 18:31:28'),(2142,'App\\Models\\Student',2143,'default.png','ARLINA MEILA PUTRI','6347@gmail.com','6347',NULL,'$2y$10$tXOBmhJo3BgdoIaIcFYYfeXSNJ8GclbsrhVM85zGZTWzPDHYQbB2i',NULL,NULL,0,1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2143,'App\\Models\\Student',2144,'default.png','CAHYA SEFTY EVA PURWANTI','6366@gmail.com','6366',NULL,'$2y$10$xNFmFeDfntm8WTj15LJiH.OyoL4sbdr98iC0i/CqEURRfbU9olDsC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2144,'App\\Models\\Student',2145,'default.png','CALLISTA IRGI MAUREN OKTAVIA','6368@gmail.com','6368',NULL,'$2y$10$Dzb6X9BIRxS6Wb4cPDNhl.n/5s.EM4DSJ0JqJqNkzPPRCFEZ0yN8C',NULL,NULL,0,1,NULL,'2022-10-01 18:31:29','2022-10-01 18:31:29'),(2145,'App\\Models\\Student',2146,'default.png','CHELSEA RAHMAWATI','6371@gmail.com','6371',NULL,'$2y$10$ptrMwZBVK3LFN4ZlvTg3h.rEGZiYi.c3U2fL98qZftcYuPL0SMKL2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2146,'App\\Models\\Student',2147,'default.png','DAVA AJI MAULANA','6382@gmail.com','6382',NULL,'$2y$10$zNJ9iU7VPAHAGw7dQ1l0l.599t7jqTx5w9kwB2zIoNPkW40GlAn6.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2147,'App\\Models\\Student',2148,'default.png','DESTA NATALIA ANGGRAINI','6389@gmail.com','6389',NULL,'$2y$10$9u8wqjmRuJ3j/ajrj6splOMFtDdKN.wnUhHGmDzBRI5.4uH8Tc6Mm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:30','2022-10-01 18:31:30'),(2148,'App\\Models\\Student',2149,'default.png','ELLA EKA NURLAILI','6423@gmail.com','6423',NULL,'$2y$10$jYfMBlKeH508ZMZ4NaPlYOO.wvZcEiH3/YusWm5yoIK7mbtuEsA.G',NULL,NULL,0,1,NULL,'2022-10-01 18:31:31','2022-10-01 18:31:31'),(2149,'App\\Models\\Student',2150,'default.png','JERRY PRIAYUDA','6465@gmail.com','6465',NULL,'$2y$10$jb9ElruJXEhF3ABbzG1GTesjfGp/HvPxvebrb5T0dZVOdBTG/cKhO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:31','2022-10-01 18:31:31'),(2150,'App\\Models\\Student',2151,'default.png','KARINA DWI PUTRI CANTIKA','6468@gmail.com','6468',NULL,'$2y$10$UTEBiaoIQUO088LvehOekO8nfCQLzvNbd.eZq4lLwxTefidvONQSy',NULL,NULL,0,1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2151,'App\\Models\\Student',2152,'default.png','KEYSHA GHITA SHAKILA','6472@gmail.com','6472',NULL,'$2y$10$JFY9HrVsbzu77hNWwZcJYecWxk0IC5ym9i44uS5iWDGkmbuOx9VvW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2152,'App\\Models\\Student',2153,'default.png','KEYZA BUNGA OLIVIA','6475@gmail.com','6475',NULL,'$2y$10$RQVIGCGj2vfcMkaWet9TWuk..5kLa18LaKOr/xnTfXN6XojPKXRFK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:32','2022-10-01 18:31:32'),(2153,'App\\Models\\Student',2154,'default.png','KHARISMA ANDJANI PASA PRIYANTO','6478@gmail.com','6478',NULL,'$2y$10$4Dxa45k4jCLiUzGSBcceA.8k1WRZAZzTo9/IAVE7qv9BRSWVMOfa2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:33','2022-10-01 18:31:33'),(2154,'App\\Models\\Student',2155,'default.png','M. ARGA MAULANA SAPUTRA','6489@gmail.com','6489',NULL,'$2y$10$Wr1LkuyhkwcwUc7RXaV6NuH9jK.9yRsEkRWIw.yNAzaoUbsJSsUL.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:33','2022-10-01 18:31:33'),(2155,'App\\Models\\Student',2156,'default.png','MAULIDA ANANDA SARI','6498@gmail.com','6498',NULL,'$2y$10$vX0H1z42.F8yigiLitttw.pN1Zup0kh/.kO1XWOMwCVRziWVmxVdq',NULL,NULL,0,1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2156,'App\\Models\\Student',2157,'default.png','NABILA NUR MALA SARI','6531@gmail.com','6531',NULL,'$2y$10$jZFcSkIfhCuRGeq56LodF.OkzQBUqZGcft/n0t9AQYulShDNsVQwO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2157,'App\\Models\\Student',2158,'default.png','NATASYA ALISIA FATEHA','6538@gmail.com','6538',NULL,'$2y$10$bEhpf6RgcI/XhU/FF0jNzeEdsT5KKkYNe9FeHrGB/.T7tyWuc6yay',NULL,NULL,0,1,NULL,'2022-10-01 18:31:34','2022-10-01 18:31:34'),(2158,'App\\Models\\Student',2159,'default.png','NAZRIL NAUFAL MUHAEDOR','6542@gmail.com','6542',NULL,'$2y$10$hVm8OYX.9LIFXJIgF9vpE.ZEqdXfHHPcS2xISnJhF1lVktMsEtXzu',NULL,NULL,0,1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2159,'App\\Models\\Student',2160,'default.png','OKFI ARMANURIA AZZAHROH','6554@gmail.com','6554',NULL,'$2y$10$4fMKOMrRu4ANPsmG3vHEfO146/luCd2hOTWEzl2ccLUOYoqt/8SoW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2160,'App\\Models\\Student',2161,'default.png','PINTARIE WAHYU BERLIAN SARIE','6556@gmail.com','6556',NULL,'$2y$10$ZiJABBL3VrU1BR9zlpPMJ.A9LtQLT2oG5Ck5XJC9ZMwdNbz9XvLN2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:35','2022-10-01 18:31:35'),(2161,'App\\Models\\Student',2162,'default.png','RAFI MAULANA PUTRA','6562@gmail.com','6562',NULL,'$2y$10$H8sglcw1O1KGm9fs1OMhpePW/pm/76BPBJb5rdBqpouv7kYjH75Q.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:36','2022-10-01 18:31:36'),(2162,'App\\Models\\Student',2163,'default.png','REZA NOVA PALESTRI','6578@gmail.com','6578',NULL,'$2y$10$AU6Iqj8Zw47.J4EUA31gP.BXjm91U4vnjyhnDblCIi5siu3HlnD2W',NULL,NULL,0,1,NULL,'2022-10-01 18:31:36','2022-10-01 18:31:36'),(2163,'App\\Models\\Student',2164,'default.png','RISMA DAMAYANTI','6585@gmail.com','6585',NULL,'$2y$10$/MCBNraE9fDQ0WGhhcrQe.ap8BlO/nv0BLbhMzSHxEJjJndvptiiK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2164,'App\\Models\\Student',2165,'default.png','RISTA AMELIA','6587@gmail.com','6587',NULL,'$2y$10$Ml6UiQuppWgqdlL8ORc1WudwO8SVLvzPVuoyj8Gh7E98LsJ586VkK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2165,'App\\Models\\Student',2166,'default.png','RIZMA FAUZIA UTAMI','6590@gmail.com','6590',NULL,'$2y$10$kzGL4x38Q4iOnXDzVZnn7ed8lJ56oDO9o4ZOEJGD8B3ucnwkQT2vi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:37','2022-10-01 18:31:37'),(2166,'App\\Models\\Student',2167,'default.png','SALSABILA ANGGRAINI','6595@gmail.com','6595',NULL,'$2y$10$Zzn.lHV1PpXkhPjRYw/1jOntsV9UaOS5l5bHVAGEvVA6IRzuZkEEW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:38','2022-10-01 18:31:38'),(2167,'App\\Models\\Student',2168,'default.png','SHEVA ELHAQQI ALBAS','6605@gmail.com','6605',NULL,'$2y$10$HqX9lbppH0tnfRUp394goOFqgo7F.NtL9sGtgSLyBGr9NgqOfBF1m',NULL,NULL,0,1,NULL,'2022-10-01 18:31:38','2022-10-01 18:31:38'),(2168,'App\\Models\\Student',2169,'default.png','SULTAN AL BAIHAQI','6609@gmail.com','6609',NULL,'$2y$10$bqY8qmi87UxhpFp6FCyyjexSXhH1mwJ6q2qaSwGsEOaiWcphXBGLm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2169,'App\\Models\\Student',2170,'default.png','WAHYU PRAKUSO','6625@gmail.com','6625',NULL,'$2y$10$Ib2Carq94Zbl03n7NKPigOCnwVMvkctlf/Ljbnihm.x2MIXbjTemC',NULL,NULL,0,1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2170,'App\\Models\\Student',2171,'default.png','ZHORA NORIN DAVITA SARI','6631@gmail.com','6631',NULL,'$2y$10$cu54RM16BOt8Zb0a3RVyqOh0FBBr6IDbz64kCDTlqfloqyrs5tTp.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:39','2022-10-01 18:31:39'),(2171,'App\\Models\\Student',2172,'default.png','ADELIA PUTRI CAHYANI','6310@gmail.com','6310',NULL,'$2y$10$s2Ab4welXJWz9SkFA.Xx4Omd0K3inyOk82ppucftAIwOGW8pSHLA.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2172,'App\\Models\\Student',2173,'default.png','ADELIA ZAHRA','6311@gmail.com','6311',NULL,'$2y$10$F/Kdo8HHYkJh/inIk2TZh.BSEmx1PZdMQp5olQfPIiNwfuJFvqC/K',NULL,NULL,0,1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2173,'App\\Models\\Student',2174,'default.png','AGNES KALESIA ANGGI','6318@gmail.com','6318',NULL,'$2y$10$/JK1apNEKMpFbC0zaHLACO1sYpoM5rgOe.1M6nkScvpJQALwEpR7S',NULL,NULL,0,1,NULL,'2022-10-01 18:31:40','2022-10-01 18:31:40'),(2174,'App\\Models\\Student',2175,'default.png','AINUN ANNISA AZZAHRA','6321@gmail.com','6321',NULL,'$2y$10$8c5igkQz2Z3OKBINT4pFPeIE7Arrdlo4XWER3occNwrZ2b5cuv3Uu',NULL,NULL,0,1,NULL,'2022-10-01 18:31:41','2022-10-01 18:31:41'),(2175,'App\\Models\\Student',2176,'default.png','AISIFAH NURAINI IKA SAPUTRI','6323@gmail.com','6323',NULL,'$2y$10$kYZxC9uwdfRrIyY3QLp8FeEYlDUj/.5KVhLQEe6sup1qF4fR0AKMK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:41','2022-10-01 18:31:41'),(2176,'App\\Models\\Student',2177,'default.png','ALDI RISKI SETIAWAN','6325@gmail.com','6325',NULL,'$2y$10$ChiixGArsMl35nmaRbrKVez3HoaQkxQI5L0WNejDV6/CTEeCTs6Dq',NULL,NULL,0,1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2177,'App\\Models\\Student',2178,'default.png','AXCEL TIRTA FAHRIZAL','6357@gmail.com','6357',NULL,'$2y$10$rAkvBhBACcm9ZmKtHi30e.4oEtWZEcpvK3YCUNgrVrgRGvC4uqF..',NULL,NULL,0,1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2178,'App\\Models\\Student',2179,'default.png','CHANTIKA ZAHRA AZIZAH','6370@gmail.com','6370',NULL,'$2y$10$nkMH8.AvwRsnKQJzCImH3uDTeelLnrGSBQx77PpSIp.RPPCCjsSoe',NULL,NULL,0,1,NULL,'2022-10-01 18:31:42','2022-10-01 18:31:42'),(2179,'App\\Models\\Student',2180,'default.png','CLAUDHINA MARTHA HARIYADI','6377@gmail.com','6377',NULL,'$2y$10$BpOgW7erDAj3QNigznFnHu4DBjgEvQqpWyvMoPoZLCsVCu4ik7eF.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:43','2022-10-01 18:31:43'),(2180,'App\\Models\\Student',2181,'default.png','DEALOVA FRANSISKA','6383@gmail.com','6383',NULL,'$2y$10$AEhcKH/esNvg5rrUTLC09ehiSTf4usaNMFQWW3tFNHq/HGOt6Fzoi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:43','2022-10-01 18:31:43'),(2181,'App\\Models\\Student',2182,'default.png','DELA WULANDARI','6385@gmail.com','6385',NULL,'$2y$10$c35lh85dsKHrBZjH9V10xOoXMZdgRWXoAvkKhmLNYCVK2Keu0J5BS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2182,'App\\Models\\Student',2183,'default.png','DEVI CITRA SARI','6392@gmail.com','6392',NULL,'$2y$10$dN5b/yhHjSYx65bDOdA2gu59Y2Adgut6E9pgA.N5v5iWBMKO14/mO',NULL,NULL,0,1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2183,'App\\Models\\Student',2184,'default.png','ELIZA NUR NABILLAH','6422@gmail.com','6422',NULL,'$2y$10$Lplu3zMXGe7loCEXS8B48eb4tmFB95KoSs7tiEd0aL0wx39AKHPea',NULL,NULL,0,1,NULL,'2022-10-01 18:31:44','2022-10-01 18:31:44'),(2184,'App\\Models\\Student',2185,'default.png','FAREL AGUSTIANO PRATAMA','6429@gmail.com','6429',NULL,'$2y$10$7TgMRIQ6/cSRdAe8f7m59ujqa7yNfJT/eRd/fEp5Ed6xi6YG.2tP2',NULL,NULL,0,1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2185,'App\\Models\\Student',2186,'default.png','FARIKHA RIZQI FADILA','6432@gmail.com','6432',NULL,'$2y$10$F2FWLgOrQxyqjkZT7mUu/.vffwPigYaC2fl8ubK7uOTYcfaAsn7di',NULL,NULL,0,1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2186,'App\\Models\\Student',2187,'default.png','KEISYA MAULIA NANDITA MAWARDI','6470@gmail.com','6470',NULL,'$2y$10$tOqzZEjwYWRkwgVFErq5Q.mIelX9zPhLEFn79dGB3rZuJ6S0uCSoK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:45','2022-10-01 18:31:45'),(2187,'App\\Models\\Student',2188,'default.png','KEYRA ZILLA AMELIA','6471@gmail.com','6471',NULL,'$2y$10$46gWRg.au1keNABSzYlezOZPAlWjmneAd5ZNn4lUi3.Uq7yP224cy',NULL,NULL,0,1,NULL,'2022-10-01 18:31:46','2022-10-01 18:31:46'),(2188,'App\\Models\\Student',2189,'default.png','KHILYA NAFA\'ATUS SYAFI\'I','6480@gmail.com','6480',NULL,'$2y$10$8w2I1fbMjXPmf52L9manQOSKcLPOhnjz56CpQu52didPLMN2JaTPi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:46','2022-10-01 18:31:46'),(2189,'App\\Models\\Student',2190,'default.png','MAGHFIROH FITRI MAULANI','6493@gmail.com','6493',NULL,'$2y$10$rwmgmg7MB6HxFQ5ozplJ8unBrLt8GK3ZStKRebDoIU7I0I5rBgCAG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2190,'App\\Models\\Student',2191,'default.png','MAULANA WIJAYA','6497@gmail.com','6497',NULL,'$2y$10$w1cCnfq.KbDD0lq1TrCnTu/WXsAn.uXjy9ATRCjsGzyM8toXJPCsy',NULL,NULL,0,1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2191,'App\\Models\\Student',2192,'default.png','MELDA MAULADITA','6499@gmail.com','6499',NULL,'$2y$10$4kM7efJgMDWdlY8yHQj3eueWSjuT.MrFnN88u6dgaxrSHXgAqJ58K',NULL,NULL,0,1,NULL,'2022-10-01 18:31:47','2022-10-01 18:31:47'),(2192,'App\\Models\\Student',2193,'default.png','MELINDA TWIN JEFRINA RAHMADANI','6500@gmail.com','6500',NULL,'$2y$10$gpBRk0ZqPB15g9NmXkcDcOfQetIvf8Cl5G/cupZ.I4jEn48Yo.w9u',NULL,NULL,0,1,NULL,'2022-10-01 18:31:48','2022-10-01 18:31:48'),(2193,'App\\Models\\Student',2194,'default.png','MOHAMAD HUSNI RAHMADANI','6509@gmail.com','6509',NULL,'$2y$10$SMJGalUJ6.6J7MBg/JsiseUVOCZOJgUhmpp1AxdUYoRtKFdKqRxH.',NULL,NULL,0,1,NULL,'2022-10-01 18:31:48','2022-10-01 18:31:48'),(2194,'App\\Models\\Student',2195,'default.png','MUHAMMAD VINO TRI SURYA ANGGARA','6525@gmail.com','6525',NULL,'$2y$10$LNqO2PKLIB.KdGCS0POZ4uasVnbNPoNvksZ.IIssRQSGGNTQIcfYS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:48','2022-10-01 18:31:48'),(2195,'App\\Models\\Student',2196,'default.png','MUTMAINA','6529@gmail.com','6529',NULL,'$2y$10$mm9g1GnajR7l1M/CIzLttesn0jA3m6Lo00OeGzPldobgTy.OTr4KS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:49','2022-10-01 18:31:49'),(2196,'App\\Models\\Student',2197,'default.png','NAFIRA JULIA AZZAHRO','6534@gmail.com','6534',NULL,'$2y$10$S4L.I2jxT.O0OFcNN6Nh5.FqDARwJCNYi0zHWIvj6zhmbR9ouzvJ6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:49','2022-10-01 18:31:49'),(2197,'App\\Models\\Student',2198,'default.png','NAZWA LUNA SHAFA RAIHANI','6543@gmail.com','6543',NULL,'$2y$10$31L6ZPV5nXXf04I8ENn5KuVQfkAiLR9wgXQuDPu0rYE4eZDPxv2AW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2198,'App\\Models\\Student',2199,'default.png','NGIZZA ULIATUNNAFISAH','6547@gmail.com','6547',NULL,'$2y$10$pB5K9glf.BBPl3eggxqYju3eGozZW54vLwuQRC76/JxwQCiDfCgUK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2199,'App\\Models\\Student',2200,'default.png','REVA FEBRINA NUR HABIBAH','6574@gmail.com','6574',NULL,'$2y$10$uMQIS35THyNpqddhdNcL3uOsDHVCI/A1LQxC6FYSKG4qc62ZDb0Q6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:50','2022-10-01 18:31:50'),(2200,'App\\Models\\Student',2201,'default.png','REZI NOVA PALESTRI ','6579@gmail.com','6579',NULL,'$2y$10$1MBfn/5oe7rQq3rUun.rHO06qugBmiBqGyF6ObNSWCzEJRYPWzB1S',NULL,NULL,0,1,NULL,'2022-10-01 18:31:51','2022-10-01 18:31:51'),(2201,'App\\Models\\Student',2202,'default.png','RIBI WULANDARI','6580@gmail.com','6580',NULL,'$2y$10$trhQEArD7WNyAr6CbAzAeu90Mn6WGRTa29a9GfQH9btd4H7/cY7ti',NULL,NULL,0,1,NULL,'2022-10-01 18:31:51','2022-10-01 18:31:51'),(2202,'App\\Models\\Student',2203,'default.png','RIENDA NUR JEFLINA','6581@gmail.com','6581',NULL,'$2y$10$KEAFjNDDyJm.PDIztMB5VeMeebEoI0RejrOjO8yyKkrVXidJrfK8C',NULL,NULL,0,1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2203,'App\\Models\\Student',2204,'default.png','SAMUEL KENANDY','6597@gmail.com','6597',NULL,'$2y$10$tADD15MMqbxCGO.LkLKlkeyuDP0J1e1UICIFHQQ373CSmnrZsh7My',NULL,NULL,0,1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2204,'App\\Models\\Student',2205,'default.png','SHENDI PUTRA','6603@gmail.com','6603',NULL,'$2y$10$lO.jwg7//gLpBrwgKgE6lOLHzI/Vo0KhQeG76IISqhE6A9kkFA7MW',NULL,NULL,0,1,NULL,'2022-10-01 18:31:52','2022-10-01 18:31:52'),(2205,'App\\Models\\Student',2206,'default.png','TAHTA AYU LAZUARDINI','6611@gmail.com','6611',NULL,'$2y$10$01K32JwWTCQRBFwsZBvGgOln8vYP7LKlbb.wq79PYE2.u5lf9ZOru',NULL,NULL,0,1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2206,'App\\Models\\Student',2207,'default.png','VIONA LAELYKA AZIZ','6623@gmail.com','6623',NULL,'$2y$10$gwNEWbKFZN5ELRCNu.xs/eZa4U8ByrhI8Sw24v8DyATalFAOeQcE6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2207,'App\\Models\\Student',2208,'default.png','YOFI FATMALA','6626@gmail.com','6626',NULL,'$2y$10$WCPiCA9pOQYqAlgO7uedWOTLvqYPo6wQPXFWBx07C74sCXKr.ogGm',NULL,NULL,0,1,NULL,'2022-10-01 18:31:53','2022-10-01 18:31:53'),(2208,'App\\Models\\Student',2209,'default.png','ALISYA ALMA ARISOM','6330@gmail.com','6330',NULL,'$2y$10$p1ziseuOSYZ6Hcg6Z5OFH.qry2s7KdZQqB9KRjlwGBjNiy1.iBgya',NULL,NULL,0,1,NULL,'2022-10-01 18:31:54','2022-10-01 18:31:54'),(2209,'App\\Models\\Student',2210,'default.png','ANISA DINDA ANDIRA RAHMA','6342@gmail.com','6342',NULL,'$2y$10$LILo4Q127uAHzvv/H4xFrO.gelvOAJj5Sh19TekxXGv6GuaCPFQi6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:54','2022-10-01 18:31:54'),(2210,'App\\Models\\Student',2211,'default.png','AYU DYA PRAMISWARI','6359@gmail.com','6359',NULL,'$2y$10$BMOY3xQd1QbEmvK8SPfnZO46SDCqqqyt66uP2vs.92ttpv/dZ6MGK',NULL,NULL,0,1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2211,'App\\Models\\Student',2212,'default.png','BETRAN CAHYA SAPUTRA','6362@gmail.com','6362',NULL,'$2y$10$2e1uYO6jVUp60v4ZqlN1Bu9O0AnKfIiv9s7S6NW7LeEAjvl7PlLR6',NULL,NULL,0,1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2212,'App\\Models\\Student',2213,'default.png','CALISTA JULYA SAPTA RINO','6367@gmail.com','6367',NULL,'$2y$10$C/pevA1AAQniJ6pQPkRJl.c8cBTh7bQedVeq1MKA2xZLBSlI392uS',NULL,NULL,0,1,NULL,'2022-10-01 18:31:55','2022-10-01 18:31:55'),(2213,'App\\Models\\Student',2214,'default.png','CINDY ALEXA FEBRIANA','6373@gmail.com','6373',NULL,'$2y$10$S085SSE83kkxcgxXXe9gtOsLyHEg2dOSTJvjMJZNwuIJophuWYIXu',NULL,NULL,0,1,NULL,'2022-10-01 18:31:56','2022-10-01 18:31:56'),(2214,'App\\Models\\Student',2215,'default.png','DENOK MANGGARANI','6386@gmail.com','6386',NULL,'$2y$10$4dpI2QlV5ee1hiW82fSgze7lhOgmiI33b.DX5b6rBzfdOeNA5ne1u',NULL,NULL,0,1,NULL,'2022-10-01 18:31:56','2022-10-01 18:31:56'),(2215,'App\\Models\\Student',2216,'default.png','DERRYL AZZA MAULANA','6387@gmail.com','6387',NULL,'$2y$10$DWu63/sOQuaX0A1dwBBXreW5DYZ4slBMi2pjRPMbVGzZboFoOnz.O',NULL,NULL,0,1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2216,'App\\Models\\Student',2217,'default.png','DEVA YUSUF SAPUTRA ','6391@gmail.com','6391',NULL,'$2y$10$3mb7D457inxp.Lnwxi6p1OONbGAz2SrR2NewhOX5nABcUFrsRoNDy',NULL,NULL,0,1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2217,'App\\Models\\Student',2218,'default.png','DIEMAS DWI ARDIANSYAH','6401@gmail.com','6401',NULL,'$2y$10$X8OhoMlFAHXbKQrqlQFkAeZe6hqjqshKXvU.zb/VwKumPELzv.O/e',NULL,NULL,0,1,NULL,'2022-10-01 18:31:57','2022-10-01 18:31:57'),(2218,'App\\Models\\Student',2219,'default.png','DIMAS NOVIANTO','6407@gmail.com','6407',NULL,'$2y$10$lw0Eij8gUx0LnQ1/e0wGYeqdT9tRdirfr8Jerks5jTI7Q0X3iP56m',NULL,NULL,0,1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2219,'App\\Models\\Student',2220,'default.png','DIVA CITRA SARI','6414@gmail.com','6414',NULL,'$2y$10$.BrmmwBznnBz49joujlx/O1o0PNLSZKHU/6UBgDzDdgZQqbqeLnJi',NULL,NULL,0,1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2220,'App\\Models\\Student',2221,'default.png','DYAS SHERINE AMUKTI','6417@gmail.com','6417',NULL,'$2y$10$Nn4BP4LDGbN3gomiDzTPf.gg/G1LDKu.EUTlIJ2LQI032VdopPO8a',NULL,NULL,0,1,NULL,'2022-10-01 18:31:58','2022-10-01 18:31:58'),(2221,'App\\Models\\Student',2222,'default.png','DYSTA ARDELIA RAMADHANI','6418@gmail.com','6418',NULL,'$2y$10$qb7N4kuKXKKQ3cHQjhypH.vPmj59YRW.wsIYFlUdBBDnKSVp/VQAG',NULL,NULL,0,1,NULL,'2022-10-01 18:31:59','2022-10-01 18:31:59'),(2222,'App\\Models\\Student',2223,'default.png','EKSA MAXENTIA IVANA WALUYO','6419@gmail.com','6419',NULL,'$2y$10$PHS4aDtL9yfL5jgRXOZKu.qd35XOQhxBvZlEVovkT2pE9WkJSWjCe',NULL,NULL,0,1,NULL,'2022-10-01 18:31:59','2022-10-01 18:31:59'),(2223,'App\\Models\\Student',2224,'default.png','ESSAFA SADWIKA ANDRIANTA','6426@gmail.com','6426',NULL,'$2y$10$ybteeU5Wq.YDebsPQDWPSOF2uCIyh6NDOHDfP58Rtha1YaadsXgTC',NULL,NULL,0,1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2224,'App\\Models\\Student',2225,'default.png','FEBY PUTRI VALLENTYAS YUSUP','6439@gmail.com','6439',NULL,'$2y$10$gBKXY.ex1KLl6NxiToNTseKazwfm8DQfu/vPhu5t.5W2EqxjoQIga',NULL,NULL,0,1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2225,'App\\Models\\Student',2226,'default.png','GADHIZA ZULEYKA','6447@gmail.com','6447',NULL,'$2y$10$n5mQRic3pOjVHuKmHS7gzOo64kV8z50a1AcHGi2WYZJksXyIZ1pVa',NULL,NULL,0,1,NULL,'2022-10-01 18:32:00','2022-10-01 18:32:00'),(2226,'App\\Models\\Student',2227,'default.png','GIGIH PRATAMA PUTRA','6451@gmail.com','6451',NULL,'$2y$10$SrAXuuCDBbTRdMKldslxn.mTYvWGKkmZuvjw1rM9GGrC0AbUmfKlu',NULL,NULL,0,1,NULL,'2022-10-01 18:32:01','2022-10-01 18:32:01'),(2227,'App\\Models\\Student',2228,'default.png','IMELDA AUDRIA D.','6459@gmail.com','6459',NULL,'$2y$10$hj7miBtUj.QrQ5QJgkTwvOvgEYSTlqEt/j9hCQAV/897QqamUrlIa',NULL,NULL,0,1,NULL,'2022-10-01 18:32:01','2022-10-01 18:32:01'),(2228,'App\\Models\\Student',2229,'default.png','JENNY INDAH WIJAYANTI','6464@gmail.com','6464',NULL,'$2y$10$TqAgGpa2RVI7qjoha0GJK.BCr2lJRxOMlROE3K36HiUQuvKsumQvG',NULL,NULL,0,1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2229,'App\\Models\\Student',2230,'default.png','KIRANA BINTANG BRILLIANTNOSA D.K.J.A.','6481@gmail.com','6481',NULL,'$2y$10$kKJQDUTk.bgHmJnIFTOmReZ6j66tYK2Lb5oeNT1LRo5oG3he92UOC',NULL,NULL,0,1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2230,'App\\Models\\Student',2231,'default.png','MANDA MAETA ANGGRAENI','6494@gmail.com','6494',NULL,'$2y$10$y11nZk/d3qlGftsIahE6GeDjzUsWGIwWdcQkfUiK4RLNHgV378pkG',NULL,NULL,0,1,NULL,'2022-10-01 18:32:02','2022-10-01 18:32:02'),(2231,'App\\Models\\Student',2232,'default.png','MILA SOFIANTI ARINI','6502@gmail.com','6502',NULL,'$2y$10$M6m9Lg5rwFSjBTaY8sjygOojNv/p4BqDHd8agSGIZEafUxQsuFycK',NULL,NULL,0,1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2232,'App\\Models\\Student',2233,'default.png','MUH. FAUZAN AL HAQ DARMAWAN','6515@gmail.com','6515',NULL,'$2y$10$tCYIGtF6IrkyOnx6QggR9uXVobTaTQPv2QJ25Zc0PMHtUB0v8CeS6',NULL,NULL,0,1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2233,'App\\Models\\Student',2234,'default.png','NANDA NAZHIFA MURIA ZHAFIR','6536@gmail.com','6536',NULL,'$2y$10$eCvquouDE4esjtRvWtVl.e7GBiPqKjvCM9cNL9eY5bX88YpIIKf5q',NULL,NULL,0,1,NULL,'2022-10-01 18:32:03','2022-10-01 18:32:03'),(2234,'App\\Models\\Student',2235,'default.png','NAYLA SAKINA PUTRI','6539@gmail.com','6539',NULL,'$2y$10$kMr0KVPI9c.GTYnDFOaKx.Nf/EYmJsa0uev0RhQmJI9lqidXojDpO',NULL,NULL,0,1,NULL,'2022-10-01 18:32:04','2022-10-01 18:32:04'),(2235,'App\\Models\\Student',2236,'default.png','PHANTOM MADA CHITAR','6555@gmail.com','6555',NULL,'$2y$10$s5tB.M4WXxbRnj4nvhFZkeRLoj9OTsvKO/IFo4DodhxW6P1PiqjgS',NULL,NULL,0,1,NULL,'2022-10-01 18:32:04','2022-10-01 18:32:04'),(2236,'App\\Models\\Student',2237,'default.png','RASYA DWI PRASTYA NINGRUM','6568@gmail.com','6568',NULL,'$2y$10$aND6zl6xQEwj4lYVk4/GZue.pB7YS86WlipbeNsyhcnmFp8l2QVO.',NULL,NULL,0,1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2237,'App\\Models\\Student',2238,'default.png','REGA JULIAN SHAFIRA','6570@gmail.com','6570',NULL,'$2y$10$3IFs7MkhG6zVLAxMIALueOdyN2Md.YihxH2KzcSZeP6.gMMk8XvJ6',NULL,NULL,0,1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2238,'App\\Models\\Student',2239,'default.png','RIFQA ANANDA CINTA','6582@gmail.com','6582',NULL,'$2y$10$jqCGViG6b7He1GiUXheFau8b.nvf7snzOhJX3OeFic9n71ytCggK6',NULL,NULL,0,1,NULL,'2022-10-01 18:32:05','2022-10-01 18:32:05'),(2239,'App\\Models\\Student',2240,'default.png','RITA AYU LESTARI','6588@gmail.com','6588',NULL,'$2y$10$lSl.CA1zQYYWLYCEn7AreOR9PDMyrj2OpozlD3j0x2G4Nff00oRYK',NULL,NULL,0,1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2240,'App\\Models\\Student',2241,'default.png','SAFIRA AJENG REFA CAHYANI','6593@gmail.com','6593',NULL,'$2y$10$rrIb.QzjMMbF/yKy9ck.H.w7JsHZd8Wdtg3BiRVuXPTdutZrnpGrG',NULL,NULL,0,1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2241,'App\\Models\\Student',2242,'default.png','SAXENA RAKHES ARSHANDI','6600@gmail.com','6600',NULL,'$2y$10$1me4fKrzwr/QLO7lNluWxeVi6n2spC91FLWXBIvIsseD48LSMbf7u',NULL,NULL,0,1,NULL,'2022-10-01 18:32:06','2022-10-01 18:32:06'),(2242,'App\\Models\\Student',2243,'default.png','SEPTIAN WAHYU JEFRINATA','6601@gmail.com','6601',NULL,'$2y$10$iAT63C/u3bb0fH1wLXSQ7eYylDi/Rs8sVf91o8eFWDfLsh0pFQR96',NULL,NULL,0,1,NULL,'2022-10-01 18:32:07','2022-10-01 18:32:07'),(2243,'App\\Models\\Student',2244,'default.png','SYALWA QOTHRUNNADA','6610@gmail.com','6610',NULL,'$2y$10$QfxytUTIY367NrIhSJszN.9g/H080fHeoUUw8i9A8HCazo0BlyFxG',NULL,NULL,0,1,NULL,'2022-10-01 18:32:07','2022-10-01 18:32:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_conference_logs`
--

DROP TABLE IF EXISTS `video_conference_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_conference_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `video_conference_id` bigint(20) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `video_conference_logs_video_conference_id_foreign` (`video_conference_id`),
  KEY `video_conference_logs_student_id_foreign` (`student_id`),
  CONSTRAINT `video_conference_logs_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `video_conference_logs_video_conference_id_foreign` FOREIGN KEY (`video_conference_id`) REFERENCES `video_conferences` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_conference_logs`
--

LOCK TABLES `video_conference_logs` WRITE;
/*!40000 ALTER TABLE `video_conference_logs` DISABLE KEYS */;
INSERT INTO `video_conference_logs` VALUES (1,5,7,'2022-04-08 16:25:08','2022-04-08 16:25:08'),(2,4,7,'2022-04-08 21:02:42','2022-04-08 21:02:42'),(3,4,8,'2022-06-11 20:44:26','2022-06-11 20:44:26');
/*!40000 ALTER TABLE `video_conference_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_conferences`
--

DROP TABLE IF EXISTS `video_conferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_conferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `code` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `meeting_number` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `video_conferences_code_unique` (`code`),
  KEY `video_conferences_course_id_foreign` (`course_id`),
  CONSTRAINT `video_conferences_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_conferences`
--

LOCK TABLES `video_conferences` WRITE;
/*!40000 ALTER TABLE `video_conferences` DISABLE KEYS */;
INSERT INTO `video_conferences` VALUES (1,2,'NV2ASL4M2H','testing video confrence','2022-04-06 05:03:00',NULL,NULL,2,'2022-04-06 05:04:08','2022-04-06 05:04:08'),(2,2,'QOB9DPJOAD','testing video confrence','2022-04-06 05:03:00',NULL,'2022-04-06 05:04:49',1,'2022-04-06 05:04:13','2022-04-06 05:04:49'),(3,2,'XMCQKEVYVE','test','2022-04-06 12:45:00',NULL,NULL,3,'2022-04-06 12:45:36','2022-04-06 12:45:36'),(4,9,'FJEZSLNQ8X','testing','2022-04-07 05:49:00',NULL,'2022-04-11 10:25:34',1,'2022-04-07 05:49:26','2022-04-11 10:25:34'),(5,9,'HXT1ATDGAI','asdgh','2022-04-07 08:43:00','2022-04-08 16:29:27','2022-04-08 16:29:04',2,'2022-04-07 08:43:43','2022-04-08 16:29:27');
/*!40000 ALTER TABLE `video_conferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_elearning'
--

--
-- Dumping routines for database 'db_elearning'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-03  3:36:39
